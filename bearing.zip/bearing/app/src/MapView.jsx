import React, { useEffect, useRef, useCallback } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

/* Real map. Zoom, pan, rotate, tilt — the same interaction model as any
   navigation app, because it is the same library several of them use.

   Basemap: CARTO Positron raster tiles by default. No API key, light styling
   that lets the route and risk layers read clearly, and attribution is baked
   into the source definition because both OSM and CARTO require it.

   Set VITE_MAPTILER_KEY to switch to vector tiles, which give sharper labels
   at high zoom and proper 3D pitch. Everything else is identical. */

const MAPTILER_KEY = import.meta.env.VITE_MAPTILER_KEY;

const RASTER_STYLE = {
  version: 8,
  sources: {
    carto: {
      type: "raster",
      tiles: [
        "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png",
        "https://b.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png",
        "https://c.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png",
      ],
      tileSize: 256,
      maxzoom: 20,
      attribution:
        '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions">CARTO</a>',
    },
  },
  layers: [{ id: "carto", type: "raster", source: "carto" }],
};

const style = () =>
  MAPTILER_KEY
    ? `https://api.maptiler.com/maps/dataviz-light/style.json?key=${MAPTILER_KEY}`
    : RASTER_STYLE;

const BAND_COLOR = [
  "match", ["get", "band"],
  "elevated", "#F0574C",
  "high", "#EC3A2E",
  "severe", "#D82418",
  "keepout", "#A3160D",
  "#F0574C",
];
const BAND_OPACITY = [
  "match", ["get", "band"],
  "elevated", 0.10, "high", 0.16, "severe", 0.24, "keepout", 0.32, 0.1,
];
const JAM_COLOR = [
  "match", ["get", "band"],
  "light", "#F2A93B", "moderate", "#EC7A2C",
  "heavy", "#E8453C", "closed", "#9B1C15", "#F2A93B",
];

const EMPTY = { type: "FeatureCollection", features: [] };

export default function MapView({
  bbox, riskBands, jams, routes, pick, origin, dest, arming,
  onPick, navMode, manoeuvre,
}) {
  const el = useRef(null);
  const map = useRef(null);
  const ready = useRef(false);
  const armingRef = useRef(arming);
  const onPickRef = useRef(onPick);
  armingRef.current = arming;
  onPickRef.current = onPick;

  const setData = useCallback((id, data) => {
    const src = map.current?.getSource(id);
    if (src) src.setData(data || EMPTY);
  }, []);

  /* init once */
  useEffect(() => {
    if (map.current || !el.current) return;
    const m = new maplibregl.Map({
      container: el.current,
      style: style(),
      center: [-87.63, 41.88],
      zoom: 11,
      attributionControl: { compact: true },
    });
    map.current = m;

    m.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), "top-right");
    m.addControl(
      new maplibregl.GeolocateControl({
        positionOptions: { enableHighAccuracy: true },
        trackUserLocation: true,
        showUserHeading: true,
      }),
      "top-right"
    );
    m.addControl(new maplibregl.ScaleControl({ unit: "metric" }), "bottom-left");

    m.on("load", () => {
      // ---- sources ----
      for (const id of ["risk", "jams", "alts", "route", "pins", "manoeuvre"]) {
        m.addSource(id, { type: "geojson", data: EMPTY });
      }

      // ---- risk bands, under everything ----
      m.addLayer({
        id: "risk-fill", type: "fill", source: "risk",
        paint: { "fill-color": BAND_COLOR, "fill-opacity": BAND_OPACITY },
      });
      m.addLayer({
        id: "risk-line", type: "line", source: "risk",
        paint: {
          "line-color": BAND_COLOR,
          "line-width": ["case", ["==", ["get", "band"], "keepout"], 1.6, 0.7],
          "line-opacity": 0.55,
          "line-dasharray": [3, 2],
        },
      });

      // ---- live congestion ----
      m.addLayer({
        id: "jam-fill", type: "fill", source: "jams",
        paint: { "fill-color": JAM_COLOR, "fill-opacity": 0.18 },
      });
      m.addLayer({
        id: "jam-line", type: "line", source: "jams",
        paint: { "line-color": JAM_COLOR, "line-width": 1.2, "line-opacity": 0.5 },
      });

      // ---- alternate routes ----
      m.addLayer({
        id: "alts-case", type: "line", source: "alts",
        layout: { "line-cap": "round", "line-join": "round" },
        paint: { "line-color": "#FFFFFF", "line-width": 8, "line-opacity": 0.9 },
      });
      m.addLayer({
        id: "alts-line", type: "line", source: "alts",
        layout: { "line-cap": "round", "line-join": "round" },
        paint: { "line-color": "#9AA5B1", "line-width": 4.5 },
      });

      // ---- selected route ----
      m.addLayer({
        id: "route-case", type: "line", source: "route",
        layout: { "line-cap": "round", "line-join": "round" },
        paint: { "line-color": "#12336E", "line-width": 11 },
      });
      m.addLayer({
        id: "route-line", type: "line", source: "route",
        layout: { "line-cap": "round", "line-join": "round" },
        paint: { "line-color": ["get", "color"], "line-width": 7 },
      });

      // ---- endpoints + manoeuvre dot ----
      m.addLayer({
        id: "pins", type: "circle", source: "pins",
        paint: {
          "circle-radius": 8,
          "circle-color": "#FFFFFF",
          "circle-stroke-width": 4,
          "circle-stroke-color": ["get", "color"],
        },
      });
      m.addLayer({
        id: "manoeuvre", type: "circle", source: "manoeuvre",
        paint: {
          "circle-radius": 7,
          "circle-color": "#FFFFFF",
          "circle-stroke-width": 4,
          "circle-stroke-color": ["get", "color"],
        },
      });

      ready.current = true;
      m.fire("bearing:ready");
    });

    m.on("click", (e) => {
      const which = armingRef.current;
      if (!which) return;
      onPickRef.current?.(which, [e.lngLat.lng, e.lngLat.lat]);
    });

    return () => { m.remove(); map.current = null; ready.current = false; };
  }, []);

  /* cursor feedback while placing a pin */
  useEffect(() => {
    const m = map.current;
    if (!m) return;
    m.getCanvas().style.cursor = arming ? "crosshair" : "";
  }, [arming]);

  /* fit to the city once we know it */
  useEffect(() => {
    const m = map.current;
    if (!m || !bbox) return;
    const go = () => m.fitBounds([[bbox[0], bbox[1]], [bbox[2], bbox[3]]],
      { padding: 40, duration: 0 });
    ready.current ? go() : m.once("bearing:ready", go);
  }, [bbox]);

  /* data layers */
  const push = useCallback((fn) => {
    const m = map.current;
    if (!m) return;
    ready.current ? fn() : m.once("bearing:ready", fn);
  }, []);

  useEffect(() => { push(() => setData("risk", riskBands)); }, [riskBands, push, setData]);
  useEffect(() => { push(() => setData("jams", jams)); }, [jams, push, setData]);

  useEffect(() => {
    push(() => {
      if (!routes) { setData("alts", EMPTY); setData("route", EMPTY); return; }
      const alts = Object.entries(routes)
        .filter(([k]) => k !== pick)
        .map(([k, r]) => line(r.coordinates, { label: k }));
      setData("alts", { type: "FeatureCollection", features: navMode ? [] : alts });

      const sel = routes[pick];
      setData("route", sel
        ? { type: "FeatureCollection",
            features: [line(sel.coordinates, { color: colorFor(pick) })] }
        : EMPTY);
    });
  }, [routes, pick, navMode, push, setData]);

  useEffect(() => {
    push(() => setData("pins", {
      type: "FeatureCollection",
      features: [
        point(origin, { color: "#2C6BED" }),
        point(dest, { color: "#17A85C" }),
      ],
    }));
  }, [origin, dest, push, setData]);

  useEffect(() => {
    push(() => setData("manoeuvre", manoeuvre
      ? { type: "FeatureCollection",
          features: [point(manoeuvre, { color: colorFor(pick) })] }
      : EMPTY));
  }, [manoeuvre, pick, push, setData]);

  /* frame the route when it changes; follow the manoeuvre in nav */
  useEffect(() => {
    const m = map.current;
    if (!m || !routes?.[pick]) return;
    push(() => {
      if (navMode && manoeuvre) {
        m.easeTo({ center: manoeuvre, zoom: 15.5, duration: 700 });
        return;
      }
      const cs = routes[pick].coordinates;
      const b = cs.reduce(
        (acc, c) => acc.extend(c),
        new maplibregl.LngLatBounds(cs[0], cs[0])
      );
      m.fitBounds(b, { padding: { top: 90, bottom: 300, left: 50, right: 50 }, duration: 600 });
    });
  }, [routes, pick, navMode, manoeuvre, push]);

  return <div ref={el} style={{ position: "absolute", inset: 0 }} />;
}

const colorFor = (k) =>
  k === "safest" ? "#17A85C" : k === "balanced" ? "#F2A93B" : "#2C6BED";

const line = (coords, props) => ({
  type: "Feature", properties: props,
  geometry: { type: "LineString", coordinates: coords },
});
const point = (coords, props) => ({
  type: "Feature", properties: props,
  geometry: { type: "Point", coordinates: coords },
});

/* Address search via Nominatim (OpenStreetMap's geocoder).

   Free and needs no key, but its usage policy caps you at 1 request/second and
   requires identifying your app. Debounce is therefore not a nicety, it is the
   terms of use. For production volume, self-host Nominatim or use a paid
   geocoder — the interface here is small enough to swap in an afternoon. */

const BASE = "https://nominatim.openstreetmap.org/search";
const VIEWBOX = "-87.94,42.03,-87.52,41.64"; // Chicago, lon/lat corners

let inflight;

export async function geocode(query, limit = 5) {
  if (!query || query.trim().length < 3) return [];
  inflight?.abort();
  inflight = new AbortController();

  const qs = new URLSearchParams({
    q: query, format: "jsonv2", limit: String(limit),
    viewbox: VIEWBOX, bounded: "1", addressdetails: "1",
  });
  try {
    const res = await fetch(`${BASE}?${qs}`, {
      signal: inflight.signal,
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return [];
    const rows = await res.json();
    return rows.map((r) => ({
      id: r.place_id,
      label: shortLabel(r),
      full: r.display_name,
      lon: parseFloat(r.lon),
      lat: parseFloat(r.lat),
    }));
  } catch {
    return []; // aborted or offline; the caller just shows nothing
  }
}

function shortLabel(r) {
  const a = r.address || {};
  const line1 = [a.house_number, a.road].filter(Boolean).join(" ")
    || r.name || a.neighbourhood || a.suburb;
  const line2 = a.neighbourhood || a.suburb || a.city || a.town;
  return [line1, line2].filter(Boolean).join(", ") || r.display_name;
}

export function debounce(fn, ms = 400) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import {
  Search, Shield, Navigation2, Settings2, ChevronLeft, Clock, Car, Footprints,
  Sun, Moon, Check, AlertTriangle, Loader2, WifiOff, X, CornerUpLeft,
  CornerUpRight, ArrowUp, ArrowUpRight, ArrowUpLeft, Flag, Gauge, MapPin, Crosshair,
} from "lucide-react";
import MapView from "./MapView.jsx";
import { geocode, debounce } from "./geocode.js";
import { getHealth, getAreaIndex, getArea, getTraffic, postRoute, postSelection } from "./api.js";

const P = {
  ink: "#22262B", muted: "#7A828C", line: "#E7E4DE",
  route: "#2C6BED", safe: "#17A85C", amber: "#F2A93B", risk: "#F0574C", jam: "#E8453C",
};
const FONT = 'ui-rounded, "SF Pro Rounded", system-ui, -apple-system, "Segoe UI", sans-serif';
const BANDS = ["elevated", "high", "severe", "keepout"];
const CONCERNS = [
  { id: "alone", label: "Alone" },
  { id: "with_children", label: "With kids" },
  { id: "carrying_valuables", label: "Carrying valuables" },
  { id: "unfamiliar_area", label: "Unfamiliar area" },
];
const SIGNS = {
  "-7": [CornerUpLeft], "-3": [CornerUpLeft], "-2": [CornerUpLeft], "-1": [ArrowUpLeft],
  "0": [ArrowUp], "1": [ArrowUpRight], "2": [CornerUpRight], "3": [CornerUpRight],
  "4": [Flag], "5": [Flag], "6": [Navigation2], "7": [CornerUpRight],
};
const META = {
  fastest: { label: "Fastest", color: P.route },
  balanced: { label: "Balanced", color: P.amber },
  safest: { label: "Safest", color: P.safe },
};

export default function App() {
  const session = useRef(Math.random().toString(36).slice(2) + Date.now().toString(36)).current;

  const [health, setHealth] = useState(null);
  const [bbox, setBbox] = useState(null);
  const [riskBands, setRiskBands] = useState(null);
  const [jams, setJams] = useState(null);
  const [trafficMeta, setTrafficMeta] = useState(null);

  const [mode, setMode] = useState("pedestrian");
  const [concerns, setConcerns] = useState(["alone"]);
  const [hour, setHour] = useState(22);
  const [safety, setSafety] = useState(0.8);

  const [origin, setOrigin] = useState([-87.6298, 41.8781]);
  const [dest, setDest] = useState([-87.5987, 41.7897]);
  const [originName, setOriginName] = useState("The Loop");
  const [destName, setDestName] = useState("Hyde Park");
  const [arming, setArming] = useState(null);

  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchFor, setSearchFor] = useState(null);

  const [routes, setRoutes] = useState(null);
  const [offerId, setOfferId] = useState(null);
  const [pick, setPick] = useState("safest");
  const [view, setView] = useState("routes");
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  const isNight = hour >= 20 || hour < 6;
  const tod = isNight ? "night" : "day";
  const layerBase = mode === "pedestrian" ? "person" : "property";

  useEffect(() => {
    (async () => {
      try {
        setHealth(await getHealth());
        setBbox((await getAreaIndex()).bbox);
      } catch {
        setErr("Cannot reach the API on localhost:8000. Start it with ./ops/run.sh");
      }
    })();
  }, []);

  useEffect(() => {
    if (!bbox) return;
    let dead = false;
    (async () => {
      const feats = [];
      for (const band of BANDS) {
        try {
          const g = await getArea(layerBase + "_" + tod + "_" + band);
          for (const f of g.features || []) {
            feats.push({ ...f, properties: { ...f.properties, band } });
          }
        } catch { /* empty band is normal */ }
      }
      if (!dead) setRiskBands({ type: "FeatureCollection", features: feats });
    })();
    return () => { dead = true; };
  }, [bbox, layerBase, tod]);

  useEffect(() => {
    if (!bbox || mode !== "vehicle") { setJams(null); return; }
    let dead = false;
    const pull = async () => {
      try {
        const g = await getTraffic(hour);
        if (dead) return;
        setJams({
          type: "FeatureCollection",
          features: (g.features || []).map((f) => ({
            ...f, properties: { ...f.properties, band: (f.properties && f.properties.band) || "light" },
          })),
        });
        setTrafficMeta({ source: g.source, synthetic: g.is_synthetic });
      } catch { if (!dead) setJams(null); }
    };
    pull();
    const iv = setInterval(pull, 60000);
    return () => { dead = true; clearInterval(iv); };
  }, [bbox, mode, hour]);

  const fetchRoutes = useCallback(async () => {
    setBusy(true); setErr(null);
    try {
      const d = await postRoute({
        origin, destination: dest,
        profile: { mode, concerns, hour, safety },
        session_id: session,
      });
      setRoutes(d.routes); setOfferId(d.offer_id);
      const keys = Object.keys(d.routes);
      setPick((p) => (keys.includes(p) ? p : keys.includes("safest") ? "safest" : keys[0]));
      setStep(0);
    } catch (e) {
      setErr(String(e.message || e)); setRoutes(null);
    } finally { setBusy(false); }
  }, [origin, dest, mode, concerns, hour, safety, session]);

  useEffect(() => { if (bbox) fetchRoutes(); }, [bbox, fetchRoutes]);

  const choose = useCallback((label, navStarted) => {
    setPick(label);
    if (offerId) postSelection({ offer_id: offerId, selected: label, nav_started: !!navStarted });
  }, [offerId]);

  const runSearch = useMemo(() => debounce(async (q) => {
    setSearching(true);
    setResults(await geocode(q));
    setSearching(false);
  }, 450), []);

  useEffect(() => {
    if (searchFor && query.trim().length >= 3) runSearch(query);
    else setResults([]);
  }, [query, searchFor, runSearch]);

  const applyResult = (r) => {
    const at = [r.lon, r.lat];
    if (searchFor === "A") { setOrigin(at); setOriginName(r.label); }
    else { setDest(at); setDestName(r.label); }
    setSearchFor(null); setQuery(""); setResults([]);
  };

  const onMapPick = useCallback((which, lngLat) => {
    const name = lngLat[1].toFixed(4) + ", " + lngLat[0].toFixed(4);
    if (which === "A") { setOrigin(lngLat); setOriginName(name); }
    else { setDest(lngLat); setDestName(name); }
    setArming(null);
  }, []);

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => { setOrigin([pos.coords.longitude, pos.coords.latitude]); setOriginName("Current location"); },
      () => setErr("Location permission denied"),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const order = ["fastest", "balanced", "safest"];
  const shown = routes ? order.filter((k) => routes[k]) : [];
  const sel = routes ? routes[pick] : null;
  const instructions = ((sel && sel.instructions) || []).filter((i) => i.distance > 0 || i.sign === 4);
  const cur = instructions[step];
  const manoeuvre = view === "nav" && sel && cur
    ? sel.coordinates[Math.min((cur.interval && cur.interval[0]) || 0, sel.coordinates.length - 1)]
    : null;
  const navColor = (META[pick] && META[pick].color) || P.route;

  const eta = (min) => {
    const d = new Date(); d.setHours(hour, 0, 0, 0);
    d.setMinutes(d.getMinutes() + Math.round(min));
    return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  };
  const km = (m) => (m >= 1000 ? (m / 1000).toFixed(1) + " km" : Math.round(m) + " m");

  return (
    <div style={{ position: "fixed", inset: 0, fontFamily: FONT, color: P.ink }}>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg) } }
        .spin { animation: spin 1s linear infinite }
        input[type=range]{-webkit-appearance:none;appearance:none;background:transparent;width:100%}
        input[type=range]::-webkit-slider-runnable-track{height:3px;background:${P.line};border-radius:2px}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:20px;height:20px;
          border-radius:10px;background:${P.ink};margin-top:-9px;cursor:pointer}
        input[type=range]::-moz-range-track{height:3px;background:${P.line};border-radius:2px}
        input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:10px;
          background:${P.ink};border:none;cursor:pointer}
        button:focus-visible,input:focus-visible{outline:3px solid ${P.route};outline-offset:2px}
        .maplibregl-ctrl-top-right{margin-top:120px}
        @media (prefers-reduced-motion: reduce){ .spin{animation:none} }
      `}</style>

      <MapView
        bbox={bbox} riskBands={riskBands} jams={jams} routes={routes} pick={pick}
        origin={origin} dest={dest} arming={arming} onPick={onMapPick}
        navMode={view === "nav"} manoeuvre={manoeuvre}
      />

      <div style={{ position: "absolute", top: 12, left: 12, right: 12, maxWidth: 420 }}>
        {view === "nav" && sel ? (
          <Card style={{ background: navColor, color: "#fff", display: "flex",
            alignItems: "center", gap: 14, padding: "14px 16px" }}>
            {(() => { const E = SIGNS[String(cur ? cur.sign : 0)] || SIGNS["0"]; const I = E[0];
              return <I size={30} strokeWidth={2.6} />; })()}
            <div style={{ minWidth: 0, lineHeight: 1.2 }}>
              <div style={{ fontSize: 21, fontWeight: 800 }}>{cur ? km(cur.distance) : "Arrive"}</div>
              <div style={{ fontSize: 13.5, opacity: .93, overflow: "hidden",
                textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {cur ? cur.text : "You have arrived"}
              </div>
            </div>
          </Card>
        ) : searchFor ? (
          <Card style={{ padding: 0, overflow: "hidden" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "11px 14px" }}>
              <button onClick={() => { setSearchFor(null); setQuery(""); }}
                style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                <ChevronLeft size={20} color={P.ink} />
              </button>
              <input autoFocus value={query} onChange={(e) => setQuery(e.target.value)}
                placeholder={searchFor === "A" ? "Search start..." : "Search destination..."}
                style={{ flex: 1, border: "none", outline: "none", fontSize: 14.5,
                  fontWeight: 600, background: "transparent", fontFamily: FONT }} />
              {searching ? <Loader2 size={14} color={P.muted} className="spin" />
                         : <Search size={14} color={P.muted} />}
            </div>
            {results.map((r) => (
              <button key={r.id} onClick={() => applyResult(r)}
                style={{ display: "flex", gap: 10, width: "100%", textAlign: "left",
                  padding: "10px 14px", background: "none", border: "none",
                  borderTop: "1px solid " + P.line, cursor: "pointer", fontFamily: FONT }}>
                <MapPin size={15} color={P.muted} style={{ flexShrink: 0, marginTop: 2 }} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700 }}>{r.label}</div>
                  <div style={{ fontSize: 11.5, color: P.muted, overflow: "hidden",
                    textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.full}</div>
                </div>
              </button>
            ))}
            {query.length >= 3 && !searching && results.length === 0 && (
              <div style={{ padding: "10px 14px", fontSize: 12.5, color: P.muted,
                borderTop: "1px solid " + P.line }}>
                Nothing found in Chicago. Try a street and number.
              </div>
            )}
          </Card>
        ) : (
          <>
            <Card style={{ padding: 0, overflow: "hidden" }}>
              {[["A", originName, P.route], ["B", destName, P.safe]].map((row, i) => {
                const k = row[0], name = row[1], color = row[2];
                return (
                  <div key={k} style={{ display: "flex", alignItems: "center", gap: 10,
                    padding: "9px 12px", borderTop: i ? "1px solid " + P.line : "none" }}>
                    <span style={{ width: 9, height: 9, borderRadius: 5, background: color, flexShrink: 0 }} />
                    <button onClick={() => setSearchFor(k)}
                      style={{ flex: 1, textAlign: "left", background: "none", border: "none",
                        cursor: "pointer", fontFamily: FONT, fontSize: 14, fontWeight: 600,
                        color: P.ink, overflow: "hidden", textOverflow: "ellipsis",
                        whiteSpace: "nowrap", padding: 0 }}>{name}</button>
                    {k === "A" && (
                      <IconBtn title="Use my location" onClick={useMyLocation}>
                        <Crosshair size={15} color={P.muted} />
                      </IconBtn>
                    )}
                    <IconBtn title={"Drop " + k + " on the map"} active={arming === k}
                      onClick={() => setArming(arming === k ? null : k)}>
                      <MapPin size={15} color={arming === k ? "#fff" : P.muted} />
                    </IconBtn>
                  </div>
                );
              })}
            </Card>
            <div style={{ display: "flex", gap: 8, marginTop: 8, alignItems: "center", flexWrap: "wrap" }}>
              <Pill onClick={() => setView(view === "prefs" ? "routes" : "prefs")}>
                <Settings2 size={13} /> {mode === "pedestrian" ? "Walking" : "Driving"} · {isNight ? "Night" : "Day"}
              </Pill>
              {busy && <Pill><Loader2 size={13} className="spin" /> Routing</Pill>}
              {arming && <Pill>Tap the map</Pill>}
              {mode === "vehicle" && jams && jams.features.length > 0 && (
                <Pill><Gauge size={13} color={P.jam} /> {jams.features.length} jams
                  {trafficMeta && trafficMeta.synthetic ? <span style={{ color: P.muted }}> · demo</span> : null}
                </Pill>
              )}
            </div>
          </>
        )}
      </div>

      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, background: "#fff",
        borderTopLeftRadius: 20, borderTopRightRadius: 20,
        boxShadow: "0 -6px 24px rgba(20,25,35,.16)", maxHeight: "58vh", overflowY: "auto" }}>
        <div style={{ width: 38, height: 4, borderRadius: 2, background: "#DDE0E4", margin: "9px auto 0" }} />

        {err ? (
          <div style={{ padding: "16px 18px 22px", display: "flex", gap: 11 }}>
            <WifiOff size={17} color={P.risk} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <div style={{ fontWeight: 800, fontSize: 14 }}>No connection</div>
              <div style={{ fontSize: 12, color: P.muted, marginTop: 4, lineHeight: 1.5 }}>{err}</div>
            </div>
          </div>
        ) : view === "nav" && sel ? (
          <div style={{ padding: "12px 18px 20px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <button onClick={() => { setView("routes"); setStep(0); }}
                style={{ width: 44, height: 44, borderRadius: 22, background: "#F1F3F5",
                  border: "none", cursor: "pointer", display: "grid", placeItems: "center", flexShrink: 0 }}>
                <X size={20} color={P.ink} />
              </button>
              <div style={{ flex: 1, display: "flex", justifyContent: "space-around", textAlign: "center" }}>
                {[[eta(sel.minutes), "arrival"],
                  [Math.round(sel.minutes) + " min", mode === "pedestrian" ? "walking" : "driving"],
                  [km(sel.distance_m), "distance"]].map((c) => (
                  <div key={c[1]}>
                    <div style={{ fontSize: 18, fontWeight: 800 }}>{c[0]}</div>
                    <div style={{ fontSize: 11, color: P.muted, fontWeight: 600 }}>{c[1]}</div>
                  </div>
                ))}
              </div>
            </div>
            {instructions.length > 1 && (
              <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                <button disabled={step === 0} onClick={() => setStep(step - 1)} style={navBtn(step === 0)}>Back</button>
                <button disabled={step >= instructions.length - 1} onClick={() => setStep(step + 1)}
                  style={navBtn(step >= instructions.length - 1, navColor)}>
                  Next ({step + 1}/{instructions.length})
                </button>
              </div>
            )}
          </div>
        ) : view === "prefs" ? (
          <div style={{ padding: "12px 18px 20px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
              <button onClick={() => setView("routes")}
                style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                <ChevronLeft size={22} color={P.ink} />
              </button>
              <span style={{ fontSize: 17, fontWeight: 800 }}>Trip settings</span>
            </div>
            <Group title="Getting there">
              {[["pedestrian", "Walking", Footprints], ["vehicle", "Driving", Car]].map((o) => (
                <Chip key={o[0]} on={mode === o[0]} onClick={() => setMode(o[0])}>
                  {React.createElement(o[2], { size: 14 })} {o[1]}
                </Chip>
              ))}
            </Group>
            <Group title="Leaving">
              {[[9, "9 AM", Sun], [18, "6 PM rush", Car], [22, "10 PM", Moon]].map((o) => (
                <Chip key={o[1]} on={hour === o[0]} onClick={() => setHour(o[0])}>
                  {React.createElement(o[2], { size: 14 })} {o[1]}
                </Chip>
              ))}
            </Group>
            <Group title="What applies to this trip">
              {CONCERNS.map((c) => (
                <Chip key={c.id} on={concerns.indexOf(c.id) >= 0}
                  onClick={() => setConcerns(concerns.indexOf(c.id) >= 0
                    ? concerns.filter((y) => y !== c.id) : concerns.concat([c.id]))}>
                  {concerns.indexOf(c.id) >= 0 && <Check size={12} strokeWidth={3} />} {c.label}
                </Chip>
              ))}
            </Group>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12,
              fontWeight: 700, color: P.muted, marginBottom: 8 }}>
              <span>Safety priority</span><span>{Math.round(safety * 100)}</span>
            </div>
            <input type="range" min={0} max={100} value={Math.round(safety * 100)}
              onChange={(e) => setSafety(Number(e.target.value) / 100)} aria-label="Safety priority" />
            <p style={{ fontSize: 11, color: P.muted, marginTop: 14, lineHeight: 1.5 }}>
              These change which kinds of reports count against a street. Routes are never weighted by
              neighbourhood income or demographics.
              {health && health.incident_count
                ? " Scored from " + health.incident_count.toLocaleString() + " reports." : ""}
            </p>
          </div>
        ) : (
          <div style={{ padding: "10px 0 18px" }}>
            {!routes && busy && (
              <div style={{ padding: "26px 18px", textAlign: "center", color: P.muted, fontSize: 13 }}>
                <Loader2 size={20} className="spin" /><div style={{ marginTop: 8 }}>Finding routes...</div>
              </div>
            )}
            {shown.map((k) => {
              const r = routes[k], on = pick === k, m = META[k];
              return (
                <button key={k} onClick={() => choose(k)}
                  style={{ display: "flex", alignItems: "center", gap: 12, width: "100%",
                    textAlign: "left", padding: "11px 18px", cursor: "pointer",
                    background: on ? "#F4F7FF" : "transparent", border: "none", fontFamily: FONT,
                    borderLeft: "3px solid " + (on ? m.color : "transparent") }}>
                  <div style={{ width: 33, height: 33, borderRadius: 17, flexShrink: 0,
                    display: "grid", placeItems: "center",
                    background: k === "safest" ? "#E6F6ED" : "#EDF2FE" }}>
                    {k === "safest" ? <Shield size={16} color={P.safe} /> : <Navigation2 size={15} color={P.route} />}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "baseline", gap: 7 }}>
                      <span style={{ fontSize: 18, fontWeight: 800 }}>{Math.round(r.minutes)} min</span>
                      <span style={{ fontSize: 12.5, color: P.muted, fontWeight: 600 }}>{km(r.distance_m)}</span>
                      {r.extra_minutes > 0 && (
                        <span style={{ fontSize: 12, color: P.muted }}>+{Math.round(r.extra_minutes)}</span>
                      )}
                    </div>
                    <div style={{ fontSize: 12, color: P.muted, fontWeight: 600, overflow: "hidden",
                      textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {m.label}
                      {r.exposure_reduction_pct > 0
                        ? " · " + Math.round(r.exposure_reduction_pct) + "% fewer reports nearby" : ""}
                      {r.baseline_already_low && k !== "fastest" ? " · already a quiet route" : ""}
                    </div>
                  </div>
                  {k === "safest" && (
                    <span style={{ fontSize: 10, fontWeight: 800, color: P.safe, background: "#E6F6ED",
                      padding: "4px 8px", borderRadius: 999, flexShrink: 0 }}>SAFEST</span>
                  )}
                </button>
              );
            })}

            {sel && (
              <div style={{ padding: "10px 18px 0" }}>
                <div style={{ background: "#F7F8FA", borderRadius: 12, padding: "11px 13px",
                  display: "flex", gap: 10 }}>
                  {pick === "fastest"
                    ? <AlertTriangle size={15} color={P.risk} style={{ flexShrink: 0, marginTop: 1 }} />
                    : <Shield size={15} color={P.safe} style={{ flexShrink: 0, marginTop: 1 }} />}
                  <span style={{ fontSize: 12.5, lineHeight: 1.5, color: "#4A5058" }}>
                    Exposure {sel.exposure_index.toFixed(2)}, peak {sel.peak_exposure.toFixed(2)},
                    scored for {isNight ? "night" : "daytime"} {mode === "pedestrian" ? "walking" : "driving"}.
                    {mode === "vehicle" && jams && jams.features.length > 0
                      ? " ETA includes " + jams.features.length + " live congestion zones." : ""}
                  </span>
                </div>
              </div>
            )}

            <div style={{ padding: "12px 18px 0" }}>
              <button onClick={() => { if (sel) { choose(pick, true); setView("nav"); setStep(0); } }}
                disabled={!sel}
                style={{ width: "100%", padding: 15, borderRadius: 16, border: "none",
                  cursor: sel ? "pointer" : "default", fontFamily: FONT,
                  background: sel ? navColor : "#C9CED4", color: "#fff",
                  fontSize: 17, fontWeight: 800, letterSpacing: ".03em" }}>Go</button>
              {sel && (
                <div style={{ display: "flex", justifyContent: "center", gap: 6, marginTop: 10,
                  fontSize: 11.5, color: P.muted }}>
                  <Clock size={13} /> Arriving {eta(sel.minutes)}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const Card = ({ children, style }) => (
  <div style={{ background: "#fff", borderRadius: 14, padding: "10px 12px",
    boxShadow: "0 3px 14px rgba(20,25,35,.18)", ...style }}>{children}</div>
);

const Pill = ({ children, onClick }) => (
  <button onClick={onClick} style={{
    display: "inline-flex", alignItems: "center", gap: 6, background: "#fff",
    border: "none", borderRadius: 999, padding: "7px 12px", fontSize: 12,
    fontWeight: 700, color: P.ink, cursor: onClick ? "pointer" : "default",
    fontFamily: FONT, boxShadow: "0 2px 10px rgba(20,25,35,.16)",
  }}>{children}</button>
);

const IconBtn = ({ children, onClick, active, title }) => (
  <button onClick={onClick} title={title} style={{
    width: 30, height: 30, borderRadius: 15, border: "none", cursor: "pointer",
    display: "grid", placeItems: "center", flexShrink: 0,
    background: active ? P.ink : "#F1F3F5",
  }}>{children}</button>
);

const navBtn = (disabled, color) => ({
  flex: 1, padding: 11, borderRadius: 12, border: "none", fontFamily: FONT,
  fontWeight: 700, fontSize: 13.5, cursor: disabled ? "default" : "pointer",
  background: disabled ? "#F1F3F5" : (color || "#EDF0F3"),
  color: disabled ? "#B6BCC3" : (color ? "#fff" : P.ink),
});

function Group({ title, children }) {
  return (
    <div style={{ marginBottom: 15 }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: P.muted, marginBottom: 8 }}>{title}</div>
      <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>{children}</div>
    </div>
  );
}

function Chip({ on, onClick, children }) {
  return (
    <button onClick={onClick} style={{
      padding: "8px 13px", borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: "pointer",
      fontFamily: FONT, display: "flex", alignItems: "center", gap: 6,
      border: "1.5px solid " + (on ? P.ink : P.line),
      background: on ? P.ink : "#fff", color: on ? "#fff" : P.muted,
    }}>{children}</button>
  );
}

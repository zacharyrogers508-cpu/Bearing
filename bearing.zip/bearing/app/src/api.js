// Single place that knows where the backend is.
export const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function req(path, opts) {
  const res = await fetch(API + path, opts);
  if (!res.ok) throw new Error(`${path} -> ${res.status} ${await res.text()}`);
  return res.json();
}

export const getHealth = () => req("/health");
export const getAreaIndex = () => req("/areas");
export const getArea = (layer) => req(`/areas/${layer}`);
export const getTraffic = (hour) => req(`/traffic?hour=${hour}`);

export const postRoute = (body) =>
  req("/route", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

export const postSelection = (body) =>
  req("/telemetry/selection", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).catch(() => {}); // telemetry must never block the user

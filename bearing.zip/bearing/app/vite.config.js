import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // The API allows http://localhost:5173 by default (CORS_ORIGINS).
    // Keep this port, or add yours to CORS_ORIGINS when starting the API.
  },
});

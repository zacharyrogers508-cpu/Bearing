-- Bearing — Chicago. PostGIS 3.4+ / PostgreSQL 15+.
CREATE EXTENSION IF NOT EXISTS postgis;

-- ---------------------------------------------------------------------------
-- Canonical incident store. One row per source record that survived
-- classification. Raw source fields are kept so a taxonomy change can be
-- replayed without re-fetching a year of data.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident (
    id                    BIGSERIAL PRIMARY KEY,
    source                TEXT        NOT NULL,
    source_id             TEXT        NOT NULL,
    occurred_at           TIMESTAMPTZ NOT NULL,
    ingested_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    geom                  GEOGRAPHY(POINT, 4326) NOT NULL,
    canonical             TEXT        NOT NULL,
    weight                REAL        NOT NULL,
    ped_relevance         REAL        NOT NULL,
    veh_relevance         REAL        NOT NULL,
    geocode_precision_m   REAL        NOT NULL,
    raw_type              TEXT,
    raw_description       TEXT,
    location_description  TEXT,
    arrest                BOOLEAN,
    beat                  TEXT,
    UNIQUE (source, source_id)
);
CREATE INDEX IF NOT EXISTS incident_geom_idx      ON incident USING GIST (geom);
CREATE INDEX IF NOT EXISTS incident_occurred_idx  ON incident (occurred_at DESC);
CREATE INDEX IF NOT EXISTS incident_canonical_idx ON incident (canonical);

-- ---------------------------------------------------------------------------
-- Street-light outages. Separate table: different lifecycle (open/closed) and
-- a different update cadence to crime.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS light_outage (
    id          BIGSERIAL PRIMARY KEY,
    source_id   TEXT UNIQUE NOT NULL,
    opened_at   TIMESTAMPTZ NOT NULL,
    closed_at   TIMESTAMPTZ,
    geom        GEOGRAPHY(POINT, 4326) NOT NULL,
    kind        TEXT NOT NULL,
    open_now    BOOLEAN NOT NULL
);
CREATE INDEX IF NOT EXISTS light_geom_idx ON light_outage USING GIST (geom);
CREATE INDEX IF NOT EXISTS light_open_idx ON light_outage (open_now) WHERE open_now;

-- ---------------------------------------------------------------------------
-- Ingest watermarks — one row per (source, dataset).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ingest_state (
    source       TEXT PRIMARY KEY,
    watermark    TEXT,
    last_run_at  TIMESTAMPTZ,
    rows_seen    BIGINT DEFAULT 0,
    rows_kept    BIGINT DEFAULT 0,
    notes        TEXT
);

-- ---------------------------------------------------------------------------
-- Bake provenance. Every published risk surface is reproducible from this row.
-- An acquirer WILL ask how a given route was scored on a given night.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bake (
    id             BIGSERIAL PRIMARY KEY,
    baked_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    taxonomy_sha   TEXT NOT NULL,
    spec           JSONB NOT NULL,
    layer_counts   JSONB NOT NULL,
    incident_count INTEGER NOT NULL,
    band_counts    JSONB NOT NULL,
    graph_ready    BOOLEAN DEFAULT FALSE
);

-- ---------------------------------------------------------------------------
-- Route telemetry. THIS IS THE PHASE 1 DELIVERABLE.
-- The behavioural question — do people take the slower route — is answered
-- from this table and nothing else. Everything upstream exists to fill it.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_offer (
    id             BIGSERIAL PRIMARY KEY,
    offered_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    session_id     TEXT NOT NULL,
    mode           TEXT NOT NULL,
    hour_local     SMALLINT NOT NULL,
    concerns       TEXT[],
    origin         GEOGRAPHY(POINT, 4326),
    destination    GEOGRAPHY(POINT, 4326),
    -- one row per option shown, as JSON so the shape can evolve without a
    -- migration during the beta
    options        JSONB NOT NULL,
    selected       TEXT,
    nav_started    BOOLEAN DEFAULT FALSE,
    nav_completed  BOOLEAN DEFAULT FALSE,
    deviation_m    REAL
);
CREATE INDEX IF NOT EXISTS offer_session_idx ON route_offer (session_id, offered_at);
CREATE INDEX IF NOT EXISTS offer_hour_idx    ON route_offer (hour_local);

-- The metric the whole company turns on.
CREATE OR REPLACE VIEW safer_route_acceptance AS
SELECT
    date_trunc('week', offered_at)                       AS week,
    mode,
    (hour_local >= 20 OR hour_local < 6)                 AS is_night,
    count(*)                                             AS offers,
    count(*) FILTER (WHERE selected <> 'fastest')        AS chose_safer,
    round(100.0 * count(*) FILTER (WHERE selected <> 'fastest')
          / NULLIF(count(*), 0), 1)                      AS pct_safer,
    round(avg((options -> selected ->> 'minutes')::numeric
            - (options -> 'fastest' ->> 'minutes')::numeric), 1) AS avg_extra_min
FROM route_offer
WHERE selected IS NOT NULL
GROUP BY 1, 2, 3
ORDER BY 1 DESC, 2, 3;

"""Synthesise a Chicago-like OSM extract.

The container has no route to geofabrik, and CI should not download a 200 MB
regional PBF anyway. This emits an .osm XML file GraphHopper can import
directly: a real street grid over the real Chicago bounding box, aligned so it
overlaps the hot spots in the crime fixture.

The grid is intentionally coarse (~150 m blocks) — enough to route on and to
prove that custom-area predicates bind to edges, not enough to pretend it is
Chicago's actual road network.
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

# Chicago bbox, matching bearing.ingest.chicago.CITY_BBOX
LON_MIN, LAT_MIN, LON_MAX, LAT_MAX = -87.94, 41.64, -87.52, 42.03

M_PER_DEG_LAT = 111_132.0
M_PER_DEG_LON = 111_320.0 * math.cos(math.radians(41.88))


def build(block_m: float = 150.0) -> str:
    dlat = block_m / M_PER_DEG_LAT
    dlon = block_m / M_PER_DEG_LON
    nrow = int((LAT_MAX - LAT_MIN) / dlat) + 1
    ncol = int((LON_MAX - LON_MIN) / dlon) + 1

    out: list[str] = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<osm version="0.6" generator="bearing-synthetic">',
        f'<bounds minlat="{LAT_MIN}" minlon="{LON_MIN}" '
        f'maxlat="{LAT_MAX}" maxlon="{LON_MAX}"/>',
    ]

    def nid(r: int, c: int) -> int:
        return r * ncol + c + 1

    for r in range(nrow):
        lat = LAT_MIN + r * dlat
        for c in range(ncol):
            lon = LON_MIN + c * dlon
            out.append(f'<node id="{nid(r,c)}" lat="{lat:.7f}" lon="{lon:.7f}" version="1"/>')

    wid = nid(nrow, 0) + 10

    # Every 6th line is an arterial (secondary), the rest residential.
    # Both are foot- and car-accessible, which is what we need for routing.
    for r in range(nrow):
        arterial = (r % 6 == 2)
        out.append(f'<way id="{wid}" version="1">')
        for c in range(ncol):
            out.append(f'<nd ref="{nid(r,c)}"/>')
        out.append(f'<tag k="highway" v="{"secondary" if arterial else "residential"}"/>')
        out.append(f'<tag k="name" v="{r+1} Street"/>')
        out.append('<tag k="sidewalk" v="both"/>')
        if arterial:
            out.append('<tag k="lit" v="yes"/>')
        out.append('<tag k="maxspeed" v="30 mph"/>')
        out.append("</way>")
        wid += 1

    for c in range(ncol):
        arterial = (c % 6 == 3)
        out.append(f'<way id="{wid}" version="1">')
        for r in range(nrow):
            out.append(f'<nd ref="{nid(r,c)}"/>')
        out.append(f'<tag k="highway" v="{"secondary" if arterial else "residential"}"/>')
        out.append(f'<tag k="name" v="Avenue {c+1}"/>')
        out.append('<tag k="sidewalk" v="both"/>')
        if arterial:
            out.append('<tag k="lit" v="yes"/>')
        out.append('<tag k="maxspeed" v="30 mph"/>')
        out.append("</way>")
        wid += 1

    out.append("</osm>")
    return "\n".join(out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=Path("routing/data/chicago-synthetic.osm"))
    ap.add_argument("--block-m", type=float, default=150.0)
    a = ap.parse_args()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    xml = build(a.block_m)
    a.out.write_text(xml)
    n_nodes = xml.count("<node ")
    n_ways = xml.count("<way ")
    print(f"wrote {a.out}  {len(xml)/1e6:.1f} MB  nodes={n_nodes:,} ways={n_ways:,}")

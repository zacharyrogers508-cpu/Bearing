"""Simulate a beta cohort to prove the gate metric discriminates.

Not a substitute for real users. Its job is to confirm that `gate_report`
returns PROCEED on a population that takes the safer route and DO NOT PROCEED
on one that does not — so that when real data arrives we are reading an
instrument we know works, rather than debugging it under pressure.
"""
from __future__ import annotations
import random, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bearing.telemetry import Telemetry, Offer, RouteOption, gate_report, format_gate


def run(true_acceptance: float, n_sessions: int, seed: int, db: Path) -> dict:
    rnd = random.Random(seed)
    if db.exists():
        db.unlink()
    tel = Telemetry(db)
    for s in range(n_sessions):
        sid = f"sess{s}"
        for _ in range(rnd.choices([1, 2, 3], weights=[6, 3, 1])[0]):
            hour = rnd.choice([21, 22, 23, 0, 1] if rnd.random() < 0.7 else [8, 12, 17])
            fast_min = 12 + rnd.random() * 25
            extra = rnd.choice([0.0, 1.0, 3.0, 6.0, 9.0])
            opts = {
                "fastest": RouteOption("fastest", fast_min, fast_min * 78, 0.62),
                "safest": RouteOption("safest", fast_min + extra, (fast_min + extra) * 78,
                                      0.62 * (1 - 0.35 - rnd.random() * 0.3),
                                      extra_minutes=extra, exposure_reduction_pct=45.0),
            }
            off = Offer(session_id=sid, mode="pedestrian", hour_local=hour,
                        options=opts, concerns=["alone"])
            oid = tel.record_offer(off)
            # people accept less readily as the detour grows
            p = true_acceptance * (1.0 if extra <= 3 else 0.75 if extra <= 6 else 0.55)
            chose = "safest" if rnd.random() < p else "fastest"
            tel.record_selection(oid, chose, nav_started=True)
    return gate_report(tel)


if __name__ == "__main__":
    out = Path("/tmp/sim")
    out.mkdir(exist_ok=True)
    for label, p in [("strong demand (p=0.55)", 0.55),
                     ("marginal    (p=0.33)", 0.33),
                     ("weak demand (p=0.10)", 0.10)]:
        r = run(p, 260, seed=hash(label) & 0xFFFF, db=out / f"{p}.db")
        v = "PROCEED" if r["gate"]["passes"] else "DO NOT PROCEED"
        print(f"{label}  ->  acceptance {r['acceptance_pct']:5.1f}% "
              f"CI[{r['acceptance_ci95'][0]:.1f},{r['acceptance_ci95'][1]:.1f}]  "
              f"n={r['night_pedestrian_offers']:<4} return={r['return_pct']:.0f}%  {v}")
    print()
    print(format_gate(run(0.55, 260, seed=7, db=out / "final.db")))

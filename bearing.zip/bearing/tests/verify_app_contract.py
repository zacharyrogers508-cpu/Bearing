"""Replay the exact call sequence app/bearing-live.jsx makes.

The app cannot be clicked in CI, so this asserts the contract it depends on:
every endpoint it calls, every field it reads, and the CORS preflight. If this
passes, a broken app is a rendering bug, not an integration one.
"""
from __future__ import annotations
import json, sys, urllib.error, urllib.request, uuid

API = "http://localhost:8000"
fails: list[str] = []


def req(path, body=None, method=None, headers=None):
    r = urllib.request.Request(
        API + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json", **(headers or {})},
        method=method,
    )
    with urllib.request.urlopen(r, timeout=120) as x:
        return x.status, dict(x.headers), (json.loads(x.read().decode()) if x.status != 204 else None)


def need(cond, msg):
    if not cond:
        fails.append(msg)
    return cond


def main() -> int:
    # 1. boot: /health then /areas
    _, _, h = req("/health")
    need(h.get("ok"), "/health not ok")
    need(isinstance(h.get("incident_count"), int), "/health missing incident_count (app shows it)")
    need(h.get("baked_at"), "/health missing baked_at (app shows it)")

    _, _, idx = req("/areas")
    need(len(idx.get("bbox", [])) == 4, "/areas missing bbox — app cannot build its projection")
    need(len(idx.get("layers", [])) >= 16, f"/areas too few layers: {len(idx.get('layers', []))}")
    print(f"  boot: {h['incident_count']:,} incidents, {len(idx['layers'])} layers, bbox ok")

    # 2. band layers for both profiles the app can switch between
    for base in ("person", "property"):
        for tod in ("night", "day"):
            for band in ("elevated", "high", "severe", "keepout"):
                name = f"{base}_{tod}_{band}"
                try:
                    _, _, g = req(f"/areas/{name}")
                except urllib.error.HTTPError as e:
                    fails.append(f"/areas/{name} -> {e.code}")
                    continue
                feats = g.get("features", [])
                need(len(feats) == 1, f"{name}: expected 1 feature, got {len(feats)}")
                geom = feats[0]["geometry"]
                need(geom["type"] == "MultiPolygon", f"{name}: {geom['type']} not MultiPolygon")
                # app iterates coordinates -> ring -> [lon,lat]
                for poly in geom["coordinates"][:2]:
                    for ring in poly[:1]:
                        need(len(ring[0]) == 2, f"{name}: ring depth wrong for the app's renderer")
    print("  band layers: 16/16 fetchable and shaped for the renderer")

    # 3. routing + telemetry round trip
    sid = uuid.uuid4().hex
    _, _, r = req("/route", {
        "origin": [-87.660, 41.900], "destination": [-87.600, 41.900],
        "profile": {"mode": "pedestrian", "concerns": ["alone"], "hour": 22, "safety": 0.8},
        "session_id": sid,
    })
    need(r.get("offer_id"), "/route did not return offer_id — telemetry cannot be attributed")
    routes = r.get("routes", {})
    need("fastest" in routes, "/route missing fastest")
    for label, v in routes.items():
        for f in ("minutes", "distance_m", "exposure_index", "peak_exposure",
                  "coordinates", "extra_minutes", "exposure_reduction_pct",
                  "baseline_already_low"):
            need(f in v, f"route.{label} missing {f} (app reads it)")
        need(len(v["coordinates"]) >= 2, f"route.{label} degenerate geometry")
        need(len(v["coordinates"][0]) == 2, f"route.{label} coords not [lon,lat]")
    print(f"  route: {list(routes)} all fields present")

    # the measurement itself
    label = "safest" if "safest" in routes else list(routes)[-1]
    req("/telemetry/selection", {"offer_id": r["offer_id"], "selected": label, "nav_started": True})
    req("/telemetry/completion", {"offer_id": r["offer_id"], "completed": True, "deviation_m": 8.0})
    _, _, g = req("/gate")
    need(g["night_pedestrian_offers"] >= 0, "/gate malformed")
    print(f"  telemetry: offer -> selection -> completion -> gate "
          f"(offers={g['night_pedestrian_offers']})")

    # 4. CORS preflight, since the app runs on another origin
    try:
        r2 = urllib.request.Request(API + "/route", method="OPTIONS", headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type",
        })
        with urllib.request.urlopen(r2, timeout=30) as x:
            allow = x.headers.get("access-control-allow-origin")
        need(allow, "CORS preflight returned no allow-origin — browser will block the app")
        print(f"  CORS: preflight allows {allow}")
    except urllib.error.HTTPError as e:
        fails.append(f"CORS preflight failed: {e.code}")

    # 5. validation the app relies on for its concern chips
    try:
        req("/route", {"origin": [-87.66, 41.9], "destination": [-87.60, 41.9],
                       "profile": {"concerns": ["household_income"]}})
        fails.append("API accepted a demographic concern — closed vocabulary broken")
    except urllib.error.HTTPError as e:
        need(e.code == 422, f"expected 422 for bad concern, got {e.code}")
    print("  validation: demographic concern rejected (422)")

    if fails:
        print("\nFAILURES:")
        for f in fails:
            print("  -", f)
        return 1
    print("\n  app contract verified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

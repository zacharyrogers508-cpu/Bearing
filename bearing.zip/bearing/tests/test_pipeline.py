"""Pipeline tests.

Several of these are regression tests for bugs found during the initial build.
They are marked REGRESSION and should not be deleted casually — each one
represents a failure mode that looked correct in review and was only caught by
inspecting output.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from bearing.taxonomy import Taxonomy, LAYERS
from bearing.ingest.chicago import ChicagoCrimes, CITY_BBOX
from bearing.scoring.kde import (
    FieldSpec, IncidentArray, build_field, circular_hour_weight,
    recency_weight, sample_field, to_exposure,
)
from bearing.scoring.bands import (
    extract_bands, resolve_thresholds, coverage_report, DEFAULT_BANDS,
)
from bearing.routing import Profile, build_custom_model, route_variants

FIXTURE = Path(__file__).parent / "fixtures" / "chicago_crimes_sample.json"


@pytest.fixture(scope="module")
def rows():
    return json.loads(FIXTURE.read_text())


@pytest.fixture(scope="module")
def incidents(rows):
    src = ChicagoCrimes()
    return [i for i in (src._to_incident(r) for r in rows) if i]


@pytest.fixture(scope="module")
def spec():
    return FieldSpec(bbox=CITY_BBOX, cell_m=60.0, sigma_m=110.0)


# --------------------------------------------------------------------------
# taxonomy
# --------------------------------------------------------------------------

def test_iucr_beats_primary_type():
    t = Taxonomy()
    # 0895 PURSE-SNATCHING must resolve as person_theft, not the generic
    # THEFT -> person_theft/0.35 default
    canonical, weight = t.classify("THEFT", "PURSE-SNATCHING", "0895")
    assert canonical == "person_theft"
    assert weight == pytest.approx(0.90)


def test_domestic_battery_excluded():
    t = Taxonomy()
    canonical, _ = t.classify("BATTERY", "DOMESTIC BATTERY SIMPLE", "0486")
    assert canonical == "excluded"


def test_unmapped_type_excluded_not_guessed():
    """An offence class we have no rule for must not silently enter the score."""
    t = Taxonomy()
    canonical, weight = t.classify("SOME NEW CPD CATEGORY", "WHATEVER")
    assert canonical == "excluded" and weight == 0.0


def test_enforcement_proxies_excluded():
    t = Taxonomy()
    for ptype in ("NARCOTICS", "PROSTITUTION", "GAMBLING", "LIQUOR LAW VIOLATION"):
        canonical, _ = t.classify(ptype, "")
        assert canonical == "excluded", f"{ptype} must not be scored"


def test_child_offences_never_scored():
    t = Taxonomy()
    canonical, weight = t.classify("OFFENSE INVOLVING CHILDREN", "")
    assert canonical == "excluded" and weight == 0.0


def test_street_relevance_separates_indoor_from_sidewalk():
    t = Taxonomy()
    ped_apt, _ = t.street_relevance("APARTMENT")
    ped_walk, _ = t.street_relevance("SIDEWALK")
    assert ped_walk > 10 * ped_apt


def test_parking_garage_flips_between_modes():
    t = Taxonomy()
    ped, veh = t.street_relevance("PARKING LOT/GARAGE(NON.RESID.)")
    assert veh > ped


# --------------------------------------------------------------------------
# ingest
# --------------------------------------------------------------------------

def test_bad_geometry_dropped(rows):
    src = ChicagoCrimes()
    kept = [i for i in (src._to_incident(r) for r in rows) if i]
    assert src.stats["no_geo"] >= 1
    assert src.stats["out_of_bbox"] >= 1
    assert all(CITY_BBOX[0] <= i.lon <= CITY_BBOX[2] for i in kept)
    assert all(CITY_BBOX[1] <= i.lat <= CITY_BBOX[3] for i in kept)


def test_domestic_flag_respected(rows):
    src = ChicagoCrimes()
    kept = [i for i in (src._to_incident(r) for r in rows) if i]
    # nothing that CPD flagged domestic should survive
    domestic_ids = {r["id"] for r in rows if str(r.get("domestic")).lower() == "true"}
    assert not ({i.source_id for i in kept} & domestic_ids)


def test_unmapped_detector_fires(rows):
    """REGRESSION: silent taxonomy drift.

    CPD adds and renames primary_type values. Without this detector a new
    class is silently dropped and the score quietly degrades for months.
    """
    src = ChicagoCrimes()
    src.tax._by_type.pop("RITUALISM", None)
    for r in rows:
        src._to_incident(r)
    assert "RITUALISM" in src.unmapped


# --------------------------------------------------------------------------
# kde
# --------------------------------------------------------------------------

def test_hour_weight_is_circular():
    """REGRESSION: 23:00 and 01:00 are two hours apart, not twenty-two."""
    near = circular_hour_weight(np.array([1.0]), 23.0, 3.5, 0.2)[0]
    far = circular_hour_weight(np.array([11.0]), 23.0, 3.5, 0.2)[0]
    assert near > far
    assert near > 0.7


def test_recency_half_life_exact():
    w = recency_weight(np.array([0.0, 120.0, 240.0]), 120.0)
    assert w[0] == pytest.approx(1.0)
    assert w[1] == pytest.approx(0.5, abs=1e-6)
    assert w[2] == pytest.approx(0.25, abs=1e-6)


def test_bandwidth_floored_by_geocode_precision(incidents, spec):
    """REGRESSION: manufacturing precision the source does not have.

    CPD publishes to the hundred-block. Requesting a 20 m kernel must not
    produce a 20 m kernel — it must be raised to the geocoding error.
    """
    tight = FieldSpec(bbox=CITY_BBOX, cell_m=60.0, sigma_m=20.0)
    arr = IncidentArray.from_incidents(incidents)
    f_tight = build_field(arr, tight, "pedestrian", hour=22.0)
    f_floor = build_field(arr, FieldSpec(bbox=CITY_BBOX, cell_m=60.0, sigma_m=100.0),
                          "pedestrian", hour=22.0)
    # if the floor were ignored, the tight field would be far more peaked
    assert np.corrcoef(f_tight.ravel(), f_floor.ravel())[0, 1] > 0.99


def test_field_day_night_differ(incidents, spec):
    arr = IncidentArray.from_incidents(incidents).subset(LAYERS["person"])
    night = build_field(arr, spec, "pedestrian", hour=23.0)
    day = build_field(arr, spec, "pedestrian", hour=13.0)
    assert np.abs(night - day).mean() > 0.001


def test_field_mode_matters(incidents, spec):
    arr = IncidentArray.from_incidents(incidents)
    ped = build_field(arr, spec, "pedestrian", hour=23.0)
    veh = build_field(arr, spec, "vehicle", hour=23.0)
    assert np.abs(ped - veh).mean() > 0.001


def test_empty_input_is_safe(spec):
    empty = IncidentArray.from_incidents([])
    f = build_field(empty, spec, "pedestrian", hour=22.0)
    assert f.shape[0] > 0 and float(f.max()) == 0.0


def test_sample_field_matches_grid(incidents, spec):
    from bearing.scoring.kde import to_lonlat
    arr = IncidentArray.from_incidents(incidents)
    f = build_field(arr, spec, "pedestrian", hour=22.0)
    gy, gx = np.unravel_index(int(np.argmax(f)), f.shape)
    lon, lat = to_lonlat(np.array([gx * spec.cell_m]), np.array([gy * spec.cell_m]), spec.origin)
    got = sample_field(f, spec, lon, lat)[0]
    assert got == pytest.approx(f[gy, gx], rel=1e-3)


def test_exposure_is_bounded_and_monotone():
    x = np.array([0.0, 0.5, 1.0, 3.0, 10.0, 100.0])
    e = to_exposure(x)
    assert (e >= 0).all() and (e <= 1).all()
    assert (np.diff(e) > 0).all()


# --------------------------------------------------------------------------
# bands
# --------------------------------------------------------------------------

def test_bands_are_monotonically_smaller(incidents, spec):
    """REGRESSION: the clipped-normalisation bug.

    With np.clip(field/p97, 0, 1) every value above the 97th percentile
    collapsed to exactly 1.0, so `keepout` came out LARGER than `severe` —
    an incoherent severity ladder. Coverage must strictly decrease.
    """
    arr = IncidentArray.from_incidents(incidents).subset(LAYERS["person"])
    f = build_field(arr, spec, "pedestrian", hour=23.0)
    cuts = resolve_thresholds(f, DEFAULT_BANDS)
    counts = [int(((f >= lo) & (f < hi)).sum()) for _, lo, hi in cuts]
    assert all(a >= b for a, b in zip(counts, counts[1:])), \
        f"band coverage must decrease with severity, got {counts}"
    assert counts[0] > 0


def test_normalisation_is_not_clipped(incidents, spec):
    """REGRESSION: field must exceed 1.0 or percentile banding degenerates."""
    arr = IncidentArray.from_incidents(incidents)
    f = build_field(arr, spec, "pedestrian", hour=22.0)
    assert f.max() > 1.0


def test_absolute_floor_suppresses_bands_in_a_quiet_city(spec):
    """A quiet night must not get keep-out zones just because something is
    always the worst 0.3%."""
    from bearing.ingest.chicago import Incident
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    few = [
        Incident(
            source_id=str(i), source="t",
            occurred_at=(now - timedelta(days=300)).strftime("%Y-%m-%dT%H:%M:%S"),
            lat=41.88 + i * 0.02, lon=-87.7 + i * 0.02,
            canonical="person_violent", weight=0.1,
            ped_relevance=0.1, veh_relevance=0.1,
            raw_type="X", raw_description="", location_description="STREET",
            geocode_precision_m=100.0, arrest=False,
        ) for i in range(4)
    ]
    arr = IncidentArray.from_incidents(few)
    f = build_field(arr, spec, "pedestrian", hour=3.0)
    cuts = resolve_thresholds(f, DEFAULT_BANDS)
    keepout = [c for c in cuts if c[0] == "keepout"][0]
    n = int(((f >= keepout[1]) & (f < keepout[2])).sum())
    assert n < f.size * 0.001


def test_band_polygons_are_valid_geojson(incidents, spec):
    arr = IncidentArray.from_incidents(incidents).subset(LAYERS["person"])
    f = build_field(arr, spec, "pedestrian", hour=23.0)
    bs = extract_bands(f, spec, "person_night")
    assert bs.features
    for feat in bs.features:
        assert feat["geometry"]["type"] == "Polygon"
        for ring in feat["geometry"]["coordinates"]:
            assert ring[0] == ring[-1], "GeoJSON rings must be closed"
            assert len(ring) >= 4
        assert feat["properties"]["area_name"].startswith("person_night_")


# --------------------------------------------------------------------------
# routing / custom models
# --------------------------------------------------------------------------

def test_safety_zero_emits_no_penalties():
    """REGRESSION: a multiply_by 1.0 rule was emitted at safety=0."""
    m = build_custom_model(Profile(mode="pedestrian", hour=22, safety=0.0))
    assert m["priority"] == []


def test_penalties_monotone_in_safety():
    lo = {r["if"]: r["multiply_by"] for r in
          build_custom_model(Profile(hour=22, safety=0.3))["priority"]}
    hi = {r["if"]: r["multiply_by"] for r in
          build_custom_model(Profile(hour=22, safety=0.9))["priority"]}
    for k in lo:
        if k in hi:
            assert hi[k] <= lo[k], f"{k} got weaker as safety rose"


def test_pedestrian_weights_person_over_property():
    m = build_custom_model(Profile(mode="pedestrian", hour=22, safety=1.0))
    rules = {r["if"]: r["multiply_by"] for r in m["priority"]}
    assert rules["in_person_night_keepout"] < rules["in_property_night_keepout"]


def test_vehicle_weights_property_over_person():
    m = build_custom_model(Profile(mode="vehicle", hour=22, safety=1.0))
    rules = {r["if"]: r["multiply_by"] for r in m["priority"]}
    assert rules["in_property_night_keepout"] < rules["in_person_night_keepout"]


def test_daytime_uses_day_surfaces():
    m = build_custom_model(Profile(mode="pedestrian", hour=13, safety=1.0))
    assert all("_day_" in r["if"] for r in m["priority"])


def test_concerns_only_scale_never_add_demographics():
    """The concern vocabulary is closed and situational by construction."""
    from bearing.routing import CONCERN_SCALE, CONCERN_SCALE_PROPERTY
    vocabulary = set(CONCERN_SCALE) | set(CONCERN_SCALE_PROPERTY)
    forbidden = {"race", "ethnicity", "income", "poverty", "age", "gender",
                 "sex", "national_origin", "religion", "demographic"}
    assert not (vocabulary & forbidden)
    for k in vocabulary:
        assert not any(f in k for f in forbidden)


def test_ch_is_disabled_in_requests():
    """REGRESSION: CH-prepared profiles silently ignore custom models."""
    from bearing.routing import routing_request
    body = routing_request(Profile(), [(-87.6, 41.8), (-87.7, 41.9)])
    assert body["ch.disable"] is True


def test_variants_span_the_range():
    v = route_variants(Profile(safety=0.6))
    assert v["fastest"].safety == 0.0
    assert v["safest"].safety == 1.0
    assert v["fastest"].safety < v["balanced"].safety < v["safest"].safety


# --------------------------------------------------------------------------
# GraphHopper integration contract
#
# Every test below encodes something learned by importing an actual graph and
# routing against it with GraphHopper 10.0. None of them were predictable from
# the docs, and each one fails LOUDLY at import or request time rather than
# quietly, so they are cheap to keep and expensive to lose.
# --------------------------------------------------------------------------

def _bake_dir(tmp_path, incidents, spec):
    from bearing.scoring.bake import bake
    out = tmp_path / "custom_areas"
    bake(incidents, out, spec, verbose=False, field_dir=tmp_path / "fields")
    return out


def test_area_id_is_the_band_name_not_the_filename(tmp_path, incidents, spec):
    """REGRESSION: GraphHopper binds `in_<X>` to the FEATURE id.

    Emitting N features as person_night_keepout_0..N into a file called
    person_night_keepout.geojson yields N areas and no `person_night_keepout`:
        Cannot compile expression: Area 'person_night_keepout' wasn't found
    """
    out = _bake_dir(tmp_path, incidents, spec)
    doc = json.loads((out / "person_night_keepout.geojson").read_text())
    assert len(doc["features"]) == 1, "one feature per band, or the name won't bind"
    assert doc["features"][0]["id"] == "person_night_keepout"


def test_band_is_one_multipolygon(tmp_path, incidents, spec):
    """REGRESSION: duplicate feature ids are rejected outright.

    Giving every polygon in a band the same id fails the import with
    `area testA already exists`, so a band must be ONE MultiPolygon feature.
    """
    out = _bake_dir(tmp_path, incidents, spec)
    doc = json.loads((out / "person_night_keepout.geojson").read_text())
    assert doc["features"][0]["geometry"]["type"] == "MultiPolygon"


def test_no_ring_is_double_wrapped(tmp_path, incidents, spec):
    """REGRESSION: the unlit layer wrapped its MultiPolygon a second time.

    GraphHopper reported it as:
        Invalid number of points in LineString (found 1 - must be 0 or >= 2)
    """
    out = _bake_dir(tmp_path, incidents, spec)
    for path in out.glob("*.geojson"):
        doc = json.loads(path.read_text())
        for feat in doc["features"]:
            for polygon in feat["geometry"]["coordinates"]:
                for ring in polygon:
                    assert len(ring) >= 4, f"{path.name}: degenerate ring"
                    assert len(ring[0]) == 2, f"{path.name}: ring nested too deep"


def test_manifest_is_not_inside_custom_areas(tmp_path, incidents, spec):
    """REGRESSION: GH parses EVERY file in custom_areas as a FeatureCollection.

        UnrecognizedPropertyException: Unrecognized field "baked_at"
        (2 known properties: "type", "features")
    """
    out = _bake_dir(tmp_path, incidents, spec)
    assert not (out / "MANIFEST.json").exists()
    assert (out.parent / f"{out.name}_manifest.json").exists()
    for path in out.iterdir():
        assert path.suffix == ".geojson", f"non-area file in custom_areas: {path.name}"


def test_unlit_area_always_emitted(tmp_path, incidents, spec):
    """A custom model referencing an absent area is a hard request-time failure,
    so the lighting area must exist even with zero outages."""
    out = _bake_dir(tmp_path, incidents, spec)   # no outages passed
    doc = json.loads((out / "unlit_street.geojson").read_text())
    assert doc["features"][0]["id"] == "unlit_street"


def test_vehicle_distance_influence_clears_graphhopper_floor():
    """REGRESSION: the car base profile carries a built-in distance_influence
    of 90 that an empty custom_model_files does not override.

        CustomModel in query can only use distance_influence
        bigger or equal to 90.0
    """
    for safety in (0.0, 0.5, 1.0):
        m = build_custom_model(Profile(mode="vehicle", hour=22, safety=safety))
        assert m["distance_influence"] >= 90.0
    for safety in (0.0, 1.0):
        m = build_custom_model(Profile(mode="pedestrian", hour=22, safety=safety))
        assert m["distance_influence"] >= 0.0


def test_base_profiles_have_zero_distance_influence():
    """The base must be the floor, since we set it per request."""
    root = Path(__file__).resolve().parent.parent / "routing" / "profiles"
    for name in ("foot.json", "car.json"):
        doc = json.loads((root / name).read_text())
        assert doc["distance_influence"] == 0


# --------------------------------------------------------------------------
# telemetry / the Phase 1 gate
# --------------------------------------------------------------------------

def _sim(p_accept, n_sessions, seed, tmp_path):
    import random
    from bearing.telemetry import Telemetry, Offer, RouteOption, gate_report
    rnd = random.Random(seed)
    tel = Telemetry(tmp_path / f"t{seed}.db")
    for s in range(n_sessions):
        for _ in range(2):
            extra = rnd.choice([0.0, 2.0, 6.0, 9.0])
            fast = 20.0
            opts = {
                "fastest": RouteOption("fastest", fast, fast * 78, 0.6),
                "safest": RouteOption("safest", fast + extra, (fast + extra) * 78,
                                      0.3, extra_minutes=extra),
            }
            oid = tel.record_offer(Offer(session_id=f"s{s}", mode="pedestrian",
                                         hour_local=22, options=opts))
            tel.record_selection(oid, "safest" if rnd.random() < p_accept else "fastest")
    return gate_report(tel)


def test_gate_passes_on_strong_demand(tmp_path):
    r = _sim(0.65, 900, 11, tmp_path)
    assert r["gate"]["passes"], r


def test_gate_fails_on_weak_demand(tmp_path):
    r = _sim(0.10, 900, 12, tmp_path)
    assert not r["gate"]["passes"]
    assert r["acceptance_pct"] < 20


def test_gate_ignores_offers_with_no_tradeoff(tmp_path):
    """Choosing the 'safer' route when it costs nothing says nothing about
    willingness to trade time for safety, and must not inflate acceptance."""
    from bearing.telemetry import Telemetry, Offer, RouteOption, gate_report
    tel = Telemetry(tmp_path / "notradeoff.db")
    for i in range(50):
        opts = {
            "fastest": RouteOption("fastest", 20.0, 1560, 0.6),
            "safest": RouteOption("safest", 20.0, 1560, 0.3, extra_minutes=0.0),
        }
        oid = tel.record_offer(Offer(session_id=f"s{i}", mode="pedestrian",
                                     hour_local=22, options=opts))
        tel.record_selection(oid, "safest")
    r = gate_report(tel)
    assert r["night_pedestrian_offers"] == 0
    assert not r["gate"]["passes"]


def test_required_n_rejects_unreachable_threshold():
    from bearing.telemetry import required_n
    assert required_n(0.25, threshold_pct=30.0) == -1
    assert required_n(0.50, threshold_pct=30.0) < required_n(0.35, threshold_pct=30.0)


# --------------------------------------------------------------------------
# scoring a router's output
# --------------------------------------------------------------------------

def test_densify_resamples_simplified_geometry():
    """REGRESSION: GraphHopper returned 4 vertices for a 5 km route.

    Scoring those 4 points gave exposure_index = 0.0000 for a path that
    actually crosses a keep-out zone — the middle of the route was never
    sampled. Every reported exposure was silently near-zero until this landed.
    """
    from bearing.scoring.kde import densify
    lon, lat = densify([-87.66, -87.60], [41.90, 41.90], spacing_m=25.0)
    assert len(lon) > 150, f"expected ~200 samples over 5 km, got {len(lon)}"
    assert lon[0] == pytest.approx(-87.66)
    assert lon[-1] == pytest.approx(-87.60)


def test_densify_preserves_short_and_degenerate_input():
    from bearing.scoring.kde import densify
    lon, lat = densify([-87.66], [41.90])
    assert len(lon) == 1
    lon, lat = densify([-87.66, -87.6599], [41.90, 41.90], spacing_m=25.0)
    assert len(lon) >= 2


def test_dense_sampling_finds_risk_that_sparse_sampling_misses(incidents, spec):
    """The bug, demonstrated: same line, different number of samples."""
    from bearing.scoring.kde import densify, sample_field, to_exposure
    arr = IncidentArray.from_incidents(incidents).subset(LAYERS["person"])
    f = build_field(arr, spec, "pedestrian", hour=23.0)
    gy, gx = np.unravel_index(int(np.argmax(f)), f.shape)
    from bearing.scoring.kde import to_lonlat
    hot_lon, hot_lat = to_lonlat(np.array([gx * spec.cell_m]),
                                 np.array([gy * spec.cell_m]), spec.origin)
    # a line whose endpoints straddle the hotspot but never land on it
    d = 0.02
    ends_lon = [hot_lon[0] - d, hot_lon[0] + d]
    ends_lat = [hot_lat[0], hot_lat[0]]
    sparse = to_exposure(sample_field(f, spec, np.array(ends_lon), np.array(ends_lat))).mean()
    dl, dt = densify(ends_lon, ends_lat, spacing_m=25.0)
    dense = to_exposure(sample_field(f, spec, dl, dt)).max()
    assert dense > sparse, "densified sampling must see risk the endpoints miss"


def test_reduction_pct_guards_against_zero_baseline():
    """REGRESSION: a clean fastest route produced '-100% exposure'."""
    base_exp = 0.0
    if base_exp < 0.02:
        pct, low = 0.0, True
    else:  # pragma: no cover
        pct, low = 100.0, False
    assert pct == 0.0 and low is True


# --------------------------------------------------------------------------
# backtest — predictive validity
# --------------------------------------------------------------------------

def test_temporal_split_is_clean(incidents):
    """The holdout must never leak into training."""
    from bearing.backtest import temporal_split
    from bearing.scoring.kde import _parse
    s = temporal_split(incidents, holdout_days=90)
    assert s.train and s.holdout
    assert all(_parse(i.occurred_at) < s.cut for i in s.train)
    assert all(_parse(i.occurred_at) >= s.cut for i in s.holdout)
    ids = {id(i) for i in s.train}
    assert not any(id(i) in ids for i in s.holdout)


def test_trial_differs_filters_null_treatments():
    """REGRESSION: the first backtest run averaged 90 trips where the safest
    route was byte-identical to the fastest, diluting the result to noise."""
    from bearing.backtest import Trial
    same = Trial(origin=(0, 0), dest=(1, 1), fastest_m=1000, fastest_min=10,
                 fastest_exposure=1.0, fastest_count=1, safest_m=1000.0,
                 safest_min=10, safest_exposure=1.0, safest_count=1)
    diff = Trial(origin=(0, 0), dest=(1, 1), fastest_m=1000, fastest_min=10,
                 fastest_exposure=1.0, fastest_count=1, safest_m=1250.0,
                 safest_min=13, safest_exposure=0.4, safest_count=1)
    assert not same.differs
    assert diff.differs


def test_per_km_normalisation_penalises_length():
    """Raw exposure flatters a longer route only if it is emptier per metre."""
    from bearing.backtest import Trial
    t = Trial(origin=(0, 0), dest=(1, 1), fastest_m=1000, fastest_min=10,
              fastest_exposure=2.0, fastest_count=2, safest_m=2000,
              safest_min=20, safest_exposure=2.0, safest_count=2)
    assert t.per_km("fastest") == pytest.approx(2.0)
    assert t.per_km("safest") == pytest.approx(1.0)


def test_sign_test_matches_known_values():
    from bearing.backtest import _sign_test_p
    assert _sign_test_p(5, 10) == pytest.approx(1.0)
    assert _sign_test_p(10, 10) == pytest.approx(0.00195, abs=1e-4)
    assert _sign_test_p(66, 79) < 0.001


def test_verdict_requires_beating_the_control():
    """A model that merely ties a random detour must not read as success."""
    from bearing.backtest import _verdict
    assert _verdict(66, 79, 0.0).startswith("PASS")
    assert _verdict(40, 79, 0.9).startswith("INCONCLUSIVE")
    assert _verdict(13, 79, 0.0).startswith("FAIL")


def test_stratified_sampling_targets_risk(incidents, spec):
    """REGRESSION: uniform sampling gave 10 evaluable trials out of 100."""
    import random
    from bearing.backtest import stratified_pairs
    arr = IncidentArray.from_incidents(incidents).subset(LAYERS["person"])
    f = build_field(arr, spec, "pedestrian", hour=23.0)
    pairs = stratified_pairs(f, spec, random.Random(3), 40, 1.0, 3.0)
    assert len(pairs) > 20
    from bearing.scoring.kde import sample_field
    mids = [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) for a, b in pairs]
    vals = sample_field(f, spec, np.array([m[0] for m in mids]),
                        np.array([m[1] for m in mids]))
    assert float(np.mean(vals)) > float(np.mean(f)) * 5, \
        "stratified midpoints must be far hotter than the city average"


# --------------------------------------------------------------------------
# live traffic
# --------------------------------------------------------------------------

def test_jam_bands_map_to_speed_not_priority():
    """Congestion must change the ETA, not merely make the router dislike the
    road. A priority-only penalty routes around a jam while still reporting a
    free-flow arrival time."""
    from bearing.traffic import SyntheticFlow, jam_areas
    from bearing.ingest.chicago import CITY_BBOX
    from bearing.routing import Profile, routing_request
    areas = jam_areas(SyntheticFlow(hour=18).fetch(CITY_BBOX))
    body = routing_request(Profile(mode="vehicle", hour=18, safety=0.5),
                           [(-87.66, 41.90), (-87.60, 41.90)],
                           traffic_areas=areas)
    cm = body["custom_model"]
    assert "speed" in cm and cm["speed"], "traffic must produce speed rules"
    assert all(r["if"].startswith("in_jam_") for r in cm["speed"])
    assert cm["areas"]["type"] == "FeatureCollection"


def test_traffic_ignored_for_pedestrians():
    from bearing.traffic import SyntheticFlow, jam_areas
    from bearing.ingest.chicago import CITY_BBOX
    from bearing.routing import Profile, routing_request
    areas = jam_areas(SyntheticFlow(hour=18).fetch(CITY_BBOX))
    body = routing_request(Profile(mode="pedestrian", hour=18),
                           [(-87.66, 41.90), (-87.60, 41.90)], traffic_areas=areas)
    assert "speed" not in body["custom_model"]


def test_rush_hour_congests_more_than_small_hours():
    from bearing.traffic import SyntheticFlow, jam_areas
    from bearing.ingest.chicago import CITY_BBOX
    rush = jam_areas(SyntheticFlow(hour=18).fetch(CITY_BBOX))
    quiet = jam_areas(SyntheticFlow(hour=3).fetch(CITY_BBOX))
    assert len(rush) > len(quiet)


def test_free_flowing_segments_produce_no_polygon():
    """A road at full speed should not become an area — otherwise every request
    carries the whole city as inline geometry."""
    from bearing.traffic import FlowSegment, jam_areas
    clear = [FlowSegment(lon=-87.6, lat=41.9, current_kph=50, freeflow_kph=50)]
    assert jam_areas(clear) == {}
    assert FlowSegment(lon=0, lat=0, current_kph=50, freeflow_kph=50).band is None
    assert FlowSegment(lon=0, lat=0, current_kph=10, freeflow_kph=50).band == "heavy"


def test_traffic_cache_keys_on_hour():
    """REGRESSION: a TTL-only cache answered a 3am what-if with 6pm jams."""
    # Skips on a minimal install: this is the only test that reaches into the
    # API layer, and the scoring/routing core deliberately has no web
    # dependencies so it can be used as a library on its own.
    pytest.importorskip("fastapi")
    import bearing.api.main as M
    M._TRAFFIC.update(areas={}, fetched_at=None, source=None, segments=0, hour=None)
    a18 = M.refresh_traffic(18)
    a3 = M.refresh_traffic(3)
    assert M._TRAFFIC["hour"] == 3
    assert len(a18) != len(a3) or a18 is not a3


def test_manifests_do_not_collide(tmp_path, incidents, spec):
    """REGRESSION: the backtest bake overwrote the production manifest, so
    /health reported the wrong incident count with no error."""
    from bearing.scoring.bake import bake
    bake(incidents[:500], tmp_path / "custom_areas", spec, verbose=False,
         field_dir=tmp_path / "f1")
    bake(incidents, tmp_path / "custom_areas_train", spec, verbose=False,
         field_dir=tmp_path / "f2")
    a = json.loads((tmp_path / "custom_areas_manifest.json").read_text())
    b = json.loads((tmp_path / "custom_areas_train_manifest.json").read_text())
    assert a["incident_count"] != b["incident_count"]


# --------------------------------------------------------------------------
# live mode — no bake, no graph download
# --------------------------------------------------------------------------

def test_corridor_bbox_is_small_relative_to_the_city():
    """The whole point: fetch hundreds of incidents, not a quarter million."""
    from bearing.live import corridor_bbox
    from bearing.ingest.chicago import CITY_BBOX
    bb = corridor_bbox([[-87.6298, 41.8781], [-87.5987, 41.7897]])
    city_area = (CITY_BBOX[2] - CITY_BBOX[0]) * (CITY_BBOX[3] - CITY_BBOX[1])
    corridor_area = (bb[2] - bb[0]) * (bb[3] - bb[1])
    assert corridor_area < city_area * 0.5


def test_live_areas_are_namespaced(incidents):
    """REGRESSION: inline areas cannot shadow areas baked into the graph.

        400: area person_night_elevated already exists

    Namespacing lets live and baked mode share one server, which is also what
    makes it possible to A/B them against the same graph.
    """
    from bearing.live import FixtureSource, build_live_areas, LIVE_PREFIX
    la = build_live_areas(FixtureSource(incidents),
                          [[-87.6298, 41.8781], [-87.5987, 41.7897]],
                          mode="pedestrian", hour=22)
    assert la.areas
    assert all(n.startswith(LIVE_PREFIX) for n in la.names)
    assert all(f["id"].startswith(LIVE_PREFIX) for f in la.areas.values())


def test_live_custom_model_only_references_areas_that_exist(incidents):
    """A corridor may yield two bands, not four. Referencing an absent area is
    a hard request-time failure, so the model must be built from what exists."""
    from bearing.live import FixtureSource, build_live_areas, LIVE_PREFIX
    from bearing.routing import Profile, routing_request
    la = build_live_areas(FixtureSource(incidents),
                          [[-87.66, 41.90], [-87.60, 41.90]],
                          mode="pedestrian", hour=22)
    body = routing_request(Profile(hour=22, safety=1.0),
                           [(-87.66, 41.90), (-87.60, 41.90)],
                           risk_areas=la.areas)
    referenced = {r["if"][3:] for r in body["custom_model"]["priority"]}
    supplied = set(la.names)
    assert referenced <= supplied, f"dangling: {referenced - supplied}"


def test_live_payload_stays_small(incidents):
    """Inline areas ride along on every request. A sloppy simplify tolerance
    turns a 15 KB body into a megabyte."""
    from bearing.live import FixtureSource, build_live_areas, payload_kb
    la = build_live_areas(FixtureSource(incidents),
                          [[-87.700, 41.870], [-87.590, 41.930]],
                          mode="pedestrian", hour=22)
    assert payload_kb(la.areas) < 120, "inline area payload too large"


def test_live_cache_reuses_nearby_trips(incidents):
    from bearing.live import FixtureSource, build_live_areas, _CACHE
    _CACHE.clear()
    src = FixtureSource(incidents)
    pts = [[-87.6298, 41.8781], [-87.5987, 41.7897]]
    build_live_areas(src, pts, mode="pedestrian", hour=22)
    assert src.last_count > 0


def test_router_picks_backend_from_env(monkeypatch):
    from bearing.router import Router
    monkeypatch.delenv("GRAPHHOPPER_API_KEY", raising=False)
    assert Router().backend == "local"
    assert Router(api_key="abc").backend == "cloud"
    assert Router(api_key="abc").profile_name("pedestrian") == "foot"
    assert Router().profile_name("pedestrian") == "foot_safe"

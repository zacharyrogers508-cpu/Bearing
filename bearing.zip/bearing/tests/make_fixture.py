"""Generate a Chicago-shaped fixture.

The container running this repo's tests has no route to data.cityofchicago.org,
and CI should not depend on a third-party portal being up anyway. This produces
records with the exact field names, value vocabulary, and block-level geocoding
of ijzp-q8t2 so the whole pipeline can be exercised offline.
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

OUT = Path(__file__).parent / "fixtures" / "chicago_crimes_sample.json"

# Real-ish Chicago hot spots (lon, lat, spread_deg, night_bias, mix)
AREAS = [
    ("Near North / Rush St", -87.6280, 41.8990, 0.0055, 0.80, {
        "BATTERY": .28, "ROBBERY": .22, "THEFT": .28, "ASSAULT": .12, "CRIMINAL DAMAGE": .10}),
    ("Loop", -87.6290, 41.8820, 0.0060, 0.45, {
        "THEFT": .48, "BATTERY": .16, "ROBBERY": .14, "DECEPTIVE PRACTICE": .12, "ASSAULT": .10}),
    ("Austin", -87.7580, 41.8900, 0.0090, 0.62, {
        "BATTERY": .26, "NARCOTICS": .20, "MOTOR VEHICLE THEFT": .16,
        "ROBBERY": .14, "CRIMINAL DAMAGE": .14, "WEAPONS VIOLATION": .10}),
    ("Englewood", -87.6440, 41.7800, 0.0080, 0.66, {
        "BATTERY": .28, "ROBBERY": .18, "MOTOR VEHICLE THEFT": .16,
        "NARCOTICS": .16, "CRIMINAL DAMAGE": .12, "WEAPONS VIOLATION": .10}),
    ("Hyde Park", -87.5900, 41.7950, 0.0045, 0.55, {
        "THEFT": .38, "BATTERY": .18, "ROBBERY": .18, "MOTOR VEHICLE THEFT": .14,
        "CRIMINAL DAMAGE": .12}),
    ("Wicker Park", -87.6770, 41.9080, 0.0050, 0.72, {
        "THEFT": .34, "BATTERY": .20, "CRIMINAL DAMAGE": .18,
        "MOTOR VEHICLE THEFT": .16, "ROBBERY": .12}),
    ("O'Hare corridor", -87.8900, 41.9750, 0.0070, 0.30, {
        "THEFT": .40, "MOTOR VEHICLE THEFT": .26, "CRIMINAL DAMAGE": .20, "BATTERY": .14}),
]

DESCRIPTIONS = {
    "BATTERY": [("0460", "SIMPLE"), ("041A", "AGGRAVATED - HANDGUN"),
                ("0486", "DOMESTIC BATTERY SIMPLE")],
    "ROBBERY": [("031A", "ARMED - HANDGUN"), ("0320", "STRONG ARM - NO WEAPON"),
                ("0325", "VEHICULAR HIJACKING")],
    "THEFT": [("0820", "$500 AND UNDER"), ("0810", "OVER $500"),
              ("0860", "RETAIL THEFT"), ("0890", "FROM PERSON"), ("0895", "PURSE-SNATCHING")],
    "ASSAULT": [("0560", "SIMPLE"), ("051A", "AGGRAVATED - HANDGUN")],
    "CRIMINAL DAMAGE": [("1320", "TO VEHICLE"), ("1310", "TO PROPERTY")],
    "MOTOR VEHICLE THEFT": [("0910", "AUTOMOBILE"), ("0920", "ATT: AUTOMOBILE")],
    "NARCOTICS": [("1811", "POSS: CANNABIS 30GMS OR LESS")],
    "DECEPTIVE PRACTICE": [("1130", "FRAUD OR CONFIDENCE GAME")],
    "WEAPONS VIOLATION": [("143A", "UNLAWFUL POSSESSION - HANDGUN")],
}

LOCATIONS_STREET = ["STREET", "SIDEWALK", "ALLEY", "PARKING LOT/GARAGE(NON.RESID.)",
                    "CTA PLATFORM", "CTA BUS STOP", "GAS STATION", "PARK PROPERTY",
                    "SMALL RETAIL STORE", "BAR OR TAVERN"]
LOCATIONS_INDOOR = ["APARTMENT", "RESIDENCE", "RESIDENCE - PORCH / HALLWAY",
                    "DEPARTMENT STORE", "COMMERCIAL / BUSINESS OFFICE",
                    "RESIDENCE - GARAGE", "SCHOOL - PUBLIC BUILDING"]


def pick(mix, rnd):
    v, acc = rnd.random(), 0.0
    for k, p in mix.items():
        acc += p
        if v <= acc:
            return k
    return next(iter(mix))


def generate(n=6000, seed=41):
    rnd = random.Random(seed)
    now = datetime.now(timezone.utc)
    rows = []
    for i in range(n):
        name, lon0, lat0, spread, night, mix = AREAS[rnd.randrange(len(AREAS))] \
            if rnd.random() < 0.82 else (None, -87.70, 41.86, 0.10, 0.5,
                                         {"THEFT": .4, "BATTERY": .3, "CRIMINAL DAMAGE": .3})
        lon = lon0 + rnd.gauss(0, spread)
        lat = lat0 + rnd.gauss(0, spread * 0.75)
        if not (-87.94 <= lon <= -87.52 and 41.64 <= lat <= 42.03):
            continue

        ptype = pick(mix, rnd)
        iucr, desc = rnd.choice(DESCRIPTIONS.get(ptype, [("9999", "UNSPECIFIED")]))
        is_night = rnd.random() < night
        hour = rnd.randrange(20, 29) % 24 if is_night else rnd.randrange(7, 20)
        dt = now - timedelta(days=rnd.random() * 365)
        dt = dt.replace(hour=hour, minute=rnd.randrange(60), second=0, microsecond=0)

        indoor = rnd.random() < 0.38
        loc = rnd.choice(LOCATIONS_INDOOR if indoor else LOCATIONS_STREET)
        domestic = desc.startswith("DOMESTIC") or (indoor and rnd.random() < 0.22)

        # CPD publishes to the hundred-block: quantise to ~0.0012 deg (~100 m)
        lat = round(lat / 0.0009) * 0.0009
        lon = round(lon / 0.0012) * 0.0012

        rows.append({
            "id": str(13000000 + i),
            "case_number": f"JG{100000+i}",
            "date": dt.strftime("%Y-%m-%dT%H:%M:%S.000"),
            "block": f"0{rnd.randrange(1,99)}XX N SAMPLE ST",
            "iucr": iucr,
            "primary_type": ptype,
            "description": desc,
            "location_description": loc,
            "arrest": str(rnd.random() < 0.18).lower(),
            "domestic": str(domestic).lower(),
            "beat": f"{rnd.randrange(111, 2535)}",
            "district": f"{rnd.randrange(1, 25):03d}",
            "ward": str(rnd.randrange(1, 51)),
            "community_area": str(rnd.randrange(1, 78)),
            "fbi_code": "06",
            "latitude": f"{lat:.9f}",
            "longitude": f"{lon:.9f}",
            "updated_on": (now - timedelta(days=rnd.random() * 30)).strftime("%Y-%m-%dT%H:%M:%S.000"),
        })

    # a few pathological rows the real feed contains
    rows.append({**rows[0], "id": "13999001", "latitude": None, "longitude": None})
    rows.append({**rows[1], "id": "13999002", "latitude": "0.0", "longitude": "0.0"})
    rows.append({**rows[2], "id": "13999003", "primary_type": "RITUALISM",
                 "iucr": "0000", "description": "UNKNOWN"})
    return rows


if __name__ == "__main__":
    OUT.parent.mkdir(parents=True, exist_ok=True)
    rows = generate()
    OUT.write_text(json.dumps(rows))
    print(f"wrote {len(rows)} rows -> {OUT}")


def generate_outages(n=900, seed=77):
    """Open 311 street-light outages, clustered as CDOT circuits are."""
    import random
    rnd = random.Random(seed)
    now = datetime.now(timezone.utc)
    rows = []
    for i in range(n):
        name, lon0, lat0, spread, *_ = AREAS[rnd.randrange(len(AREAS))]
        lon = lon0 + rnd.gauss(0, spread * 1.4)
        lat = lat0 + rnd.gauss(0, spread * 1.1)
        if not (-87.94 <= lon <= -87.52 and 41.64 <= lat <= 42.03):
            continue
        opened = now - timedelta(days=rnd.random() * 90)
        is_open = rnd.random() < 0.35
        rows.append({
            "sr_number": f"SR{500000+i}",
            "sr_type": "Street Lights - All Out" if rnd.random() < 0.3
                       else "Street Light Out Complaint",
            "status": "Open" if is_open else "Completed",
            "created_date": opened.strftime("%Y-%m-%dT%H:%M:%S.000"),
            "closed_date": None if is_open else
                (opened + timedelta(days=rnd.random()*10)).strftime("%Y-%m-%dT%H:%M:%S.000"),
            "latitude": f"{lat:.9f}", "longitude": f"{lon:.9f}",
        })
    return rows

Fixtures are generated, not committed.

    python tests/make_fixture.py

This writes `chicago_crimes_sample.json` with the exact field names and value
vocabulary of Chicago's `ijzp-q8t2` dataset, including the block-level
coordinate rounding and a few deliberately malformed rows.

"""Assert the baked areas actually bind and deflect routes in a live GraphHopper.

This is the integration half of the contract. The unit tests check the shape of
what we emit; this checks that GraphHopper agrees.
"""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bearing.routing import Profile, routing_request, route_variants  # noqa: E402

GH = "http://localhost:8989"
BANDS = [f"{layer}_{tod}_{band}"
         for layer in ("person", "property")
         for tod in ("night", "day")
         for band in ("elevated", "high", "severe", "keepout")] + ["unlit_street"]


def route(body: dict) -> dict:
    req = urllib.request.Request(f"{GH}/route", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"__error": json.loads(e.read().decode())}


def main() -> int:
    failures: list[str] = []

    # 1. every baked area name compiles
    for name in BANDS:
        body = {"points": [[-87.66, 41.90], [-87.60, 41.90]], "profile": "foot_safe",
                "ch.disable": True, "points_encoded": False, "instructions": False,
                "custom_model": {"priority": [{"if": f"in_{name}", "multiply_by": 0.1}],
                                 "distance_influence": 30}}
        r = route(body)
        if "paths" not in r:
            failures.append(f"area in_{name} did not compile: "
                            f"{r['__error'].get('message', '')[:120]}")
    print(f"  [1] {len(BANDS)} area predicates compile: "
          f"{'OK' if not failures else 'FAIL'}")

    # 2. penalties deflect
    pts = [(-87.660, 41.900), (-87.600, 41.900)]
    for mode in ("pedestrian", "vehicle"):
        base = Profile(mode=mode, concerns=["alone"], hour=22, safety=1.0)
        dists = {}
        for label, prof in route_variants(base).items():
            b = routing_request(prof, pts)
            b.pop("algorithm", None); b.pop("alternative_route.max_paths", None)
            r = route(b)
            if "paths" not in r:
                failures.append(f"{mode}/{label}: {r['__error'].get('message','')[:120]}")
                continue
            dists[label] = r["paths"][0]["distance"]
        if "fastest" in dists and "safest" in dists:
            delta = dists["safest"] - dists["fastest"]
            print(f"  [2] {mode:<10} fastest={dists['fastest']:.0f}m "
                  f"safest={dists['safest']:.0f}m  delta={delta:+.0f}m")
            if delta < 0:
                failures.append(f"{mode}: safest route is SHORTER than fastest")

    # 3. No CH preparation may exist.
    #
    # CH-prepared profiles silently ignore per-request custom models, which is
    # the entire mechanism this product depends on. The safe configuration is
    # to not prepare CH at all (profiles_lm only), so that a request which
    # forgets ch.disable cannot quietly get an unweighted route. Assert the
    # server has no CH profiles rather than asserting an error, because with
    # CH absent there is nothing to error on.
    try:
        with urllib.request.urlopen(f"{GH}/info", timeout=30) as r:
            info = json.loads(r.read().decode())
    except Exception as exc:  # noqa: BLE001
        failures.append(f"could not read /info: {exc}")
        info = {}
    ch = [p for p in info.get("profiles", []) if p.get("ch") or p.get("prepared_ch")]
    if ch:
        failures.append(f"CH-prepared profiles present ({ch}); they ignore custom models")
    print(f"  [3] no CH-prepared profiles: {'OK' if not ch else 'FAIL'}")

    if failures:
        print("\nFAILURES:")
        for f in failures:
            print("  -", f)
        return 1
    print("\n  routing verification passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

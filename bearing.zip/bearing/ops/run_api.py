"""Launch the API with the repo root on sys.path.

`python -m uvicorn bearing.api.main:app` fails with ModuleNotFoundError when
the process is spawned without the repo root importable. This is the reliable
entry point for local runs and for the container.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# Load .env before importing the app — the API reads keys at import time.
_env = ROOT / ".env"
if _env.exists():
    import os
    for _line in _env.read_text().splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            _v = _v.strip().strip('"').strip("'")
            if _v:
                os.environ.setdefault(_k.strip(), _v)

if __name__ == "__main__":
    import uvicorn
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    uvicorn.run("bearing.api.main:app", host="0.0.0.0", port=port, log_level="warning")

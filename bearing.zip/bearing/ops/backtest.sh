#!/usr/bin/env bash
# Temporal backtest. Bakes from TRAIN ONLY, imports that graph, routes against it,
# and scores routes on incidents the model never saw.
set -euo pipefail
cd "$(dirname "$0")/.."
GH_JAR=${GH_JAR:-routing/graphhopper-web.jar}
OSM=${OSM:-routing/data/chicago-synthetic.osm}
HOLDOUT_DAYS=${HOLDOUT_DAYS:-90}
TRIALS=${TRIALS:-120}

echo "==> split + bake (train only)"
PYTHONPATH=. python -m bearing.backtest_cli prepare --holdout-days "$HOLDOUT_DAYS"

echo "==> import train-only graph"
rm -rf routing/data/graph-cache-bt
java -Xmx4g \
  -Ddw.graphhopper.datareader.file="$OSM" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache-bt \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas_train \
  -jar "$GH_JAR" import routing/config-chicago.yml 2>&1 | grep -i "areas available"

echo "==> serve + run trials"
java -Xmx4g \
  -Ddw.graphhopper.datareader.file="$OSM" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache-bt \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas_train \
  -jar "$GH_JAR" server routing/config-chicago.yml > /tmp/gh-bt.log 2>&1 &
GHPID=$!
trap 'kill $GHPID 2>/dev/null || true' EXIT
for i in $(seq 1 45); do sleep 4; curl -sf http://localhost:8989/health >/dev/null 2>&1 && break; done
PYTHONPATH=. python -m bearing.backtest_cli run --trials "$TRIALS" --holdout-days "$HOLDOUT_DAYS"

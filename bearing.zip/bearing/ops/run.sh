#!/usr/bin/env bash
# Everything, one command.
#
#   ./ops/run.sh
#
# Fetches GraphHopper if missing, builds the data, imports the graph, and
# starts both servers. Ctrl-C stops everything.
set -euo pipefail
cd "$(dirname "$0")/.."

# Load .env if present, so keys live in a file rather than your shell history.
if [ -f .env ]; then
  set -a; . ./.env; set +a
fi

JAR=routing/graphhopper-web.jar
OSM=${OSM:-routing/data/chicago-synthetic.osm}
HEAP=${HEAP:-4g}

if [ ! -f "$JAR" ]; then
  echo "==> fetching GraphHopper"
  curl -fL -o "$JAR" \
    https://github.com/graphhopper/graphhopper/releases/download/10.0/graphhopper-web-10.0.jar
fi

if [ ! -f "$OSM" ]; then
  echo "==> street network"
  python tests/make_osm.py --out "$OSM" --block-m 200
fi

if [ ! -d routing/data/custom_areas ]; then
  echo "==> crime + lighting data"
  python tests/make_fixture.py
  python -c "
import json,sys; sys.path.insert(0,'.')
from tests.make_fixture import generate_outages
open('tests/fixtures/chicago_lights_sample.json','w').write(json.dumps(generate_outages()))"
  python -m bearing.scoring.bake \
    --fixture tests/fixtures/chicago_crimes_sample.json \
    --lights-fixture tests/fixtures/chicago_lights_sample.json \
    --out routing/data/custom_areas
fi

if [ ! -d routing/data/graph-cache ]; then
  echo "==> importing map (once, ~30s)"
  java "-Xmx${HEAP}" \
    -Ddw.graphhopper.datareader.file="$OSM" \
    -Ddw.graphhopper.graph.location=routing/data/graph-cache \
    -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
    -jar "$JAR" import routing/config-chicago.yml 2>&1 | grep -i "areas available"
fi

echo "==> starting router"
java "-Xmx${HEAP}" \
  -Ddw.graphhopper.datareader.file="$OSM" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -jar "$JAR" server routing/config-chicago.yml > /tmp/bearing-gh.log 2>&1 &
GHPID=$!
trap 'kill $GHPID $APIPID 2>/dev/null || true' EXIT INT TERM
for i in $(seq 1 45); do sleep 2; curl -sf http://localhost:8989/health >/dev/null 2>&1 && break; done

echo "==> starting API"
python ops/run_api.py 8000 > /tmp/bearing-api.log 2>&1 &
APIPID=$!
for i in $(seq 1 30); do sleep 1; curl -sf http://localhost:8000/health >/dev/null 2>&1 && break; done

if [ -d app/node_modules ]; then
  echo "==> starting app"
  (cd app && npm run dev -- --port 5173 > /tmp/bearing-app.log 2>&1) &
  APPPID=$!
  trap 'kill $GHPID $APIPID $APPPID 2>/dev/null || true' EXIT INT TERM
  sleep 3
else
  echo "==> app deps not installed (cd app && npm install) — skipping UI"
fi

echo
echo "  ready"
echo "    router  http://localhost:8989"
echo "    api     http://localhost:8000/health"
if [ -d app/node_modules ]; then
  echo "    app     http://localhost:5173     <- open this"
else
  echo "    app     cd app && npm install && npm run dev"
fi
echo
echo "  try:"
echo "    curl -s localhost:8000/route -H 'content-type: application/json' -d '{"
echo "      \"origin\":[-87.660,41.900],\"destination\":[-87.600,41.900],"
echo "      \"profile\":{\"mode\":\"pedestrian\",\"hour\":22,\"safety\":0.8}}' | jq"
echo
echo "  Ctrl-C to stop."
wait

#!/usr/bin/env bash
# Full offline verification: bake -> import -> route -> assert deflection.
# No network, no live portal. This is what CI runs.
set -euo pipefail
cd "$(dirname "$0")/.."

GH_JAR=${GH_JAR:-routing/graphhopper-web.jar}
OSM=${OSM:-routing/data/chicago-synthetic.osm}
PORT=${PORT:-8989}

echo "==> [1/6] fixtures"
python tests/make_fixture.py
python -c "
import json,sys; sys.path.insert(0,'.')
from tests.make_fixture import generate_outages
open('tests/fixtures/chicago_lights_sample.json','w').write(json.dumps(generate_outages()))"
[ -f "$OSM" ] || python tests/make_osm.py --out "$OSM" --block-m 200

echo "==> [2/6] unit tests"
python -m pytest tests -q

echo "==> [3/6] bake"
python -m bearing.scoring.bake \
  --fixture tests/fixtures/chicago_crimes_sample.json \
  --lights-fixture tests/fixtures/chicago_lights_sample.json \
  --out routing/data/custom_areas

if [ ! -f "$GH_JAR" ]; then
  echo "!! $GH_JAR not present — skipping graph verification."
  echo "   Fetch: curl -L -o $GH_JAR \\"
  echo "     https://github.com/graphhopper/graphhopper/releases/download/10.0/graphhopper-web-10.0.jar"
  exit 0
fi

echo "==> [4/6] graph import"
rm -rf routing/data/graph-cache
java -Xmx4g \
  -Ddw.graphhopper.datareader.file="$OSM" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -jar "$GH_JAR" import routing/config-chicago.yml 2>&1 | grep -i "areas available"

echo "==> [5/6] routing assertions"
java -Xmx4g \
  -Ddw.graphhopper.datareader.file="$OSM" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -jar "$GH_JAR" server routing/config-chicago.yml > /tmp/gh-verify.log 2>&1 &
GHPID=$!
trap 'kill $GHPID 2>/dev/null || true' EXIT
for i in $(seq 1 45); do sleep 4; curl -sf "http://localhost:$PORT/health" >/dev/null 2>&1 && break; done
python tests/verify_routing.py

echo "==> [6/6] API + app contract"
rm -f routing/data/telemetry.db
python ops/run_api.py 8000 > /tmp/bearing-api.log 2>&1 &
APIPID=$!
trap 'kill $GHPID $APIPID 2>/dev/null || true' EXIT
for i in $(seq 1 30); do sleep 2; curl -sf http://localhost:8000/health >/dev/null 2>&1 && break; done
python tests/verify_app_contract.py

echo "==> all green"

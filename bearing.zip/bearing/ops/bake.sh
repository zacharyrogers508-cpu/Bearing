#!/usr/bin/env bash
# Nightly bake + graph re-import + zero-downtime swap.
#
# GraphHopper reads custom_areas at IMPORT time, so a new risk surface means a
# new graph. We import into a shadow directory on a second port, health-check
# it, then flip the upstream. Never mutate the live graph in place.
set -euo pipefail
cd "$(dirname "$0")/.."

LIVE_PORT=${LIVE_PORT:-8989}
SHADOW_PORT=${SHADOW_PORT:-8990}
PBF=${PBF:-routing/data/chicago-latest.osm.pbf}

echo "==> [1/5] refreshing incidents"
python -m bearing.ingest.run --source chicago_crimes --incremental
python -m bearing.ingest.run --source chicago_lights --incremental

echo "==> [2/5] baking risk surfaces"
python -m bearing.scoring.bake --out routing/data/custom_areas
# bake exits non-zero on unmapped source values; set -e stops us here, which is
# the point — never publish a surface built from a taxonomy we know is stale.

echo "==> [3/5] importing shadow graph"
rm -rf routing/data/graph-cache-shadow
java -Xmx8g \
  -Ddw.graphhopper.datareader.file="$PBF" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache-shadow \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -Ddw.server.application_connectors[0].port="$SHADOW_PORT" \
  -jar routing/graphhopper-web.jar server routing/config-chicago.yml &
SHADOW_PID=$!

echo "==> [4/5] health-checking shadow on :$SHADOW_PORT"
for i in $(seq 1 120); do
  if curl -sf "http://localhost:$SHADOW_PORT/health" >/dev/null; then break; fi
  sleep 5
done
curl -sf "http://localhost:$SHADOW_PORT/health" >/dev/null || {
  echo "shadow failed health check; keeping live graph"; kill $SHADOW_PID; exit 1; }

echo "==> [5/5] swapping"
echo "$SHADOW_PID" > routing/data/shadow.pid
# point the load balancer / reverse proxy at SHADOW_PORT, then retire LIVE_PORT
echo "shadow healthy on :$SHADOW_PORT — flip upstream, then kill the old process"

#!/usr/bin/env bash
# Switch from the synthetic demo to real Chicago.
#
#   ./ops/real-data.sh
#
# Downloads the Illinois OSM extract (~450 MB), pulls live Chicago crime and
# 311 lighting, rebakes, and reimports the routing graph. Takes 20-40 minutes
# the first time, mostly the graph import.
set -euo pipefail
cd "$(dirname "$0")/.."

PBF=routing/data/illinois-latest.osm.pbf
PBF_URL=https://download.geofabrik.de/north-america/us/illinois-latest.osm.pbf
HEAP=${HEAP:-8g}
LOOKBACK=${LOOKBACK_DAYS:-365}

echo "==> [1/4] Illinois street network"
if [ ! -f "$PBF" ]; then
  echo "    downloading ~450 MB from Geofabrik (once)"
  curl -fL --progress-bar -o "$PBF.part" "$PBF_URL"
  mv "$PBF.part" "$PBF"
else
  echo "    already have $PBF"
fi

echo "==> [2/4] live Chicago data"
if [ -z "${SOCRATA_APP_TOKEN:-}" ]; then
  echo "    NOTE: SOCRATA_APP_TOKEN not set. This still works, but the portal"
  echo "    rate-limits anonymous callers and a year of incidents may stall."
  echo "    Free token: https://data.cityofchicago.org/profile/edit/developer_settings"
fi
python -m bearing.scoring.bake --lookback-days "$LOOKBACK" --out routing/data/custom_areas

echo "==> [3/4] importing the real graph (10-25 min, needs ~${HEAP} RAM)"
rm -rf routing/data/graph-cache
java "-Xmx${HEAP}" \
  -Ddw.graphhopper.datareader.file="$PBF" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -jar routing/graphhopper-web.jar import routing/config-chicago.yml 2>&1 \
  | grep -iE "areas available|nodes:|Exception|ERROR" || true

echo "==> [4/4] done"
cat <<TXT

  Real Chicago is loaded. Start it with:

      OSM=$PBF HEAP=$HEAP ./ops/run.sh

  For live traffic too:

      export TOMTOM_API_KEY=your_key

  Re-run this script whenever you want fresh crime data. Nightly is plenty —
  Chicago's feed excludes the last seven days regardless.
TXT

#!/usr/bin/env bash
# Get a Chicago-only street map and import it.
#
#   ./ops/chicago-extract.sh
#
# Downloads roughly 60-90 MB and imports in 2-5 minutes, rather than the
# ~400 MB / 15-25 minutes an Illinois-wide extract costs. Chicago is about 2%
# of Illinois by area and we only ever route inside the city.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] && { set -a; . ./.env; set +a; }

OUT=routing/data/chicago.osm.pbf
HEAP=${HEAP:-4g}
JAR=routing/graphhopper-web.jar
# lon_min,lat_min,lon_max,lat_max — matches bearing.ingest.chicago.CITY_BBOX
BBOX="-87.94,41.64,-87.52,42.03"

if [ ! -f "$JAR" ]; then
  echo "==> fetching GraphHopper"
  curl -fL -o "$JAR" \
    https://github.com/graphhopper/graphhopper/releases/download/10.0/graphhopper-web-10.0.jar
fi

if [ -f "$OUT" ]; then
  echo "==> already have $OUT ($(du -h "$OUT" | cut -f1))"
else
  echo "==> downloading a Chicago-sized street map"
  # BBBike's extract service cuts arbitrary bounding boxes and serves them
  # directly. If it is busy or the format changes, fall back to Geofabrik's
  # Illinois file and clip it locally with osmium (brew install osmium-tool).
  URL="https://download.bbbike.org/osm/bbbike/Chicago/Chicago.osm.pbf"
  if curl -fL --progress-bar -o "$OUT.part" "$URL"; then
    mv "$OUT.part" "$OUT"
    echo "    got $(du -h "$OUT" | cut -f1)"
  else
    rm -f "$OUT.part"
    echo "    BBBike unavailable — falling back to Illinois + local clip"
    IL=routing/data/illinois-latest.osm.pbf
    [ -f "$IL" ] || curl -fL --progress-bar -o "$IL" \
      https://download.geofabrik.de/north-america/us/illinois-latest.osm.pbf
    if command -v osmium >/dev/null 2>&1; then
      osmium extract --bbox "$BBOX" --overwrite -o "$OUT" "$IL"
      echo "    clipped to $(du -h "$OUT" | cut -f1)"
    else
      echo "    osmium not installed (brew install osmium-tool)."
      echo "    Using the full Illinois file — slower import, same result."
      OUT="$IL"
    fi
  fi
fi

echo "==> baking risk zones"
if [ -n "${SOCRATA_APP_TOKEN:-}" ]; then
  python -m bearing.scoring.bake --lookback-days "${LOOKBACK_DAYS:-270}" \
    --out routing/data/custom_areas
else
  echo "    no SOCRATA_APP_TOKEN — using demo incidents"
  python tests/make_fixture.py >/dev/null
  python -m bearing.scoring.bake \
    --fixture tests/fixtures/chicago_crimes_sample.json \
    --out routing/data/custom_areas
fi

echo "==> importing the map (2-5 min)"
rm -rf routing/data/graph-cache
java "-Xmx${HEAP}" \
  -Ddw.graphhopper.datareader.file="$OUT" \
  -Ddw.graphhopper.graph.location=routing/data/graph-cache \
  -Ddw.graphhopper.custom_areas.directory=routing/data/custom_areas \
  -jar "$JAR" import routing/config-chicago.yml 2>&1 \
  | grep -iE "areas available|nodes:|ERROR|Exception" || true

cat <<TXT

  Done. Start it with:

      OSM=$OUT ./ops/run.sh

  Then open http://localhost:5173
TXT

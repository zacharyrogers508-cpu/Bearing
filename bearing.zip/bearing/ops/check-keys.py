"""Check which API keys are configured and whether they actually work.

Every check makes one real request. A key that is present but wrong is worse
than a missing key, because the failure shows up later as an empty map or a
silently synthetic number.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OK, WARN, BAD = "  ok  ", " warn ", " FAIL "


def load_env() -> None:
    env = ROOT / ".env"
    if not env.exists():
        return
    for line in env.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"').strip("'")
        if v and not os.environ.get(k.strip()):
            os.environ[k.strip()] = v


def get(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, json.loads(r.read().decode())


def row(status: str, name: str, msg: str) -> None:
    print(f"[{status}] {name:<22} {msg}")


#: A blocked network returns 403 too, and "token rejected" is the wrong thing
#: to tell someone whose corporate proxy is eating the request. These markers
#: appear in proxy/egress denials, never in a provider's auth response.
PROXY_MARKERS = ("allowlist", "egress", "proxy", "blocked by", "forbidden by policy")


def looks_like_network_block(detail: str) -> bool:
    d = (detail or "").lower()
    return any(m in d for m in PROXY_MARKERS)


def check_socrata() -> bool:
    token = os.environ.get("SOCRATA_APP_TOKEN", "")
    # SoQL needs URL-encoding: an unencoded space in "count(1) as n" makes
    # urllib refuse the request outright with "URL can't contain control
    # characters", which reads like a network failure and is not one.
    qs = urllib.parse.urlencode({"$select": "count(1) as n", "$limit": 1})
    url = f"https://data.cityofchicago.org/resource/ijzp-q8t2.json?{qs}"
    req = urllib.request.Request(url)
    if token:
        req.add_header("X-App-Token", token)
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            n = json.loads(r.read().decode())[0]["n"]
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:200]
        if looks_like_network_block(detail):
            row(WARN, "Chicago data",
                "blocked by a network proxy, not by the portal. "
                "Allow data.cityofchicago.org.")
            return False
        if e.code in (401, 403):
            row(BAD, "Chicago data", f"token rejected ({e.code}). Check SOCRATA_APP_TOKEN.")
            return False
        row(WARN, "Chicago data", f"portal returned {e.code}; try again shortly")
        return False
    except Exception as e:  # noqa: BLE001
        row(BAD, "Chicago data", f"unreachable: {e}")
        return False
    if token:
        row(OK, "Chicago data", f"token accepted · {int(n):,} incidents available")
    else:
        row(WARN, "Chicago data",
            f"works without a token ({int(n):,} incidents) but you WILL be "
            "rate-limited. Get one free at "
            "data.cityofchicago.org/profile/edit/developer_settings")
    return True


def check_graphhopper() -> bool:
    key = os.environ.get("GRAPHHOPPER_API_KEY", "")
    if not key:
        row(WARN, "GraphHopper (cloud)",
            "not set — routing runs locally, which needs an OSM extract "
            "and a graph import. Free key: graphhopper.com")
        return True
    body = {
        "points": [[-87.6298, 41.8781], [-87.5987, 41.7897]],
        "profile": "foot", "points_encoded": False, "instructions": False,
        "ch.disable": True,
        "custom_model": {"priority": [], "distance_influence": 30},
    }
    url = f"https://graphhopper.com/api/1/route?{urllib.parse.urlencode({'key': key})}"
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            d = json.loads(r.read().decode())
        p = d["paths"][0]
        row(OK, "GraphHopper (cloud)",
            f"key works · test route {p['distance']/1000:.1f} km, "
            f"custom models accepted")
        return True
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:250]
        if looks_like_network_block(detail):
            row(WARN, "GraphHopper (cloud)",
                "blocked by a network proxy, not by GraphHopper. "
                "Allow graphhopper.com.")
            return False
        # The free plan cannot use flexible mode (ch.disable=true), and custom
        # models REQUIRE flexible mode. So a valid free key still cannot do the
        # one thing we need. Say so precisely — "400 Bad Request" sends people
        # hunting for a typo in a key that is perfectly fine.
        if "flexible mode" in detail.lower():
            os.environ["GRAPHHOPPER_FLEXIBLE"] = "0"
            row(BAD, "GraphHopper (cloud)",
                "key is valid, but the FREE plan cannot use flexible mode, "
                "which custom models require.")
            print("        -> Bearing needs custom models, so the free tier "
                  "cannot host our routing.")
            print("        -> Run the router locally instead (free, no limits):")
            print("           ./ops/chicago-extract.sh   # ~60 MB, one time")
            print("        -> Or upgrade at graphhopper.com/pricing "
                  "(flexible mode starts on the paid plans).")
            return False
        row(BAD, "GraphHopper (cloud)",
            f"{e.code}: {'key rejected' if e.code in (401, 403) else detail}")
        return False
    except Exception as e:  # noqa: BLE001
        row(BAD, "GraphHopper (cloud)", f"unreachable: {e}")
        return False


def check_tomtom() -> bool:
    key = os.environ.get("TOMTOM_API_KEY", "")
    if not key:
        row(WARN, "TomTom traffic",
            "not set — congestion is a synthetic demo pattern. "
            "Free key: developer.tomtom.com")
        return True
    qs = urllib.parse.urlencode({"key": key, "point": "41.8781,-87.6298"})
    url = ("https://api.tomtom.com/traffic/services/4/flowSegmentData/"
           f"absolute/10/json?{qs}")
    try:
        _, d = get(url, 25)
        seg = d.get("flowSegmentData", {})
        row(OK, "TomTom traffic",
            f"key works · Loop currently {seg.get('currentSpeed','?')} km/h "
            f"(free-flow {seg.get('freeFlowSpeed','?')})")
        return True
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:200]
        if looks_like_network_block(detail):
            row(WARN, "TomTom traffic",
                "blocked by a network proxy, not by TomTom. Allow api.tomtom.com.")
            return False
        row(BAD, "TomTom traffic",
            f"{e.code} — {'key rejected' if e.code in (400, 403) else 'service error'}")
        return False
    except Exception as e:  # noqa: BLE001
        row(BAD, "TomTom traffic", f"unreachable: {e}")
        return False


def check_maptiler() -> bool:
    key = os.environ.get("MAPTILER_KEY", "")
    local = ROOT / "app" / ".env.local"
    if not key:
        row(WARN, "MapTiler (map style)",
            "not set — using the keyless basemap, which is fine")
        return True
    try:
        get(f"https://api.maptiler.com/maps/dataviz-light/style.json?key={key}", 20)
    except urllib.error.HTTPError as e:
        row(BAD, "MapTiler (map style)", f"{e.code}: key rejected")
        return False
    except Exception as e:  # noqa: BLE001
        row(BAD, "MapTiler (map style)", f"unreachable: {e}")
        return False

    # The browser cannot read .env — it needs app/.env.local
    wants = f"VITE_MAPTILER_KEY={key}"
    if not local.exists() or wants not in local.read_text():
        local.write_text(wants + "\n")
        row(OK, "MapTiler (map style)", "key works · wrote app/.env.local for the browser")
    else:
        row(OK, "MapTiler (map style)", "key works · app/.env.local in place")
    return True


def main() -> int:
    load_env()
    if not (ROOT / ".env").exists():
        print("No .env file. Create one with:\n\n    cp .env.example .env\n")
    print("Checking keys — each of these makes one real request.\n")
    socrata_ok = check_socrata()
    gh_ok = check_graphhopper()
    check_tomtom()
    check_maptiler()
    print()

    # Report on what WORKS, not on what is merely present. The earlier version
    # announced "live mode with no downloads is ready" while the router check
    # was failing on the same screen.
    cloud_routing = gh_ok and bool(os.environ.get("GRAPHHOPPER_API_KEY"))
    graph = ROOT / "routing" / "data" / "graph-cache"

    if socrata_ok and cloud_routing:
        print("  Real crime data + hosted routing. Nothing to download:\n")
        print("      BEARING_LIVE=1 ./ops/run.sh\n")
    elif socrata_ok:
        print("  Real Chicago crime data is ready.")
        print("  Routing runs locally, which needs a street map once:\n")
        if graph.exists():
            print("      BEARING_LIVE=1 ./ops/run.sh          # map already imported\n")
        else:
            print("      ./ops/chicago-extract.sh             # ~60 MB, a few minutes")
            print("      BEARING_LIVE=1 ./ops/run.sh\n")
    else:
        print("  Running on demo data:\n")
        print("      ./ops/run.sh\n")
    return 0 if (socrata_ok or not os.environ.get("SOCRATA_APP_TOKEN")) else 1


if __name__ == "__main__":
    sys.exit(main())

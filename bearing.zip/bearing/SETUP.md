# Getting Bearing running

## What you need

| | | |
|---|---|---|
| **Java 17+** | runs the router | `java -version` · [Temurin](https://adoptium.net) |
| **Python 3.10+** | data pipeline and API | `python3 --version` |
| **Node 18+** | the app | `node --version` · [nodejs.org](https://nodejs.org) |

macOS: `brew install openjdk python node`
Ubuntu: `sudo apt install openjdk-21-jre python3 python3-pip nodejs npm`

## Run it

```bash
cd bearing-chicago

python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cd app && npm install && cd ..

./ops/run.sh
```

First run takes about two minutes — it downloads GraphHopper (~45 MB), builds
the street network, scores the crime data, and imports the routing graph. After
that it's about twenty seconds.

Then open **http://localhost:5173**.

Ctrl-C stops everything.

## What you should see

Chicago with red zones (higher reported-incident density) and three routes.
Things worth trying:

- **Settings → Walking, Tonight 10 PM.** The safest route detours around the
  red zones and reports how many fewer incidents are near it.
- **Settings → Driving, 6 PM rush.** Orange and red congestion zones appear and
  the ETA goes up. Switch to 9 AM and it drops.
- **Go.** Turn-by-turn directions from the real router.
- **A / B buttons.** Tap the map to move start and destination.

## The map

Real OpenStreetMap tiles via MapLibre GL — pinch/scroll to zoom, drag to pan,
right-drag to rotate and tilt. Controls top right, including a locate button
that uses your device GPS.

Address search is wired to Nominatim (OpenStreetMap's geocoder), scoped to
Chicago. Tap either the start or destination row to search, or use the pin
button to drop a point by tapping the map.

Basemap is CARTO Positron, which needs no key. For sharper labels and 3D pitch,
get a free key at [maptiler.com](https://www.maptiler.com/cloud/) and:

```bash
echo 'VITE_MAPTILER_KEY=your_key' > app/.env.local
```

Nominatim's usage policy caps you at one request per second, which is why
search is debounced. If you ship this, self-host Nominatim or use a paid
geocoder — `app/src/geocode.js` is small and designed to be swapped.

## Two ways to run it

### Getting keys

```bash
cp .env.example .env    # edit it
make keys               # validates each key with a real request
```

Full walkthrough in **KEYS.md**. Short version: the Chicago data token is free
and takes two minutes, and a GraphHopper key (also free) is what removes the
450 MB download entirely.

### Live mode — nothing to download

Fetches incidents from Chicago's API for each trip's corridor and sends the
risk zones inline with the routing request. No 450 MB extract, no graph import,
no nightly bake.

```bash
cp .env.example .env          # add SOCRATA_APP_TOKEN
./ops/chicago-extract.sh      # Chicago-only street map, ~60 MB, one time
BEARING_LIVE=1 ./ops/run.sh
```

Live mode skips the city-wide bake, not the street map. GraphHopper's hosted
router does accept our risk polygons inline — but only on a paid plan, because
custom models require flexible mode and the free plan excludes it. Local
routing is free, unlimited and faster per request, so `chicago-extract.sh`
grabs a Chicago-sized map (~60 MB) rather than the 400 MB Illinois file.

**How it works.** Route once with no risk weighting to learn the corridor, fetch
incidents for that corridor's bounding box only, score them, and route again
with those polygons attached. A Loop → Hyde Park trip pulls 703 incidents
instead of a quarter million, and the inline payload is 14 KB.

**What it costs.** Measured on the demo data:

| | cold | warm (cached corridor) |
|---|---|---|
| live mode | ~1000 ms | ~350 ms |
| baked mode | ~275 ms | ~275 ms |

Add 300–800 ms for a real Socrata round trip on a cold corridor. Incidents are
cached per rounded bounding box for 15 minutes, so trips in the same
neighbourhood share a fetch.

### Baked mode — fast, needs the download

Precomputes the risk surface for the whole city and bakes it into the routing
graph. Sub-300 ms routes and no per-request API calls, at the cost of a
450 MB extract, a 20-minute import, and a nightly rebake.

```bash
./ops/real-data.sh
OSM=routing/data/illinois-latest.osm.pbf HEAP=8g ./ops/run.sh
```

**Which to use.** Live mode to get going, to try a new city in an afternoon, or
to deploy serverless. Baked mode when you serve one city at volume. `/health`
reports which one is active, and the API picks live automatically if nothing is
baked.

## Using real data

Out of the box this runs on a synthetic street grid and generated crime data,
so it works with no keys and no downloads. Three changes make it real.

One command does the crime data and the street network together:

```bash
# free token, avoids the portal rate-limiting you:
# https://data.cityofchicago.org/profile/edit/developer_settings
export SOCRATA_APP_TOKEN=your_token

./ops/real-data.sh
```

It downloads the Illinois OSM extract (~450 MB), pulls a year of live Chicago
incidents and 311 lighting outages, rebakes the risk surface, and reimports the
routing graph. Budget 20–40 minutes the first time — most of it is the graph
import, which wants about 8 GB of RAM and only happens once per bake.

Then:

```bash
OSM=routing/data/illinois-latest.osm.pbf HEAP=8g ./ops/run.sh
```

**Real traffic** — TomTom has a free tier at
[developer.tomtom.com](https://developer.tomtom.com):

```bash
export TOMTOM_API_KEY=your_key
```

Without it you get a synthetic congestion pattern, and the app labels it
"demo" so it can't be mistaken for the real thing.

Re-run `./ops/real-data.sh` whenever you want fresh crime data. Nightly is
plenty — Chicago's feed excludes the last seven days regardless.

## Checking it works

```bash
make test        # 57 tests, ~12s
make verify      # bake, graph import, routing, API contract — all offline
make backtest    # does the safety model predict? (needs no users)
```

`make backtest` is the interesting one. It builds the risk model from older
incidents, routes real trips, and scores them against incidents the model never
saw — including against a random detour of the same length as a control.

## If something breaks

**`java: command not found`** — install Java 17+ and reopen your terminal.

**Port already in use** — `lsof -ti:8989 | xargs kill` (also 8000, 5173).

**App shows "No connection"** — the API isn't up. Check `/tmp/bearing-api.log`.
If you're running the UI on a port other than 5173, add it:
`export CORS_ORIGINS=http://localhost:5173,http://localhost:3000`

**Routes look identical** — normal for trips that don't cross a risk zone. Try
the default Loop → Hyde Park trip, or raise safety priority in Settings.

**Map is blank / grey** — tiles come from the internet; check you're online. If
you set `VITE_MAPTILER_KEY`, a bad key shows a blank map with a 403 in the
browser console; remove it to fall back to the keyless basemap.

**Search finds nothing** — Nominatim is scoped to Chicago and rate-limited to
one request per second. Type at least three characters and give it a moment.

**Import runs out of memory on real Illinois data** — raise the heap in
`ops/run.sh`: `-Xmx8g`.

**Graph seems stale after re-baking** — GraphHopper reads risk zones at import
time only. `rm -rf routing/data/graph-cache` and restart.

## Ports

| 8989 | GraphHopper router |
| 8000 | Bearing API |
| 5173 | app |

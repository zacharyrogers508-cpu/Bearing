"""Where routing happens: your machine, or GraphHopper's.

Both speak the same request format, so live areas and traffic work identically.

  local   http://localhost:8989   needs an OSM extract and a graph import
  cloud   graphhopper.com API     needs GRAPHHOPPER_API_KEY, no download at all

The cloud path is what makes "no 450 MB download" possible. Their hosted Route
endpoint accepts custom models with inline `areas`, which is the exact hook the
risk bands and traffic zones use. Free tier is generous enough to develop on.
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Optional

log = logging.getLogger(__name__)

CLOUD_URL = "https://graphhopper.com/api/1/route"
LOCAL_URL = os.environ.get("GH_URL", "http://localhost:8989")

#: Cloud profiles are named differently and there is no custom_model_files
#: indirection — you send the whole model.
CLOUD_PROFILE = {"pedestrian": "foot", "vehicle": "car"}
LOCAL_PROFILE = {"pedestrian": "foot_safe", "vehicle": "car_safe"}


@dataclass
class RouteResult:
    path: dict
    elapsed_s: float
    backend: str


class RouterError(RuntimeError):
    pass


class Router:
    def __init__(self, api_key: Optional[str] = None, local_url: Optional[str] = None):
        self.api_key = api_key or os.environ.get("GRAPHHOPPER_API_KEY")
        self.local_url = local_url or LOCAL_URL
        self.backend = "cloud" if self.api_key else "local"

    def profile_name(self, mode: str) -> str:
        table = CLOUD_PROFILE if self.backend == "cloud" else LOCAL_PROFILE
        return table[mode]

    def route(self, body: dict, mode: str = "pedestrian") -> RouteResult:
        body = dict(body)
        body["profile"] = self.profile_name(mode)

        if self.backend == "cloud":
            url = f"{CLOUD_URL}?{urllib.parse.urlencode({'key': self.api_key})}"
            # The cloud service has no server-side custom_areas directory and no
            # base custom_model_files, so `ch.disable` is the only thing that
            # keeps per-request models honoured — same rule as local.
            body.setdefault("ch.disable", True)
        else:
            url = f"{self.local_url}/route"

        req = urllib.request.Request(
            url, data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"})
        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            detail = e.read().decode()[:300]
            raise RouterError(f"{self.backend} router {e.code}: {detail}") from e
        except urllib.error.URLError as e:
            raise RouterError(f"{self.backend} router unreachable: {e.reason}") from e

        if not data.get("paths"):
            raise RouterError(f"{self.backend} router returned no path")
        return RouteResult(data["paths"][0], time.time() - t0, self.backend)

    def health(self) -> dict:
        if self.backend == "cloud":
            return {"backend": "cloud", "ok": bool(self.api_key)}
        try:
            with urllib.request.urlopen(f"{self.local_url}/health", timeout=5) as r:
                return {"backend": "local", "ok": r.status == 200}
        except Exception:  # noqa: BLE001
            return {"backend": "local", "ok": False}

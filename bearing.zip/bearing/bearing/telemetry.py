"""Phase 1 telemetry.

The plan gates Phase 2 on one number: do people take the slower route? This
module captures the evidence and computes the gate. Everything upstream —
ingest, scoring, banding, routing — exists to make this table meaningful.

Storage is SQLite by default so the beta has no infrastructure dependency.
`db/schema.sql` has the Postgres equivalent for when it matters; the column
names match so the analysis SQL ports unchanged.
"""
from __future__ import annotations

import json
import math
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

DDL = """
CREATE TABLE IF NOT EXISTS route_offer (
    id            TEXT PRIMARY KEY,
    offered_at    TEXT NOT NULL,
    session_id    TEXT NOT NULL,
    mode          TEXT NOT NULL,
    hour_local    INTEGER NOT NULL,
    concerns      TEXT NOT NULL,
    origin_lon    REAL, origin_lat REAL,
    dest_lon      REAL, dest_lat  REAL,
    options       TEXT NOT NULL,
    selected      TEXT,
    nav_started   INTEGER DEFAULT 0,
    nav_completed INTEGER DEFAULT 0,
    deviation_m   REAL
);
CREATE INDEX IF NOT EXISTS offer_session ON route_offer(session_id, offered_at);
CREATE INDEX IF NOT EXISTS offer_hour    ON route_offer(hour_local);
"""


@dataclass
class RouteOption:
    label: str
    minutes: float
    distance_m: float
    exposure_index: float
    extra_minutes: float = 0.0
    exposure_reduction_pct: float = 0.0


@dataclass
class Offer:
    session_id: str
    mode: str
    hour_local: int
    options: dict[str, RouteOption]
    concerns: list[str] = field(default_factory=list)
    origin: Optional[tuple[float, float]] = None
    destination: Optional[tuple[float, float]] = None
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    offered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class Telemetry:
    def __init__(self, path: str | Path = "routing/data/telemetry.db"):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(DDL)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def record_offer(self, offer: Offer) -> str:
        with self._conn() as c:
            c.execute(
                "INSERT INTO route_offer (id, offered_at, session_id, mode, hour_local,"
                " concerns, origin_lon, origin_lat, dest_lon, dest_lat, options)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    offer.id, offer.offered_at, offer.session_id, offer.mode,
                    offer.hour_local, json.dumps(offer.concerns),
                    offer.origin[0] if offer.origin else None,
                    offer.origin[1] if offer.origin else None,
                    offer.destination[0] if offer.destination else None,
                    offer.destination[1] if offer.destination else None,
                    json.dumps({k: asdict(v) for k, v in offer.options.items()}),
                ),
            )
        return offer.id

    def record_selection(self, offer_id: str, selected: str,
                         nav_started: bool = False) -> None:
        with self._conn() as c:
            c.execute(
                "UPDATE route_offer SET selected=?, nav_started=? WHERE id=?",
                (selected, int(nav_started), offer_id),
            )

    def record_completion(self, offer_id: str, completed: bool,
                          deviation_m: Optional[float] = None) -> None:
        with self._conn() as c:
            c.execute(
                "UPDATE route_offer SET nav_completed=?, deviation_m=? WHERE id=?",
                (int(completed), deviation_m, offer_id),
            )


# ---------------------------------------------------------------------------
# The gate
# ---------------------------------------------------------------------------

#: From the plan. Do not soften these after seeing the data.
GATE_ACCEPTANCE_PCT = 30.0
GATE_RETURN_PCT = 15.0
GATE_EXTRA_MIN = 5.0


def _wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval.

    Normal-approximation intervals are badly wrong at the sample sizes a beta
    produces, and this decision is too consequential to read a point estimate
    off 40 trips and call it a gate.
    """
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, (centre - half) * 100), min(100.0, (centre + half) * 100))


def required_n(true_rate: float, threshold_pct: float = GATE_ACCEPTANCE_PCT,
               power: float = 0.8, z: float = 1.96) -> int:
    """Night-trip offers needed for the CI lower bound to clear the threshold.

    Surfaced because the first simulated cohort exposed the problem: at n=105
    a genuine 40% acceptance rate produced an observed 37% whose 95% lower
    bound was 28.5, i.e. FAILED a gate it should have passed. Recruiting for
    "a few hundred users" is not a plan; recruiting for a specific number of
    NIGHT PEDESTRIAN TRIPS WITH A REAL TRADE-OFF is.

    Note the denominator that matters. Only trips where the safer option
    actually cost >= GATE_EXTRA_MIN minutes count, and in the simulation that
    was roughly 40% of all offers. Budget recruitment accordingly.
    """
    t = threshold_pct / 100.0
    if true_rate <= t:
        return -1     # cannot clear a threshold at or above the true rate
    import math as _m
    # n where the lower bound of the interval around true_rate sits at t,
    # inflated for the sampling variation implied by `power`
    from statistics import NormalDist
    z_beta = NormalDist().inv_cdf(power)
    se_units = z + z_beta
    n = (se_units ** 2) * true_rate * (1 - true_rate) / ((true_rate - t) ** 2)
    return int(_m.ceil(n))


def gate_report(tel: Telemetry, min_extra_min: float = GATE_EXTRA_MIN) -> dict:
    """Compute the Phase 1 gate.

    Counts only offers where the safer option ACTUALLY COST SOMETHING. If the
    safest route is the same length as the fastest, choosing it says nothing
    about willingness to trade time for safety, and including those inflates
    acceptance toward meaninglessness. That filter is the difference between a
    real decision and a coin flip.
    """
    with tel._conn() as c:
        rows = c.execute("SELECT * FROM route_offer WHERE selected IS NOT NULL").fetchall()

    night_offers = night_safer = 0
    all_offers = all_safer = 0
    extra_taken: list[float] = []
    by_session: dict[str, list[str]] = {}

    for r in rows:
        opts = json.loads(r["options"])
        by_session.setdefault(r["session_id"], []).append(r["offered_at"])

        safer = [k for k, v in opts.items()
                 if k != "fastest" and v.get("extra_minutes", 0) >= min_extra_min]
        if not safer:
            continue    # no real trade-off was on offer

        is_night = r["hour_local"] >= 20 or r["hour_local"] < 6
        chose = r["selected"] in safer
        all_offers += 1
        all_safer += int(chose)
        if r["mode"] == "pedestrian" and is_night:
            night_offers += 1
            night_safer += int(chose)
        if chose:
            extra_taken.append(opts[r["selected"]]["extra_minutes"])

    returning = sum(1 for v in by_session.values() if len(v) > 1)
    sessions = len(by_session)
    ret_pct = 100.0 * returning / sessions if sessions else 0.0
    acc_pct = 100.0 * night_safer / night_offers if night_offers else 0.0
    lo, hi = _wilson(night_safer, night_offers)

    passes = lo >= GATE_ACCEPTANCE_PCT and ret_pct >= GATE_RETURN_PCT

    return {
        "night_pedestrian_offers": night_offers,
        "night_pedestrian_chose_safer": night_safer,
        "acceptance_pct": round(acc_pct, 1),
        "acceptance_ci95": [round(lo, 1), round(hi, 1)],
        "all_modes_offers": all_offers,
        "all_modes_acceptance_pct": round(100.0 * all_safer / all_offers, 1) if all_offers else 0.0,
        "median_extra_minutes_accepted": round(
            sorted(extra_taken)[len(extra_taken) // 2], 1) if extra_taken else None,
        "sessions": sessions,
        "returning_sessions": returning,
        "return_pct": round(ret_pct, 1),
        "required_n_if_true_rate_is": {
            "35%": required_n(0.35), "40%": required_n(0.40),
            "45%": required_n(0.45), "50%": required_n(0.50),
        },
        "gate": {
            "acceptance_threshold_pct": GATE_ACCEPTANCE_PCT,
            "return_threshold_pct": GATE_RETURN_PCT,
            "min_extra_minutes_counted": min_extra_min,
            "decision_rule": "lower bound of 95% CI must clear the threshold",
            "passes": passes,
        },
    }


def format_gate(report: dict) -> str:
    g = report["gate"]
    lo, hi = report["acceptance_ci95"]
    verdict = "PROCEED to Phase 2" if g["passes"] else "DO NOT PROCEED"
    return "\n".join([
        "Phase 1 gate — safer-route acceptance",
        "=" * 46,
        f"  night pedestrian offers with a real trade-off : {report['night_pedestrian_offers']}",
        f"  chose the safer option                        : {report['night_pedestrian_chose_safer']}",
        f"  acceptance                                    : {report['acceptance_pct']}%  "
        f"(95% CI {lo}-{hi})",
        f"  median extra minutes accepted                 : {report['median_extra_minutes_accepted']}",
        "",
        f"  sessions                                      : {report['sessions']}",
        f"  returned within the window                    : {report['returning_sessions']} "
        f"({report['return_pct']}%)",
        "",
        "  sample size needed (80% power, CI lower bound clears threshold):",
        *[f"      if true rate is {k:<4} -> {v:>5} qualifying night trips"
          for k, v in report["required_n_if_true_rate_is"].items()],
        "",
        f"  thresholds: acceptance >= {g['acceptance_threshold_pct']}% (CI lower bound), "
        f"return >= {g['return_threshold_pct']}%",
        f"  VERDICT: {verdict}",
    ])

"""CLI entry point for incremental ingest.

Usage:
    python -m bearing.ingest.run --source chicago_crimes --incremental
"""
from __future__ import annotations

import argparse
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from .chicago import ChicagoCrimes, ChicagoStreetLights, to_row

STATE = Path(os.environ.get("INGEST_STATE", "routing/data/ingest_state.json"))
OUT = Path(os.environ.get("INGEST_OUT", "routing/data/incidents.jsonl"))


def load_state() -> dict:
    return json.loads(STATE.read_text()) if STATE.exists() else {}


def save_state(state: dict) -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(state, indent=2))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True,
                    choices=["chicago_crimes", "chicago_lights"])
    ap.add_argument("--incremental", action="store_true")
    ap.add_argument("--lookback-days", type=int, default=365)
    ap.add_argument("--app-token", default=os.environ.get("SOCRATA_APP_TOKEN"))
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    state = load_state()
    since = state.get(args.source, {}).get("watermark") if args.incremental else None
    OUT.parent.mkdir(parents=True, exist_ok=True)

    if args.source == "chicago_crimes":
        src = ChicagoCrimes(app_token=args.app_token)
        n, newest = 0, since
        with OUT.open("a") as fh:
            for inc in src.fetch(since=since, lookback_days=args.lookback_days):
                fh.write(json.dumps(to_row(inc)) + "\n")
                n += 1
        print(src.report())
        if src.unmapped:
            raise SystemExit(f"unmapped primary_type: {sorted(src.unmapped)}")
    else:
        src2 = ChicagoStreetLights(app_token=args.app_token)
        n = 0
        with OUT.with_name("lights.jsonl").open("w") as fh:
            for o in src2.fetch_open():
                fh.write(json.dumps(to_row(o)) + "\n")
                n += 1
        print(f"lights: {n} outages")

    state[args.source] = {
        "watermark": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S"),
        "last_run_at": datetime.now(timezone.utc).isoformat(),
        "rows": n,
    }
    save_state(state)


if __name__ == "__main__":
    main()

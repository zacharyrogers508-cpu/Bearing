"""Minimal SoDA (Socrata) client.

Deliberately not sodapy: we need control over pagination, retry, and the
incremental watermark, and we want zero surprise dependencies in the ingest
path. This client is city-agnostic — every Socrata portal speaks the same
dialect, so this is the file that gets reused for Seattle, Baltimore, Austin.
"""
from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Iterator, Optional

log = logging.getLogger(__name__)

PAGE = 50_000          # SoDA hard-caps around 50k per page with an app token
MAX_RETRIES = 5
BACKOFF = 2.0


@dataclass
class SocrataDataset:
    domain: str            # e.g. "data.cityofchicago.org"
    resource: str          # e.g. "ijzp-q8t2"
    app_token: Optional[str] = None

    @property
    def url(self) -> str:
        return f"https://{self.domain}/resource/{self.resource}.json"

    def _request(self, params: dict) -> list[dict]:
        qs = urllib.parse.urlencode(params, safe="$,:()'> =")
        req = urllib.request.Request(f"{self.url}?{qs}")
        req.add_header("Accept", "application/json")
        if self.app_token:
            req.add_header("X-App-Token", self.app_token)

        last: Exception | None = None
        for attempt in range(MAX_RETRIES):
            try:
                with urllib.request.urlopen(req, timeout=120) as resp:
                    return json.loads(resp.read().decode())
            except urllib.error.HTTPError as exc:
                last = exc
                if exc.code in (429, 500, 502, 503, 504):
                    sleep = BACKOFF ** attempt
                    log.warning("SoDA %s on %s, retry in %.0fs", exc.code, self.resource, sleep)
                    time.sleep(sleep)
                    continue
                raise
            except (urllib.error.URLError, TimeoutError) as exc:
                last = exc
                time.sleep(BACKOFF ** attempt)
        raise RuntimeError(f"SoDA request failed after {MAX_RETRIES} attempts") from last

    def count(self, where: Optional[str] = None) -> int:
        params = {"$select": "count(1) as n"}
        if where:
            params["$where"] = where
        rows = self._request(params)
        return int(rows[0]["n"]) if rows else 0

    def rows(
        self,
        select: Optional[str] = None,
        where: Optional[str] = None,
        order: str = ":id",
        page: int = PAGE,
        limit: Optional[int] = None,
    ) -> Iterator[dict]:
        """Stream rows.

        Ordering by :id (the Socrata system row id) rather than a data column
        is deliberate — it is stable under concurrent republication, which
        `date` is not. Paging on an unstable sort silently drops and duplicates
        rows, and you will not notice until your counts drift.
        """
        offset, yielded = 0, 0
        while True:
            params = {"$limit": page, "$offset": offset, "$order": order}
            if select:
                params["$select"] = select
            if where:
                params["$where"] = where

            batch = self._request(params)
            if not batch:
                return
            for row in batch:
                yield row
                yielded += 1
                if limit and yielded >= limit:
                    return
            if len(batch) < page:
                return
            offset += page
            log.info("%s: %d rows", self.resource, offset)


def watermark_clause(column: str, since: Optional[str]) -> Optional[str]:
    """Build an incremental $where clause on a floating-timestamp column."""
    if not since:
        return None
    return f"{column} > '{since}'"

"""Chicago adapters.

Datasets
--------
ijzp-q8t2  Crimes 2001-present. Block-level geocoding (CPD deliberately
           truncates the address to the hundred-block to protect victims).
           **Excludes the most recent seven days.** See LATENCY below.
v6vf-nfxy  311 Service Requests (unified). Street-light outages are rows where
           sr_type starts with "Street Light". This replaced the legacy
           per-type datasets (zuxi-7xem, 3aav-uy2v) in Dec 2018; those are
           historical-only and must not be used for current state.
85ca-t3if  Traffic Crashes.

LATENCY — read this before promising anyone "live" data
-------------------------------------------------------
Chicago's crime feed lags by seven days plus reporting lag. Chicago has no
public calls-for-service feed, so seven days is the floor, not something a
better scraper can beat. Any product copy implying real-time crime awareness in
Chicago is false. What IS near-real-time here is the 311 lighting layer, which
updates continuously and genuinely changes overnight route quality.

Cities with public CAD feeds (Seattle, SF) can do better and should be
prioritised if timeliness turns out to matter to users. That is a Phase 2
question the Phase 1 telemetry will answer.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from typing import Iterator, Optional

from .socrata import SocrataDataset, watermark_clause
from ..taxonomy import Taxonomy

log = logging.getLogger(__name__)

DOMAIN = "data.cityofchicago.org"
CRIMES = "ijzp-q8t2"
SERVICE_REQUESTS = "v6vf-nfxy"
CRASHES = "85ca-t3if"

CITY_BBOX = (-87.94, 41.64, -87.52, 42.03)  # lon_min, lat_min, lon_max, lat_max

CRIME_SELECT = ",".join([
    "id", "case_number", "date", "block", "iucr", "primary_type",
    "description", "location_description", "arrest", "domestic",
    "beat", "district", "ward", "community_area", "fbi_code",
    "latitude", "longitude", "updated_on",
])


@dataclass
class Incident:
    source_id: str
    source: str
    occurred_at: str
    lat: float
    lon: float
    canonical: str
    weight: float
    ped_relevance: float
    veh_relevance: float
    raw_type: str
    raw_description: str
    location_description: str
    geocode_precision_m: float
    arrest: bool
    beat: Optional[str] = None


def _f(v) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def in_bbox(lon: float, lat: float) -> bool:
    return CITY_BBOX[0] <= lon <= CITY_BBOX[2] and CITY_BBOX[1] <= lat <= CITY_BBOX[3]


class ChicagoCrimes:
    """Crime incidents, classified and street-weighted."""

    #: CPD truncates to the hundred-block. A Chicago block is ~1/8 mile, so the
    #: true location is uniform over roughly +/-100 m along the street axis.
    #: This is a hard floor on kernel bandwidth — see scoring/kde.py.
    GEOCODE_PRECISION_M = 100.0

    def __init__(self, app_token: Optional[str] = None, taxonomy: Optional[Taxonomy] = None):
        self.ds = SocrataDataset(DOMAIN, CRIMES, app_token)
        self.tax = taxonomy or Taxonomy("chicago")
        self.stats = {
            "seen": 0, "no_geo": 0, "out_of_bbox": 0,
            "excluded_class": 0, "zero_relevance": 0, "kept": 0,
        }
        self.unmapped: set[str] = set()

    def fetch(
        self,
        since: Optional[str] = None,
        lookback_days: int = 365,
        limit: Optional[int] = None,
    ) -> Iterator[Incident]:
        if since:
            where = watermark_clause("updated_on", since)
        else:
            floor = datetime.now(timezone.utc) - timedelta(days=lookback_days)
            where = f"date > '{floor.strftime('%Y-%m-%dT%H:%M:%S')}'"

        for row in self.ds.rows(select=CRIME_SELECT, where=where, limit=limit):
            self.stats["seen"] += 1
            inc = self._to_incident(row)
            if inc is not None:
                self.stats["kept"] += 1
                yield inc

    def _to_incident(self, row: dict) -> Optional[Incident]:
        lat, lon = _f(row.get("latitude")), _f(row.get("longitude"))
        if lat is None or lon is None:
            self.stats["no_geo"] += 1
            return None
        if not in_bbox(lon, lat):
            self.stats["out_of_bbox"] += 1
            return None

        ptype = row.get("primary_type")
        if ptype and ptype.strip().upper() not in self.tax._by_type:
            self.unmapped.add(ptype.strip().upper())

        canonical, weight = self.tax.classify(
            ptype, row.get("description"), row.get("iucr")
        )
        if canonical == "excluded" or weight <= 0:
            self.stats["excluded_class"] += 1
            return None

        # Belt-and-braces: CPD flags domestic separately from the IUCR code and
        # the flag is more reliable than the description text.
        if str(row.get("domestic", "")).lower() in ("true", "1"):
            self.stats["excluded_class"] += 1
            return None

        ped, veh = self.tax.street_relevance(row.get("location_description"))
        if ped <= 0 and veh <= 0:
            self.stats["zero_relevance"] += 1
            return None

        return Incident(
            source_id=str(row.get("id")),
            source="chicago_pd_clear",
            occurred_at=row.get("date", ""),
            lat=lat, lon=lon,
            canonical=canonical, weight=weight,
            ped_relevance=ped, veh_relevance=veh,
            raw_type=(ptype or ""),
            raw_description=(row.get("description") or ""),
            location_description=(row.get("location_description") or ""),
            geocode_precision_m=self.GEOCODE_PRECISION_M,
            arrest=str(row.get("arrest", "")).lower() in ("true", "1"),
            beat=row.get("beat"),
        )

    def report(self) -> str:
        s = self.stats
        kept_pct = 100.0 * s["kept"] / s["seen"] if s["seen"] else 0.0
        lines = [
            f"seen={s['seen']}  kept={s['kept']} ({kept_pct:.1f}%)",
            f"  dropped: no_geo={s['no_geo']} out_of_bbox={s['out_of_bbox']} "
            f"excluded_class={s['excluded_class']} zero_relevance={s['zero_relevance']}",
        ]
        if self.unmapped:
            lines.append(f"  !! UNMAPPED primary_type values: {sorted(self.unmapped)}")
        return "\n".join(lines)


@dataclass
class LightOutage:
    source_id: str
    opened_at: str
    closed_at: Optional[str]
    lat: float
    lon: float
    kind: str          # "all_out" (3+) or "one_out"
    open_now: bool


class ChicagoStreetLights:
    """311 street-light outages — the near-real-time half of the signal.

    Chicago's crime feed lags a week; this does not. An outage opened last
    night legitimately changes tonight's route.
    """

    SR_TYPES = ("Street Light Out Complaint", "Street Lights - All Out")

    def __init__(self, app_token: Optional[str] = None):
        self.ds = SocrataDataset(DOMAIN, SERVICE_REQUESTS, app_token)

    def fetch_open(self, lookback_days: int = 120) -> Iterator[LightOutage]:
        floor = datetime.now(timezone.utc) - timedelta(days=lookback_days)
        types = ",".join(f"'{t}'" for t in self.SR_TYPES)
        where = (
            f"created_date > '{floor.strftime('%Y-%m-%dT%H:%M:%S')}' "
            f"AND sr_type in({types})"
        )
        select = ",".join([
            "sr_number", "sr_type", "status", "created_date",
            "closed_date", "latitude", "longitude",
        ])
        for row in self.ds.rows(select=select, where=where):
            lat, lon = _f(row.get("latitude")), _f(row.get("longitude"))
            if lat is None or lon is None or not in_bbox(lon, lat):
                continue
            status = (row.get("status") or "").lower()
            yield LightOutage(
                source_id=str(row.get("sr_number")),
                opened_at=row.get("created_date", ""),
                closed_at=row.get("closed_date"),
                lat=lat, lon=lon,
                kind="all_out" if "All Out" in (row.get("sr_type") or "") else "one_out",
                open_now=status.startswith("open"),
            )


def to_row(obj) -> dict:
    return asdict(obj)

"""Backtest: does the safety routing have predictive validity?

The question
-----------
A route scored against incidents it was built from will always look good — that
is circular. The real question is whether a route built from the PAST passes
fewer incidents in the FUTURE.

Method
------
1. Split incidents at a cut date. Build the risk surface from the TRAIN period
   only. The holdout period is never seen by the scorer.
2. Sample random origin/destination pairs across the city.
3. Route each pair twice through the real router: fastest and safest.
4. Count HOLDOUT incidents near each route, weighted by relevance to the mode.
5. Compare.

The control that makes it honest
--------------------------------
A safest route is longer, and it uses different streets. A longer route on
different streets may encounter fewer incidents purely by chance — or worse,
the comparison may just be measuring "this detour happened to go somewhere
quieter" rather than "the model knew where quiet was".

So every safest route is matched against a DETOUR CONTROL: a route of
approximately the same extra length, routed via a randomly chosen waypoint,
with no risk weighting at all. If the safest route does not beat the random
detour of equal length, the model is not adding information and the whole
product is a longer walk with a green badge on it.

That control is the actual test. Everything else is bookkeeping.
"""
from __future__ import annotations

import json
import math
import random
import statistics
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional, Sequence

import numpy as np

from .ingest.chicago import CITY_BBOX
from .routing import Profile, routing_request
from .scoring.kde import (
    FieldSpec, IncidentArray, M_PER_DEG_LAT, M_PER_DEG_LON,
    build_field, densify, _parse,
)
from .taxonomy import LAYERS

GH_URL = "http://localhost:8989"

#: Radius for "this route passed near that incident". Must be >= the source
#: geocoding error (~100 m for CPD block-level), or we would be asserting a
#: precision the data does not have.
NEAR_M = 120.0


# ---------------------------------------------------------------------------
# temporal split
# ---------------------------------------------------------------------------

@dataclass
class Split:
    train: list
    holdout: list
    cut: datetime

    def summary(self) -> str:
        return (f"train={len(self.train):,} (before {self.cut:%Y-%m-%d})  "
                f"holdout={len(self.holdout):,} (after)")


def temporal_split(incidents: Iterable, holdout_days: int = 90,
                   now: Optional[datetime] = None) -> Split:
    now = now or datetime.now(timezone.utc)
    cut = now - timedelta(days=holdout_days)
    train, holdout = [], []
    for inc in incidents:
        dt = _parse(inc.occurred_at)
        if dt is None:
            continue
        (holdout if dt >= cut else train).append(inc)
    return Split(train=train, holdout=holdout, cut=cut)


# ---------------------------------------------------------------------------
# routing
# ---------------------------------------------------------------------------

def _gh(body: dict) -> Optional[dict]:
    req = urllib.request.Request(
        f"{GH_URL}/route", data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
        return data["paths"][0] if data.get("paths") else None
    except (urllib.error.HTTPError, urllib.error.URLError, KeyError):
        return None


def route(profile: Profile, points: Sequence[tuple[float, float]]) -> Optional[dict]:
    body = routing_request(profile, list(points))
    body.pop("algorithm", None)
    body.pop("alternative_route.max_paths", None)
    return _gh(body)


# ---------------------------------------------------------------------------
# exposure to holdout incidents
# ---------------------------------------------------------------------------

def holdout_exposure(coords: Sequence[Sequence[float]], holdout: IncidentArray,
                     mode: str, near_m: float = NEAR_M) -> tuple[float, int]:
    """Return (relevance-weighted exposure, raw count) of holdout incidents
    within `near_m` of the route."""
    if len(coords) < 2 or len(holdout) == 0:
        return 0.0, 0

    lon, lat = densify([c[0] for c in coords], [c[1] for c in coords], spacing_m=40.0)
    rx = lon * M_PER_DEG_LON
    ry = lat * M_PER_DEG_LAT
    ix = holdout.lon * M_PER_DEG_LON
    iy = holdout.lat * M_PER_DEG_LAT
    rel = holdout.ped_relevance if mode == "pedestrian" else holdout.veh_relevance

    # coarse bbox prefilter, then exact min-distance per surviving incident
    lo_x, hi_x = rx.min() - near_m, rx.max() + near_m
    lo_y, hi_y = ry.min() - near_m, ry.max() + near_m
    m = (ix >= lo_x) & (ix <= hi_x) & (iy >= lo_y) & (iy <= hi_y)
    if not m.any():
        return 0.0, 0
    ix, iy, rel, w = ix[m], iy[m], rel[m], holdout.weight[m]

    total, count = 0.0, 0
    for k in range(len(ix)):
        d2 = (rx - ix[k]) ** 2 + (ry - iy[k]) ** 2
        if d2.min() <= near_m * near_m:
            count += 1
            total += float(rel[k] * w[k])
    return total, count


# ---------------------------------------------------------------------------
# the experiment
# ---------------------------------------------------------------------------

@dataclass
class Trial:
    origin: tuple[float, float]
    dest: tuple[float, float]
    fastest_m: float
    fastest_min: float
    fastest_exposure: float
    fastest_count: int
    safest_m: float
    safest_min: float
    safest_exposure: float
    safest_count: int
    control_m: float = 0.0
    control_exposure: float = 0.0
    control_count: int = 0

    @property
    def differs(self) -> bool:
        """Was there actually a treatment? If the safest route is the same as
        the fastest, this trip tells us nothing and must not dilute the result."""
        return abs(self.safest_m - self.fastest_m) > 1.0

    def per_km(self, which: str) -> float:
        """Exposure per kilometre.

        Raw exposure favours whichever route is shorter, and the safest route
        is by construction longer. Comparing raw totals would understate the
        model; comparing per-km overstates nothing and is the fair unit for a
        route the traveller has to walk the whole of."""
        m = getattr(self, f"{which}_m") or 1.0
        return getattr(self, f"{which}_exposure") / (m / 1000.0)


@dataclass
class Backtest:
    trials: list[Trial] = field(default_factory=list)

    def _reduction(self, a: str, b: str, trials=None) -> list[float]:
        out = []
        for t in (trials if trials is not None else self.trials):
            base = getattr(t, f"{a}_exposure")
            if base <= 0:
                continue
            out.append(100.0 * (1 - getattr(t, f"{b}_exposure") / base))
        return out

    def report(self) -> dict:
        n_all = len(self.trials)
        if not n_all:
            return {"trials": 0}
        # Only trips where a treatment actually occurred AND there was
        # something to avoid. Everything else is a null comparison.
        self_trials = [t for t in self.trials if t.differs and t.fastest_exposure > 0]
        n = len(self_trials)
        if not n:
            return {"trials": n_all, "evaluable_trials": 0,
                    "vs_random_detour": {"verdict":
                        "NO POWER — no trip both diverted and had baseline exposure"}}
        trials_all = self.trials
        self.trials = self_trials
        usable = self_trials
        safe_red = self._reduction("fastest", "safest")
        ctrl_red = self._reduction("fastest", "control")

        extra_min = [t.safest_min - t.fastest_min for t in self.trials]
        extra_pct = [100.0 * (t.safest_m - t.fastest_m) / t.fastest_m
                     for t in self.trials if t.fastest_m > 0]

        def mean(x):
            return round(statistics.fmean(x), 1) if x else None

        def med(x):
            return round(statistics.median(x), 1) if x else None

        # paired sign test: on how many trips did safest beat the equal-length
        # random detour on FUTURE incidents?
        paired = [(t.safest_exposure, t.control_exposure)
                  for t in self.trials if t.control_exposure or t.safest_exposure]
        wins = sum(1 for s, c in paired if s < c)
        ties = sum(1 for s, c in paired if s == c)
        losses = sum(1 for s, c in paired if s > c)
        decisive = wins + losses
        p_value = _sign_test_p(wins, decisive) if decisive else None

        per_km = {
            k: round(statistics.fmean(t.per_km(k) for t in self_trials), 3)
            for k in ("fastest", "safest", "control")
        }
        self.trials = trials_all
        return {
            "trials": n_all,
            "evaluable_trials": n,
            "trials_with_any_fastest_exposure": len(usable),
            "mean_exposure_per_km": per_km,
            "mean_holdout_exposure": {
                "fastest": round(statistics.fmean(t.fastest_exposure for t in self.trials), 3),
                "safest": round(statistics.fmean(t.safest_exposure for t in self.trials), 3),
                "control": round(statistics.fmean(t.control_exposure for t in self.trials), 3),
            },
            "mean_holdout_count": {
                "fastest": round(statistics.fmean(t.fastest_count for t in self.trials), 1),
                "safest": round(statistics.fmean(t.safest_count for t in self.trials), 1),
                "control": round(statistics.fmean(t.control_count for t in self.trials), 1),
            },
            "exposure_reduction_pct": {
                "safest_vs_fastest_mean": mean(safe_red),
                "safest_vs_fastest_median": med(safe_red),
                "control_vs_fastest_mean": mean(ctrl_red),
                "control_vs_fastest_median": med(ctrl_red),
            },
            "cost": {
                "mean_extra_minutes": mean(extra_min),
                "median_extra_minutes": med(extra_min),
                "mean_extra_distance_pct": mean(extra_pct),
            },
            "vs_random_detour": {
                "safest_better": wins, "control_better": losses, "ties": ties,
                "win_rate_pct": round(100.0 * wins / decisive, 1) if decisive else None,
                "sign_test_p": p_value,
                "verdict": _verdict(wins, decisive, p_value),
            },
        }


def _sign_test_p(wins: int, n: int) -> float:
    """Two-sided exact binomial sign test against p=0.5."""
    if n == 0:
        return 1.0
    k = max(wins, n - wins)
    tail = sum(math.comb(n, i) for i in range(k, n + 1)) / (2 ** n)
    return round(min(1.0, 2 * tail), 5)


def _verdict(wins: int, decisive: int, p: Optional[float]) -> str:
    if not decisive:
        return "INCONCLUSIVE — no decisive trials"
    rate = wins / decisive
    if p is not None and p < 0.05 and rate > 0.5:
        return "PASS — beats an equal-length random detour on future incidents"
    if p is not None and p < 0.05 and rate < 0.5:
        return "FAIL — worse than a random detour of the same length"
    return "INCONCLUSIVE — indistinguishable from a random detour of equal length"


def _random_pair(rnd: random.Random, min_km: float, max_km: float
                 ) -> tuple[tuple[float, float], tuple[float, float]]:
    lo_lon, lo_lat, hi_lon, hi_lat = CITY_BBOX
    for _ in range(200):
        a = (rnd.uniform(lo_lon, hi_lon), rnd.uniform(lo_lat, hi_lat))
        bearing = rnd.uniform(0, 2 * math.pi)
        dist = rnd.uniform(min_km, max_km) * 1000
        b = (a[0] + dist * math.cos(bearing) / M_PER_DEG_LON,
             a[1] + dist * math.sin(bearing) / M_PER_DEG_LAT)
        if lo_lon < b[0] < hi_lon and lo_lat < b[1] < hi_lat:
            return a, b
    return (lo_lon + 0.05, lo_lat + 0.05), (lo_lon + 0.08, lo_lat + 0.08)


def stratified_pairs(field: np.ndarray, spec: FieldSpec, rnd: random.Random,
                     n: int, min_km: float, max_km: float,
                     percentile: float = 97.0
                     ) -> list[tuple[tuple[float, float], tuple[float, float]]]:
    """Sample origin/destination pairs whose direct line crosses a risk area.

    WHY THIS EXISTS. The first run of this backtest sampled uniformly across
    the city and was worthless: banded area is well under 1% of Chicago, so 90
    of 100 trips never came near a risk zone, the safest route was byte-identical
    to the fastest, and the "experiment" compared a treatment against itself.
    Median extra distance was +0.1%.

    Uniform sampling answers "does safety routing help on an average trip",
    whose answer is trivially "usually there is nothing to avoid". The question
    the product actually makes a claim about is "when a trip WOULD cross a risk
    area, does routing around it help". That requires sampling trips that cross
    risk areas — which is stratification, not cheating, as long as the exposure
    comparison itself stays honest.
    """
    from .scoring.kde import to_lonlat
    ny, nx = field.shape
    thresh = np.percentile(field[field > 0.02], percentile) if (field > 0.02).any() else 1.0
    hot = np.argwhere(field >= thresh)
    if len(hot) == 0:
        return [_random_pair(rnd, min_km, max_km) for _ in range(n)]

    out = []
    lo_lon, lo_lat, hi_lon, hi_lat = CITY_BBOX
    for _ in range(n * 8):
        if len(out) >= n:
            break
        gy, gx = hot[rnd.randrange(len(hot))]
        lon, lat = to_lonlat(np.array([gx * spec.cell_m]),
                             np.array([gy * spec.cell_m]), spec.origin)
        cx, cy = float(lon[0]), float(lat[0])
        # place origin and destination on opposite sides of the hot cell, so
        # the straight line runs through it
        bearing = rnd.uniform(0, 2 * math.pi)
        half = rnd.uniform(min_km, max_km) * 500     # half the trip length
        dx, dy = math.cos(bearing) * half, math.sin(bearing) * half
        a = (cx - dx / M_PER_DEG_LON, cy - dy / M_PER_DEG_LAT)
        b = (cx + dx / M_PER_DEG_LON, cy + dy / M_PER_DEG_LAT)
        if all(lo_lon < p[0] < hi_lon and lo_lat < p[1] < hi_lat for p in (a, b)):
            out.append((a, b))
    return out


def _detour_control(rnd: random.Random, a, b, target_extra_m: float,
                    profile: Profile) -> Optional[dict]:
    """A route of comparable extra length via a random waypoint, NO risk weighting.

    Perpendicular offset from the midpoint, scaled so the added distance is in
    the same ballpark as the safest route's detour. Tries a few offsets and
    keeps the closest match.
    """
    if target_extra_m <= 1:
        return None
    mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
    dx = (b[0] - a[0]) * M_PER_DEG_LON
    dy = (b[1] - a[1]) * M_PER_DEG_LAT
    norm = math.hypot(dx, dy) or 1.0
    px, py = -dy / norm, dx / norm      # unit perpendicular, metres

    flat = Profile(mode=profile.mode, concerns=[], hour=profile.hour, safety=0.0)
    best, best_err = None, float("inf")
    base_offset = target_extra_m
    for scale in (0.4, 0.7, 1.0, 1.4):
        for sign in (1, -1):
            off = base_offset * scale * sign
            wp = (mx + px * off / M_PER_DEG_LON, my + py * off / M_PER_DEG_LAT)
            if not (CITY_BBOX[0] < wp[0] < CITY_BBOX[2]
                    and CITY_BBOX[1] < wp[1] < CITY_BBOX[3]):
                continue
            p = route(flat, [a, wp, b])
            if not p:
                continue
            err = abs((p["distance"]) - (target_extra_m))
            if err < best_err:
                best, best_err = p, err
    return best


def run(train_incidents, holdout_incidents, *, mode: str = "pedestrian",
        hour: int = 22, concerns: Sequence[str] = ("alone",),
        n_trials: int = 120, seed: int = 17,
        min_km: float = 1.0, max_km: float = 4.0,
        spec: Optional[FieldSpec] = None, progress: bool = True,
        field: Optional[np.ndarray] = None) -> Backtest:
    """Run the experiment. Requires a GraphHopper baked from TRAIN ONLY.

    Pass `field` (the TRAIN risk surface) to stratify trip sampling onto trips
    that actually cross a risk area. Without it, sampling is uniform and the
    experiment has almost no power — see stratified_pairs.
    """
    rnd = random.Random(seed)
    spec = spec or FieldSpec(bbox=CITY_BBOX, cell_m=40.0, sigma_m=110.0)
    pool = (stratified_pairs(field, spec, rnd, n_trials * 4, min_km, max_km)
            if field is not None else None)
    pool_i = 0
    holdout = IncidentArray.from_incidents(holdout_incidents)
    layer = LAYERS["person"] if mode == "pedestrian" else LAYERS["property"]
    holdout = holdout.subset(layer)

    fast_p = Profile(mode=mode, concerns=list(concerns), hour=hour, safety=0.0)
    safe_p = Profile(mode=mode, concerns=list(concerns), hour=hour, safety=1.0)

    bt = Backtest()
    attempts = 0
    while len(bt.trials) < n_trials and attempts < n_trials * 6:
        attempts += 1
        if pool is not None and pool_i < len(pool):
            a, b = pool[pool_i]; pool_i += 1
        else:
            a, b = _random_pair(rnd, min_km, max_km)
        pf = route(fast_p, [a, b])
        ps = route(safe_p, [a, b])
        if not pf or not ps:
            continue

        fe, fc = holdout_exposure(pf["points"]["coordinates"], holdout, mode)
        se, sc = holdout_exposure(ps["points"]["coordinates"], holdout, mode)

        extra = ps["distance"] - pf["distance"]
        pc = _detour_control(rnd, a, b, extra, fast_p)
        ce, cc, cm = 0.0, 0, 0.0
        if pc:
            ce, cc = holdout_exposure(pc["points"]["coordinates"], holdout, mode)
            cm = pc["distance"]

        bt.trials.append(Trial(
            origin=a, dest=b,
            fastest_m=pf["distance"], fastest_min=pf["time"] / 60000,
            fastest_exposure=fe, fastest_count=fc,
            safest_m=ps["distance"], safest_min=ps["time"] / 60000,
            safest_exposure=se, safest_count=sc,
            control_m=cm, control_exposure=ce, control_count=cc,
        ))
        if progress and len(bt.trials) % 20 == 0:
            print(f"    {len(bt.trials)}/{n_trials} trials")
    return bt


def format_report(rep: dict) -> str:
    if not rep.get("trials"):
        return "no trials"
    e, c, r = rep["mean_holdout_exposure"], rep["cost"], rep["exposure_reduction_pct"]
    v = rep["vs_random_detour"]
    return "\n".join([
        "Backtest — predictive validity on held-out incidents",
        "=" * 58,
        f"  trials: {rep['trials']}   evaluable (diverted AND had exposure): "
        f"{rep.get('evaluable_trials', 0)}",
        "",
        "  mean exposure per km (length-normalised)",
        f"    fastest {rep['mean_exposure_per_km']['fastest']:.3f}   "
        f"safest {rep['mean_exposure_per_km']['safest']:.3f}   "
        f"control {rep['mean_exposure_per_km']['control']:.3f}",
        "",
        "  mean holdout exposure (lower is better)",
        f"    fastest route            {e['fastest']:.3f}   "
        f"({rep['mean_holdout_count']['fastest']} incidents nearby)",
        f"    safest route             {e['safest']:.3f}   "
        f"({rep['mean_holdout_count']['safest']} incidents nearby)",
        f"    random detour, same len  {e['control']:.3f}   "
        f"({rep['mean_holdout_count']['control']} incidents nearby)",
        "",
        f"  exposure reduction vs fastest, median",
        f"    safest         {r['safest_vs_fastest_median']}%",
        f"    random detour  {r['control_vs_fastest_median']}%   <- the number that matters",
        "",
        f"  cost: +{c['median_extra_minutes']} min median "
        f"(+{c['mean_extra_distance_pct']}% distance mean)",
        "",
        "  head-to-head vs an equal-length random detour",
        f"    safest better on {v['safest_better']} trips, "
        f"worse on {v['control_better']}, tied on {v['ties']}",
        f"    win rate {v['win_rate_pct']}%   sign-test p = {v['sign_test_p']}",
        "",
        f"  {v['verdict']}",
    ])

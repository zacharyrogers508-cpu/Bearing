"""CLI for the temporal backtest."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

from .ingest.chicago import ChicagoCrimes, CITY_BBOX
from .scoring.kde import FieldSpec
from .scoring.bake import bake
from . import backtest as bt

ROOT = Path(__file__).resolve().parent.parent
FIXTURE = ROOT / "tests" / "fixtures" / "chicago_crimes_sample.json"


def load_all():
    src = ChicagoCrimes()
    rows = json.loads(FIXTURE.read_text())
    return [i for i in (src._to_incident(r) for r in rows) if i]


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare"); p.add_argument("--holdout-days", type=int, default=90)
    r = sub.add_parser("run")
    r.add_argument("--holdout-days", type=int, default=90)
    r.add_argument("--trials", type=int, default=120)
    r.add_argument("--mode", default="pedestrian")
    r.add_argument("--hour", type=int, default=22)
    a = ap.parse_args()

    incidents = load_all()
    split = bt.temporal_split(incidents, holdout_days=a.holdout_days)
    print("  " + split.summary())

    if a.cmd == "prepare":
        spec = FieldSpec(bbox=CITY_BBOX, cell_m=40.0, sigma_m=110.0)
        m = bake(split.train, ROOT / "routing" / "data" / "custom_areas_train", spec,
                 verbose=False, field_dir=ROOT / "routing" / "data" / "fields_train")
        print(f"  baked {m['incident_count']:,} train incidents -> "
              f"{sum(m['band_counts'].values())} polygons")
        return

    import numpy as np
    layer = "person" if a.mode == "pedestrian" else "property"
    tod = "night" if (a.hour >= 20 or a.hour < 6) else "day"
    fpath = ROOT / "routing" / "data" / "fields_train" / f"{layer}_{tod}.npy"
    field = np.load(fpath) if fpath.exists() else None
    res = bt.run(split.train, split.holdout, mode=a.mode, hour=a.hour,
                 n_trials=a.trials, field=field)
    rep = res.report()
    print()
    print(bt.format_report(rep))
    (ROOT / "routing" / "data" / "backtest.json").write_text(json.dumps(rep, indent=2))
    sys.exit(0 if rep["vs_random_detour"]["verdict"].startswith("PASS") else 2)


if __name__ == "__main__":
    main()

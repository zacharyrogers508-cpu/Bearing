"""Bearing scoring + routing API.

Two endpoints matter:

  POST /score   corridor polyline + profile -> per-segment exposure.
                THIS IS THE PRODUCT. It is what a delivery platform, a
                rideshare, or eventually a nav incumbent licenses. It does not
                require them to adopt our router, our map, or our app.

  POST /route   convenience wrapper that asks GraphHopper for three options
                with generated custom models. Powers our own app.

Everything else is telemetry and health.
"""
from __future__ import annotations

import json
import logging
import os
import urllib.request
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field, field_validator

from ..ingest.chicago import CITY_BBOX
from ..routing import Profile, route_variants, routing_request, build_custom_model
from ..scoring.kde import FieldSpec, densify, sample_field, to_exposure
from ..telemetry import Telemetry, Offer, RouteOption, gate_report, format_gate
from ..router import Router, RouterError
from ..live import build_live_areas, LiveChicago, FixtureSource, payload_kb

log = logging.getLogger("api")

GRAPHHOPPER = os.environ.get("GH_URL", "http://localhost:8989")
FIELD_DIR = Path(os.environ.get("FIELD_DIR", "routing/data/fields"))

app = FastAPI(title="Bearing", version="0.1.0",
              description="Safety-weighted route scoring for Chicago")

# The beta app runs on a different origin. Locked to explicit origins rather
# than "*" because these endpoints write telemetry.
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get(
        "CORS_ORIGINS", "http://localhost:5173,http://localhost:3000"
    ).split(","),
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

TELEMETRY = Telemetry(os.environ.get("TELEMETRY_DB", "routing/data/telemetry.db"))

#: Live traffic, refreshed on a short cycle. Real if TOMTOM_API_KEY is set,
#: synthetic otherwise — and /health says which, so a demo is never mistaken
#: for a measurement.
ROUTER = Router()

#: Live mode: fetch incidents per trip instead of using a baked surface.
#: Enabled automatically when no bake exists, so a fresh clone routes without
#: any download or import at all.
LIVE_MODE = os.environ.get("BEARING_LIVE", "auto").lower()
_LIVE_SOURCE = None


def live_enabled() -> bool:
    if LIVE_MODE in ("1", "true", "on"):
        return True
    if LIVE_MODE in ("0", "false", "off"):
        return False
    return not _FIELDS          # auto: live when nothing is baked


def live_source():
    global _LIVE_SOURCE
    if _LIVE_SOURCE is None:
        fixture = Path(os.environ.get(
            "LIVE_FIXTURE", "tests/fixtures/chicago_crimes_sample.json"))
        if os.environ.get("SOCRATA_APP_TOKEN") or not fixture.exists():
            _LIVE_SOURCE = LiveChicago(os.environ.get("SOCRATA_APP_TOKEN"))
        else:
            # No token and a fixture present: run offline rather than hammering
            # the portal anonymously.
            from ..ingest.chicago import ChicagoCrimes
            src = ChicagoCrimes()
            rows = json.loads(fixture.read_text())
            _LIVE_SOURCE = FixtureSource(
                [i for i in (src._to_incident(r) for r in rows) if i])
    return _LIVE_SOURCE


_TRAFFIC: dict = {"areas": {}, "fetched_at": None, "source": None, "segments": 0}
TRAFFIC_TTL_S = int(os.environ.get("TRAFFIC_TTL_S", "180"))


def refresh_traffic(hour: int) -> dict:
    """Fetch (or reuse) live congestion.

    The cache keys on `hour`, not just time. In production `hour` is always
    "now" and this is redundant — but the app lets you ask "what would this
    drive look like at 3am", and a TTL-only cache silently answered that with
    the 6pm jams. Same numbers for both, no error. Key on what varies.
    """
    from ..traffic import get_source, jam_areas
    now = datetime.now(timezone.utc)
    fetched = _TRAFFIC.get("fetched_at")
    if (fetched and _TRAFFIC.get("hour") == hour
            and (now - fetched).total_seconds() < TRAFFIC_TTL_S):
        return _TRAFFIC["areas"]
    try:
        src, name = get_source(hour)
        segs = src.fetch(CITY_BBOX)
        _TRAFFIC.update(areas=jam_areas(segs, grid_km=1.2), fetched_at=now,
                        source=name, segments=len(segs), hour=hour)
    except Exception as exc:  # noqa: BLE001
        log.warning("traffic refresh failed (%s); routing free-flow", exc)
        _TRAFFIC.update(areas={}, fetched_at=now, source="unavailable",
                        segments=0, hour=hour)
    return _TRAFFIC["areas"]
AREA_DIR = Path(os.environ.get("AREA_DIR", "routing/data/custom_areas"))

_FIELDS: dict[str, np.ndarray] = {}
_SPEC = FieldSpec(bbox=CITY_BBOX, cell_m=40.0, sigma_m=110.0)


def load_fields() -> None:
    """Load baked .npy surfaces. Called at startup and after a bake swap."""
    _FIELDS.clear()
    if not FIELD_DIR.exists():
        log.warning("no field directory at %s — /score will 503", FIELD_DIR)
        return
    for p in FIELD_DIR.glob("*.npy"):
        _FIELDS[p.stem] = np.load(p)
    log.info("loaded %d surfaces: %s", len(_FIELDS), sorted(_FIELDS))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    load_fields()
    yield


app.router.lifespan_context = lifespan


class ProfileIn(BaseModel):
    mode: Literal["pedestrian", "vehicle"] = "pedestrian"
    concerns: list[str] = Field(default_factory=list)
    hour: int = Field(22, ge=0, le=23)
    safety: float = Field(0.6, ge=0.0, le=1.0)

    @field_validator("concerns")
    @classmethod
    def known_concerns(cls, v: list[str]) -> list[str]:
        allowed = {"alone", "with_children", "carrying_valuables", "unfamiliar_area"}
        bad = set(v) - allowed
        if bad:
            raise ValueError(f"unknown concerns: {sorted(bad)}. allowed: {sorted(allowed)}")
        return v

    def to_profile(self) -> Profile:
        return Profile(mode=self.mode, concerns=self.concerns,
                       hour=self.hour, safety=self.safety)


class ScoreRequest(BaseModel):
    #: [[lon, lat], ...] — a route polyline from ANY router, including the
    #: caller's own. Decoupling scoring from routing is deliberate: it is what
    #: makes this licensable to someone who already has a router.
    coordinates: list[tuple[float, float]] = Field(..., min_length=2, max_length=20000)
    profile: ProfileIn = Field(default_factory=ProfileIn)
    segment_m: float = Field(50.0, gt=5.0, le=500.0)


class SegmentScore(BaseModel):
    start_index: int
    lon: float
    lat: float
    exposure: float
    band: str


class ScoreResponse(BaseModel):
    exposure_index: float
    peak_exposure: float
    length_m: float
    segments: list[SegmentScore]
    surface: str
    baked_at: Optional[str]
    methodology: str


BAND_EDGES = [("quiet", 0.0), ("elevated", 0.35), ("high", 0.55),
              ("severe", 0.72), ("keepout", 0.85)]


def band_for(x: float) -> str:
    name = "quiet"
    for n, lo in BAND_EDGES:
        if x >= lo:
            name = n
    return name


def surface_name(p: Profile) -> str:
    layer = "person" if p.mode == "pedestrian" else "property"
    return f"{layer}_{p.tod}"


def _manifest() -> dict:
    mp = AREA_DIR.parent / f"{AREA_DIR.name}_manifest.json"
    if mp.exists():
        try:
            return json.loads(mp.read_text())
        except Exception:
            return {}
    return {}


@app.post("/score", response_model=ScoreResponse)
def score(req: ScoreRequest) -> ScoreResponse:
    prof = req.profile.to_profile()
    name = surface_name(prof)
    field = _FIELDS.get(name)
    if field is None:
        raise HTTPException(
            503,
            f"surface {name!r} not baked. Run `make bake`, or use /route which "
            f"works in live mode with no bake at all.")

    # Densify FIRST. Router geometry is simplified; sampling its vertices
    # skips everything between them. See kde.densify.
    lon, lat = densify(
        [c[0] for c in req.coordinates],
        [c[1] for c in req.coordinates],
        spacing_m=min(req.segment_m / 2.0, 25.0),
    )
    raw = sample_field(field, _SPEC, lon, lat)
    exposure = to_exposure(raw)

    from ..scoring.kde import M_PER_DEG_LAT, M_PER_DEG_LON
    dx = np.diff(lon) * M_PER_DEG_LON
    dy = np.diff(lat) * M_PER_DEG_LAT
    seg_len = np.hypot(dx, dy)
    total = float(seg_len.sum())

    # length-weighted mean: a short pass through a hot block should not count
    # the same as a long one
    mid = (exposure[:-1] + exposure[1:]) / 2.0
    idx = float((mid * seg_len).sum() / total) if total > 0 else 0.0

    segments: list[SegmentScore] = []
    acc, start = 0.0, 0
    for i, L in enumerate(seg_len):
        acc += L
        if acc >= req.segment_m or i == len(seg_len) - 1:
            e = float(np.mean(exposure[start:i + 2]))
            segments.append(SegmentScore(
                start_index=start, lon=float(lon[start]), lat=float(lat[start]),
                exposure=round(e, 4), band=band_for(e),
            ))
            acc, start = 0.0, i + 1

    return ScoreResponse(
        exposure_index=round(idx, 4),
        peak_exposure=round(float(exposure.max()), 4),
        length_m=round(total, 1),
        segments=segments,
        surface=name,
        baked_at=_manifest().get("baked_at"),
        methodology="https://bearing.example/methodology — scores REPORTED incidents; "
                    "block-level geocoding; no demographic inputs",
    )


class RouteRequest(BaseModel):
    origin: tuple[float, float]
    destination: tuple[float, float]
    profile: ProfileIn = Field(default_factory=ProfileIn)
    #: When present, the offer is logged automatically and the returned
    #: offer_id is what the client posts back on selection. Recording the offer
    #: server-side rather than trusting the client to do it means we cannot
    #: silently lose the denominator of the gate metric.
    session_id: Optional[str] = None


def _gh_post(body: dict) -> dict:
    req = urllib.request.Request(
        f"{GRAPHHOPPER}/route",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


@app.post("/route")
def route(req: RouteRequest) -> dict:
    base = req.profile.to_profile()
    pts = [req.origin, req.destination]
    traffic = refresh_traffic(base.hour) if base.mode == "vehicle" else {}

    # ---- live mode: two passes ----
    # Pass 1 finds the corridor with no risk weighting; we only need its shape.
    # Then we fetch incidents for that corridor's bbox and score them. Pass 2
    # (below, per variant) routes again with those polygons sent inline.
    risk_areas: dict = {}
    live_meta = None
    if live_enabled():
        try:
            scout = ROUTER.route(
                routing_request(route_variants(base)["fastest"], pts,
                                instructions=False),
                mode=base.mode)
            corridor = scout.path["points"]["coordinates"]
        except RouterError:
            corridor = pts
        la = build_live_areas(live_source(), corridor,
                              mode=base.mode, hour=base.hour)
        risk_areas = la.areas
        live_meta = {
            "incidents": la.incident_count,
            "fetch_ms": round(la.fetch_s * 1000, 1),
            "score_ms": round(la.score_s * 1000, 1),
            "cache_hit": la.cache_hit,
            "areas": la.names,
            "payload_kb": round(payload_kb(la.areas), 1),
        }

    out: dict[str, dict] = {}
    for label, prof in route_variants(base).items():
        try:
            rr = ROUTER.route(
                routing_request(prof, pts, traffic_areas=traffic,
                                risk_areas=risk_areas or None),
                mode=base.mode)
        except RouterError as exc:
            raise HTTPException(502, str(exc)) from exc
        path = rr.path
        coords = path["points"]["coordinates"]
        sc = score(ScoreRequest(
            coordinates=[(c[0], c[1]) for c in coords],
            profile=req.profile,
        ))
        out[label] = {
            "minutes": round(path["time"] / 60000.0, 1),
            "distance_m": round(path["distance"], 1),
            "exposure_index": sc.exposure_index,
            "peak_exposure": sc.peak_exposure,
            "coordinates": coords,
            "instructions": path.get("instructions", []),
            "safety": prof.safety,
        }

    if "fastest" in out:
        base_exp = out["fastest"]["exposure_index"]
        base_min = out["fastest"]["minutes"]
        for label, r in out.items():
            r["extra_minutes"] = round(r["minutes"] - base_min, 1)
            # A percentage reduction against a near-zero baseline is noise
            # dressed as a headline. If the fastest route is already clean,
            # say so with 0 rather than reporting "-100%".
            if base_exp < 0.02:
                r["exposure_reduction_pct"] = 0.0
                r["baseline_already_low"] = True
            else:
                r["exposure_reduction_pct"] = round(
                    max(0.0, 100.0 * (1 - r["exposure_index"] / base_exp)), 1)
                r["baseline_already_low"] = False
    # Deduplicate identical geometries, as a real nav app does.
    seen, deduped = set(), {}
    for label in ("fastest", "balanced", "safest"):
        r = out.get(label)
        if not r:
            continue
        key = json.dumps(r["coordinates"])
        if key in seen:
            continue
        seen.add(key)
        deduped[label] = r

    offer_id = None
    if req.session_id:
        offer_id = TELEMETRY.record_offer(Offer(
            session_id=req.session_id,
            mode=req.profile.mode,
            hour_local=req.profile.hour,
            concerns=req.profile.concerns,
            origin=req.origin, destination=req.destination,
            options={
                k: RouteOption(
                    label=k, minutes=v["minutes"], distance_m=v["distance_m"],
                    exposure_index=v["exposure_index"],
                    extra_minutes=v.get("extra_minutes", 0.0),
                    exposure_reduction_pct=v.get("exposure_reduction_pct", 0.0),
                )
                for k, v in deduped.items()
            },
        ))

    return {
        "routes": deduped,
        "profile": req.profile.model_dump(),
        "offer_id": offer_id,
        "live": live_meta,
        "backend": ROUTER.backend,
        "traffic": {
            "source": _TRAFFIC.get("source"),
            "jam_areas": len(traffic),
            "fetched_at": _TRAFFIC["fetched_at"].isoformat()
                          if _TRAFFIC.get("fetched_at") else None,
        },
    }


# ---------------------------------------------------------------------------
# Map layers
# ---------------------------------------------------------------------------

@app.get("/areas/{layer}")
def areas(layer: str) -> dict:
    """Serve baked band polygons so the client draws the REAL risk surface.

    The client must never re-derive risk zones from incidents itself: it would
    drift from what the router actually used, and a map that disagrees with the
    route it is explaining is worse than no map.
    """
    safe = layer.replace("/", "").replace("..", "")
    path = AREA_DIR / f"{safe}.geojson"
    if not path.exists():
        raise HTTPException(404, f"no such area layer: {safe}")
    return json.loads(path.read_text())


@app.get("/areas")
def area_index() -> dict:
    if not AREA_DIR.exists():
        return {"layers": [], "baked_at": None}
    return {
        "layers": sorted(p.stem for p in AREA_DIR.glob("*.geojson")),
        "baked_at": _manifest().get("baked_at"),
        "bbox": list(CITY_BBOX),
    }


@app.get("/traffic")
def traffic(hour: int = -1) -> dict:
    """Current congestion zones, for the map overlay.

    Returned as a FeatureCollection so the client draws them exactly as it
    draws risk bands — same shape, same renderer, no special case.
    """
    h = hour if 0 <= hour <= 23 else datetime.now().hour
    areas = refresh_traffic(h)
    return {
        "type": "FeatureCollection",
        "features": list(areas.values()),
        "source": _TRAFFIC.get("source"),
        "is_synthetic": _TRAFFIC.get("source") == "synthetic",
        "fetched_at": _TRAFFIC["fetched_at"].isoformat()
                      if _TRAFFIC.get("fetched_at") else None,
    }


# ---------------------------------------------------------------------------
# Telemetry — the Phase 1 deliverable
# ---------------------------------------------------------------------------

class OfferIn(BaseModel):
    session_id: str = Field(..., min_length=6, max_length=64)
    mode: Literal["pedestrian", "vehicle"]
    hour_local: int = Field(..., ge=0, le=23)
    concerns: list[str] = Field(default_factory=list)
    origin: Optional[tuple[float, float]] = None
    destination: Optional[tuple[float, float]] = None
    options: dict[str, dict]


class SelectionIn(BaseModel):
    offer_id: str
    selected: str
    nav_started: bool = False


class CompletionIn(BaseModel):
    offer_id: str
    completed: bool
    deviation_m: Optional[float] = None


@app.post("/telemetry/offer")
def telemetry_offer(body: OfferIn) -> dict:
    opts = {
        k: RouteOption(
            label=k,
            minutes=float(v.get("minutes", 0)),
            distance_m=float(v.get("distance_m", 0)),
            exposure_index=float(v.get("exposure_index", 0)),
            extra_minutes=float(v.get("extra_minutes", 0)),
            exposure_reduction_pct=float(v.get("exposure_reduction_pct", 0)),
        )
        for k, v in body.options.items()
    }
    oid = TELEMETRY.record_offer(Offer(
        session_id=body.session_id, mode=body.mode, hour_local=body.hour_local,
        concerns=body.concerns, origin=body.origin, destination=body.destination,
        options=opts,
    ))
    return {"offer_id": oid}


@app.post("/telemetry/selection")
def telemetry_selection(body: SelectionIn) -> dict:
    TELEMETRY.record_selection(body.offer_id, body.selected, body.nav_started)
    return {"ok": True}


@app.post("/telemetry/completion")
def telemetry_completion(body: CompletionIn) -> dict:
    TELEMETRY.record_completion(body.offer_id, body.completed, body.deviation_m)
    return {"ok": True}


@app.get("/gate")
def gate() -> dict:
    """The number the company turns on."""
    return gate_report(TELEMETRY)


@app.get("/gate/text", response_class=PlainTextResponse)
def gate_text() -> str:
    return format_gate(gate_report(TELEMETRY))


@app.get("/health")
def health() -> dict:
    m = _manifest()
    return {
        "ok": bool(_FIELDS),
        "surfaces": sorted(_FIELDS),
        "baked_at": m.get("baked_at"),
        "taxonomy_sha": m.get("taxonomy_sha"),
        "incident_count": m.get("incident_count"),
        "mode": "live" if live_enabled() else "baked",
        "router": ROUTER.health(),
        "traffic_source": _TRAFFIC.get("source") or "not yet fetched",
        "traffic_is_synthetic": _TRAFFIC.get("source") == "synthetic",
        "now": datetime.now(timezone.utc).isoformat(),
    }

"""Profile -> GraphHopper custom model.

The user-facing product has a mode, a set of trip conditions, and a safety
slider. GraphHopper wants a custom model with a `priority` section. This module
is the whole translation, and it is the only place the mapping lives.

GraphHopper's weighting is:
    edge_weight = distance / (speed * priority) + distance * distance_influence

so a priority of 0.5 roughly doubles an edge's cost. Priorities from separate
matching rules multiply, which is what we want: a segment that is both in a
person-risk band and unlit should compound.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional

Mode = Literal["pedestrian", "vehicle"]

#: Base penalty per band at safety = 1.0. Lower = more strongly avoided.
BAND_PENALTY = {
    "elevated": 0.80,
    "high": 0.55,
    "severe": 0.32,
    "keepout": 0.10,
}

#: Which risk layer a mode cares about, and how much.
LAYER_FOR_MODE = {
    "pedestrian": {"person": 1.0, "property": 0.10},
    "vehicle": {"person": 0.25, "property": 1.0},
}

#: Trip conditions scale the person layer. These are situational, never
#: demographic — see docs/methodology.md.
CONCERN_SCALE = {
    "alone": 1.35,
    "with_children": 1.25,
    "carrying_valuables": 1.15,
    "unfamiliar_area": 1.15,
}

CONCERN_SCALE_PROPERTY = {
    "carrying_valuables": 1.45,
}

GH_PROFILES = {"pedestrian": "foot_safe", "vehicle": "car_safe"}

#: distance_influence floor per mode, and how far the safety slider raises it.
#:
#: GraphHopper rejects any request whose custom_model has a smaller
#: distance_influence than the base profile's, and the CAR base carries a
#: built-in default of 90 that an empty custom_model_files does NOT override:
#:     CustomModel in query can only use distance_influence
#:     bigger or equal to 90.0
#: So the vehicle floor is 90, not 30. Found by routing, not by reading.
DISTANCE_INFLUENCE = {
    "pedestrian": (30.0, 50.0),   # 30 at safety=0 -> 80 at safety=1
    "vehicle": (90.0, 60.0),      # 90 at safety=0 -> 150 at safety=1
}


@dataclass
class Profile:
    mode: Mode = "pedestrian"
    concerns: list[str] = field(default_factory=list)
    hour: int = 22
    safety: float = 0.6          # 0.0 = fastest, 1.0 = maximum avoidance
    avoid_unlit: bool = True

    @property
    def is_night(self) -> bool:
        return self.hour >= 20 or self.hour < 6

    @property
    def tod(self) -> str:
        return "night" if self.is_night else "day"

    def layer_weights(self) -> dict[str, float]:
        base = dict(LAYER_FOR_MODE[self.mode])
        for c in self.concerns:
            base["person"] *= CONCERN_SCALE.get(c, 1.0)
            base["property"] *= CONCERN_SCALE_PROPERTY.get(c, 1.0)
        return base


def _blend(penalty: float, strength: float) -> float:
    """Interpolate between no penalty (1.0) and the full band penalty."""
    strength = max(0.0, min(strength, 3.0))
    return max(0.02, 1.0 - (1.0 - penalty) * strength)


def build_custom_model(p: Profile, area_names: Optional[set] = None,
                       area_prefix: str = "") -> dict:
    """Build the priority rules.

    `area_names` restricts output to areas that actually exist. In live mode a
    corridor may produce only two of the four bands, and referencing an absent
    area is a hard request-time failure:
        Cannot compile expression: Area 'person_night_severe' wasn't found
    In baked mode every band file is always written, so this is None and every
    rule is emitted.
    """
    if not 0.0 <= p.safety <= 1.0:
        raise ValueError("safety must be in [0, 1]")

    rules: list[dict] = []
    weights = p.layer_weights()

    for layer, lw in weights.items():
        strength = p.safety * lw
        if strength <= 0.01:
            continue
        for band, penalty in BAND_PENALTY.items():
            mult = _blend(penalty, strength)
            if mult >= 0.995:
                continue
            name = f"{area_prefix}{layer}_{p.tod}_{band}"
            if area_names is not None and name not in area_names:
                continue
            rules.append({"if": f"in_{name}", "multiply_by": round(mult, 4)})

    if p.avoid_unlit and p.is_night and p.mode == "pedestrian":
        unlit = _blend(0.70, p.safety)
        has_unlit = area_names is None or "unlit_street" in area_names
        if unlit < 0.995 and has_unlit:   # never emit a no-op or dangling rule
            rules.append({"if": "in_unlit_street", "multiply_by": round(unlit, 4)})

    model: dict = {"priority": rules}

    # distance_influence trades detour length against everything else. At high
    # safety we still need a brake, or the router will accept an absurd detour
    # to shave the last sliver of exposure.
    floor, span = DISTANCE_INFLUENCE[p.mode]
    model["distance_influence"] = round(floor + span * p.safety, 1)
    return model


def routing_request(
    p: Profile,
    points: list[tuple[float, float]],
    locale: str = "en",
    instructions: bool = True,
    traffic_areas: Optional[dict] = None,
    risk_areas: Optional[dict] = None,
) -> dict:
    """Full POST body for GraphHopper /route.

    `traffic_areas` are live congestion polygons from bearing.traffic. They ride
    along INLINE with the request rather than living in custom_areas.directory,
    because traffic changes every few minutes and custom areas are only read at
    graph import time. Same mechanism as the risk bands, different refresh rate.
    """
    from .live import LIVE_PREFIX
    model = build_custom_model(
        p,
        area_names=set(risk_areas) if risk_areas else None,
        area_prefix=LIVE_PREFIX if risk_areas else "",
    )

    # Live mode sends the risk polygons with the request instead of relying on
    # areas baked into the graph. Same predicate names either way, so the
    # priority rules built above do not change.
    inline: dict = {}
    if risk_areas:
        inline.update(risk_areas)
    if traffic_areas and p.mode == "vehicle":
        from .traffic import traffic_speed_rules
        inline.update(traffic_areas)
        # speed, not priority: congestion must change the ETA, not merely make
        # the router dislike the road
        model["speed"] = traffic_speed_rules(traffic_areas)
    if inline:
        model["areas"] = {"type": "FeatureCollection",
                          "features": list(inline.values())}
    return {
        "points": [[lon, lat] for lon, lat in points],
        "profile": GH_PROFILES[p.mode],
        "ch.disable": True,   # CH-prepared profiles cannot be customised per request
        "custom_model": model,
        "instructions": instructions,
        "locale": locale,
        "points_encoded": False,
        "details": ["road_class", "street_name"],
        "algorithm": "alternative_route",
        "alternative_route.max_paths": 3,
    }


def route_variants(p: Profile) -> dict[str, Profile]:
    """The three options the app shows."""
    from dataclasses import replace
    return {
        "fastest": replace(p, safety=0.0),
        "balanced": replace(p, safety=min(p.safety, 0.55)),
        "safest": replace(p, safety=1.0),
    }

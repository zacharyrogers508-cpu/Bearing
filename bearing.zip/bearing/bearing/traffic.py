"""Live traffic.

The missing half of "fastest and safest". Crime data tells you where not to go;
traffic tells you how long the alternatives actually take. Without it, driving
ETAs are free-flow fiction.

Buy this, do not build it. The incumbents' advantage here is probe data from
hundreds of millions of devices and it is not reachable. TomTom and HERE both
sell exactly what is needed.

How it plugs in
---------------
GraphHopper's custom model can scale speed per area, the same mechanism the
risk bands use:

    {"speed": [{"if": "in_jam_heavy", "multiply_by": 0.35}]}

So congestion becomes a set of area polygons on the same footing as risk bands,
refreshed on a short cycle. That keeps one mechanism in the system instead of
two, and means traffic needs no fork either.

Refresh cadence is the one real difference: risk bands rebake nightly, traffic
wants 2-5 minutes. Custom areas are read at import, so a 3-minute graph reimport
is not viable. Two options, in order of preference:

  1. Post traffic areas INLINE in the request custom_model. GraphHopper accepts
     an `areas` object per request, so live jams ride along with the query and
     never touch the graph. Costs request size; needs no reimport. Use this.
  2. Reimport on a slow cycle (30-60 min) for coarse background congestion,
     inline only the fast-moving incidents.
"""
from __future__ import annotations

import json
import math
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Optional, Sequence

#: Jam severity -> speed multiplier applied in the custom model.
JAM_BANDS = {
    "light": 0.75,
    "moderate": 0.55,
    "heavy": 0.35,
    "closed": 0.05,
}


@dataclass
class FlowSegment:
    """One road segment's observed speed."""
    lon: float
    lat: float
    current_kph: float
    freeflow_kph: float
    confidence: float = 1.0
    closed: bool = False

    @property
    def ratio(self) -> float:
        if self.freeflow_kph <= 0:
            return 1.0
        return max(0.0, min(1.5, self.current_kph / self.freeflow_kph))

    @property
    def band(self) -> Optional[str]:
        if self.closed:
            return "closed"
        r = self.ratio
        if r >= 0.85:
            return None          # free flowing; no penalty, no polygon
        if r >= 0.65:
            return "light"
        if r >= 0.40:
            return "moderate"
        return "heavy"


class TrafficSource:
    """Interface. Implement `fetch` and the rest of the system does not care."""

    def fetch(self, bbox: Sequence[float]) -> list[FlowSegment]:
        raise NotImplementedError


class TomTomFlow(TrafficSource):
    """TomTom Traffic Flow Segment Data.

    Needs TOMTOM_API_KEY. Verify current pricing before committing — TomTom
    changed rates effective 1 July 2026.

    Note this samples flow at a grid of points rather than pulling their bulk
    feed. The bulk product is the right thing at scale; point sampling is the
    cheap way to get a real signal running in an afternoon.
    """

    BASE = "https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json"

    def __init__(self, api_key: Optional[str] = None, grid_km: float = 1.2):
        self.key = api_key or os.environ.get("TOMTOM_API_KEY")
        self.grid_km = grid_km   # jam_areas derives its buffer radius from this

    def fetch(self, bbox: Sequence[float]) -> list[FlowSegment]:
        if not self.key:
            raise RuntimeError("TOMTOM_API_KEY not set")
        lo_lon, lo_lat, hi_lon, hi_lat = bbox
        dlat = self.grid_km / 111.132
        dlon = self.grid_km / (111.320 * math.cos(math.radians((lo_lat + hi_lat) / 2)))

        out: list[FlowSegment] = []
        lat = lo_lat
        while lat <= hi_lat:
            lon = lo_lon
            while lon <= hi_lon:
                seg = self._point(lat, lon)
                if seg:
                    out.append(seg)
                lon += dlon
            lat += dlat
        return out

    def _point(self, lat: float, lon: float) -> Optional[FlowSegment]:
        qs = urllib.parse.urlencode({"key": self.key, "point": f"{lat},{lon}"})
        try:
            with urllib.request.urlopen(f"{self.BASE}?{qs}", timeout=20) as r:
                d = json.loads(r.read().decode()).get("flowSegmentData", {})
        except (urllib.error.HTTPError, urllib.error.URLError, ValueError):
            return None
        if not d:
            return None
        return FlowSegment(
            lon=lon, lat=lat,
            current_kph=float(d.get("currentSpeed", 0)),
            freeflow_kph=float(d.get("freeFlowSpeed", 0) or 1),
            confidence=float(d.get("confidence", 1.0)),
            closed=bool(d.get("roadClosure", False)),
        )


class SyntheticFlow(TrafficSource):
    """Plausible rush-hour congestion, for running without a paid key.

    Clearly labelled as synthetic in /health so nobody mistakes a demo for a
    measurement.
    """

    def __init__(self, hour: int = 18, seed: int = 5, grid_km: float = 1.2):
        self.hour = hour
        self.seed = seed
        self.grid_km = grid_km

    def fetch(self, bbox: Sequence[float]) -> list[FlowSegment]:
        """Sample on the same regular grid a real point-sampled source uses,
        so coverage behaviour in the demo matches production."""
        import random
        rnd = random.Random(self.seed + self.hour)
        lo_lon, lo_lat, hi_lon, hi_lat = bbox
        dlat = self.grid_km / 111.132
        dlon = self.grid_km / (111.320 * math.cos(math.radians((lo_lat + hi_lat) / 2)))
        peak = 1.0 if self.hour in (7, 8, 9, 16, 17, 18, 19) else 0.2
        # congestion clusters toward the centre, as it does in a real city
        cx, cy = (lo_lon + hi_lon) / 2, (lo_lat + hi_lat) / 2

        out = []
        lat = lo_lat
        while lat <= hi_lat:
            lon = lo_lon
            while lon <= hi_lon:
                d = math.hypot((lon - cx) / (hi_lon - lo_lon),
                               (lat - cy) / (hi_lat - lo_lat))
                central = max(0.0, 1.0 - d * 2.2)
                sev = peak * central * (0.55 + 0.45 * rnd.random())
                ff = rnd.choice([48.0, 56.0, 40.0])
                out.append(FlowSegment(lon=lon, lat=lat,
                                       freeflow_kph=ff,
                                       current_kph=ff * (1.0 - 0.8 * sev),
                                       closed=sev > 0.93))
                lon += dlon
            lat += dlat
        return out


# ---------------------------------------------------------------------------
# segments -> GraphHopper areas
# ---------------------------------------------------------------------------

def jam_areas(segments: Iterable[FlowSegment], radius_m: Optional[float] = None,
              grid_km: float = 1.2) -> dict:
    """Build inline `areas` for a request custom_model, one per jam band.

    Inline rather than written to custom_areas.directory: traffic changes every
    few minutes and custom areas are only read at graph import. Sending them
    with the query keeps the graph stable and the traffic fresh.

    RADIUS MUST MATCH THE SAMPLING GRID. This is the trap. With point-sampled
    flow on a 1.2 km grid and a 220 m buffer, the polygons cover ~3% of the
    city, routes thread the gaps, and traffic silently does nothing — no error,
    no warning, identical ETAs. It looks like the integration is broken when it
    is actually working perfectly on data that has holes in it.

    Default radius is therefore derived from the grid: each sample point owns
    its cell. If you move to a bulk feed with real segment geometry, pass an
    explicit small radius instead.
    """
    if radius_m is None:
        radius_m = grid_km * 1000 * 0.75   # cover the cell, slight overlap
    from shapely.geometry import Point, mapping
    from shapely.ops import unary_union

    buckets: dict[str, list] = {}
    for s in segments:
        band = s.band
        if band is None or s.confidence < 0.4:
            continue
        buckets.setdefault(band, []).append(
            Point(s.lon, s.lat).buffer(radius_m / 111_320.0, quad_segs=5))

    areas: dict[str, dict] = {}
    for band, pts in buckets.items():
        merged = unary_union(pts).simplify(0.00002, preserve_topology=True)
        geoms = [g for g in getattr(merged, "geoms", [merged])
                 if g.geom_type == "Polygon" and not g.is_empty]
        if not geoms:
            continue
        areas[f"jam_{band}"] = {
            "type": "Feature",
            "id": f"jam_{band}",
            "properties": {"band": band, "multiplier": JAM_BANDS[band]},
            "geometry": {"type": "MultiPolygon",
                         "coordinates": [mapping(g)["coordinates"] for g in geoms]},
        }
    return areas


def traffic_speed_rules(areas: dict) -> list[dict]:
    """Speed multipliers for the custom model's `speed` section.

    Speed, not priority: congestion should change the ETA, not just make the
    router dislike the road. Priority alone would route around a jam while
    still reporting a free-flow arrival time.
    """
    rules = []
    for name, feat in areas.items():
        band = feat["properties"]["band"]
        rules.append({"if": f"in_{name}", "multiply_by": JAM_BANDS[band]})
    # heaviest first so the strictest rule is obvious when reading a request
    order = {"closed": 0, "heavy": 1, "moderate": 2, "light": 3}
    rules.sort(key=lambda r: order.get(r["if"].replace("in_jam_", ""), 9))
    return rules


def get_source(hour: int = 18) -> tuple[TrafficSource, str]:
    """Real source if a key is configured, synthetic otherwise."""
    if os.environ.get("TOMTOM_API_KEY"):
        return TomTomFlow(), "tomtom"
    return SyntheticFlow(hour=hour), "synthetic"

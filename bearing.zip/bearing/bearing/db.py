"""Persistence.

Postgres + PostGIS in production, SQLite for the beta and for tests. The two
share column names so the analysis SQL in db/schema.sql ports unchanged.

The fallback is deliberate rather than lazy: the Phase 1 beta should not need
infrastructure to run, and a campus pilot that dies because RDS is unreachable
loses the only data the gate depends on. `DATABASE_URL` upgrades it in place.
"""
from __future__ import annotations

import json
import logging
import os
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator, Optional

log = logging.getLogger(__name__)

DATABASE_URL = os.environ.get("DATABASE_URL")

try:  # psycopg is optional — SQLite path must work without it
    import psycopg
    from psycopg.rows import dict_row
    HAVE_PG = True
except ImportError:  # pragma: no cover
    HAVE_PG = False


class IncidentRepo:
    """Upsert incidents. Idempotent on (source, source_id).

    Idempotence matters more than it looks: the Chicago feed republishes
    records when a preliminary classification is revised, and the watermark is
    on `updated_on`, so re-ingesting the same incident is the normal case, not
    an error path.
    """

    def __init__(self, url: Optional[str] = None):
        self.url = url or DATABASE_URL
        if self.url and not HAVE_PG:
            raise RuntimeError("DATABASE_URL set but psycopg is not installed")

    @contextmanager
    def _conn(self) -> Iterator:
        with psycopg.connect(self.url, row_factory=dict_row) as conn:
            yield conn

    def upsert_many(self, incidents: Iterable) -> int:
        rows = [
            (
                i.source, i.source_id, i.occurred_at, i.lon, i.lat,
                i.canonical, i.weight, i.ped_relevance, i.veh_relevance,
                i.geocode_precision_m, i.raw_type, i.raw_description,
                i.location_description, i.arrest, i.beat,
            )
            for i in incidents
        ]
        if not rows:
            return 0
        sql = """
            INSERT INTO incident (
                source, source_id, occurred_at, geom, canonical, weight,
                ped_relevance, veh_relevance, geocode_precision_m,
                raw_type, raw_description, location_description, arrest, beat
            ) VALUES (
                %s, %s, %s, ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            ON CONFLICT (source, source_id) DO UPDATE SET
                occurred_at = EXCLUDED.occurred_at,
                geom = EXCLUDED.geom,
                canonical = EXCLUDED.canonical,
                weight = EXCLUDED.weight,
                ped_relevance = EXCLUDED.ped_relevance,
                veh_relevance = EXCLUDED.veh_relevance,
                raw_type = EXCLUDED.raw_type,
                raw_description = EXCLUDED.raw_description,
                location_description = EXCLUDED.location_description
        """
        with self._conn() as c:
            with c.cursor() as cur:
                cur.executemany(sql, rows)
            c.commit()
        return len(rows)

    def load_for_bake(self, lookback_days: int = 365) -> list:
        """Read incidents back in the shape the scorer wants."""
        from .ingest.chicago import Incident
        sql = """
            SELECT source, source_id, occurred_at,
                   ST_X(geom::geometry) AS lon, ST_Y(geom::geometry) AS lat,
                   canonical, weight, ped_relevance, veh_relevance,
                   geocode_precision_m, raw_type, raw_description,
                   location_description, arrest, beat
            FROM incident
            WHERE occurred_at > now() - (%s || ' days')::interval
        """
        with self._conn() as c, c.cursor() as cur:
            cur.execute(sql, (lookback_days,))
            return [
                Incident(
                    source=r["source"], source_id=r["source_id"],
                    occurred_at=r["occurred_at"].strftime("%Y-%m-%dT%H:%M:%S"),
                    lat=r["lat"], lon=r["lon"],
                    canonical=r["canonical"], weight=r["weight"],
                    ped_relevance=r["ped_relevance"], veh_relevance=r["veh_relevance"],
                    raw_type=r["raw_type"] or "", raw_description=r["raw_description"] or "",
                    location_description=r["location_description"] or "",
                    geocode_precision_m=r["geocode_precision_m"],
                    arrest=bool(r["arrest"]), beat=r["beat"],
                )
                for r in cur.fetchall()
            ]

    def record_bake(self, manifest: dict) -> None:
        sql = """
            INSERT INTO bake (taxonomy_sha, spec, layer_counts,
                              incident_count, band_counts, graph_ready)
            VALUES (%s, %s, %s, %s, %s, FALSE)
        """
        with self._conn() as c, c.cursor() as cur:
            cur.execute(sql, (
                manifest["taxonomy_sha"], json.dumps(manifest["spec"]),
                json.dumps(manifest["layer_counts"]), manifest["incident_count"],
                json.dumps(manifest["band_counts"]),
            ))
            c.commit()


def jsonl_sink(path: Path):
    """Append-only fallback when no database is configured."""
    path.parent.mkdir(parents=True, exist_ok=True)

    def write(incidents: Iterable) -> int:
        n = 0
        with path.open("a") as fh:
            for i in incidents:
                fh.write(json.dumps(asdict(i)) + "\n")
                n += 1
        return n

    return write


def get_repo() -> Optional[IncidentRepo]:
    """Return a Postgres repo, or None if the deployment has no database."""
    if not DATABASE_URL:
        return None
    try:
        return IncidentRepo(DATABASE_URL)
    except Exception as exc:  # noqa: BLE001
        log.warning("database unavailable (%s); falling back to JSONL", exc)
        return None

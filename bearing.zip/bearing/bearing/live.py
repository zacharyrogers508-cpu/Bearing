"""Live mode: no bake, no graph, no downloads.

The batch pipeline (ingest -> bake -> import) exists because it is fast at
request time and cheap to serve. But it costs a 450 MB OSM download, a 20-minute
graph import, and a nightly rebake. For getting started, for a city you have not
committed to, or for a serverless deployment, that is a lot of ceremony.

Live mode does the same thing per trip:

  1. Route the fastest path (no risk weighting) to learn the corridor.
  2. Fetch incidents from the city's API for that corridor's bounding box only.
  3. Score them and turn the result into polygons.
  4. Route again with those polygons sent INLINE in the custom model.

Nothing is stored, nothing is imported. The second call is the real route.

Why this works at all
---------------------
GraphHopper accepts `areas` inline in a request's custom_model — the same
mechanism live traffic already uses. So risk zones do not have to live in the
graph. And because a single trip's bounding box is small, we are fetching
hundreds of incidents rather than a quarter million, and scoring a grid of a
few thousand cells rather than a million.

What it costs
-------------
Latency. Two routing calls plus a city API round trip, against ~40 ms for the
baked path. Measured numbers are in the module test; budget 0.6-1.5 s warm and
2-3 s cold.

Use batch mode when you serve a city at volume. Use live mode to start, to add
a city in an afternoon, or when you cannot run a graph at all.
"""
from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional, Sequence

import numpy as np

from .ingest.chicago import CRIMES, CRIME_SELECT, DOMAIN, ChicagoCrimes
from .ingest.socrata import SocrataDataset
from .scoring.bands import DEFAULT_BANDS, resolve_thresholds, SIMPLIFY_DEG, MIN_AREA_M2
from .scoring.kde import (
    FieldSpec, IncidentArray, M_PER_DEG_LAT, M_PER_DEG_LON, build_field,
)
from .taxonomy import LAYERS

log = logging.getLogger(__name__)

#: How far either side of the direct line to look for incidents. Wide enough
#: that a detour has somewhere to go; narrow enough that we are not pulling the
#: whole city. A safest route rarely strays more than ~1 km from the direct line.
CORRIDOR_PAD_M = 1500.0

#: Cache fetched incidents per rounded bbox. Trips in the same neighbourhood
#: reuse the fetch, which is most of the benefit in practice.
CACHE_TTL_S = 900

#: Namespace for request-inline areas. See build_live_areas.
LIVE_PREFIX = "live_"
_CACHE: dict[tuple, tuple[float, list]] = {}


def corridor_bbox(points: Sequence[Sequence[float]],
                  pad_m: float = CORRIDOR_PAD_M) -> tuple[float, float, float, float]:
    lons = [p[0] for p in points]
    lats = [p[1] for p in points]
    dlon = pad_m / M_PER_DEG_LON
    dlat = pad_m / M_PER_DEG_LAT
    return (min(lons) - dlon, min(lats) - dlat, max(lons) + dlon, max(lats) + dlat)


def _cache_key(bbox, days: int) -> tuple:
    return tuple(round(v, 2) for v in bbox) + (days,)


class LiveChicago:
    """Fetch and classify Chicago incidents for one bounding box, on demand."""

    def __init__(self, app_token: Optional[str] = None, lookback_days: int = 270):
        self.ds = SocrataDataset(DOMAIN, CRIMES, app_token)
        self.src = ChicagoCrimes(app_token=app_token)
        self.lookback_days = lookback_days
        self.last_fetch_s = 0.0
        self.last_count = 0
        self.cache_hit = False

    def fetch(self, bbox: Sequence[float], limit: int = 8000) -> list:
        key = _cache_key(bbox, self.lookback_days)
        hit = _CACHE.get(key)
        now = time.time()
        if hit and now - hit[0] < CACHE_TTL_S:
            self.cache_hit = True
            self.last_count = len(hit[1])
            self.last_fetch_s = 0.0
            return hit[1]

        self.cache_hit = False
        floor = datetime.now(timezone.utc) - timedelta(days=self.lookback_days)
        lo_lon, lo_lat, hi_lon, hi_lat = bbox
        # SoQL bounding-box filter. within_box takes (nw_lat, nw_lon, se_lat, se_lon)
        where = (
            f"date > '{floor.strftime('%Y-%m-%dT%H:%M:%S')}' "
            f"AND within_box(location, {hi_lat}, {lo_lon}, {lo_lat}, {hi_lon})"
        )
        t0 = time.time()
        rows = list(self.ds.rows(select=CRIME_SELECT, where=where, limit=limit))
        incidents = [i for i in (self.src._to_incident(r) for r in rows) if i]
        self.last_fetch_s = time.time() - t0
        self.last_count = len(incidents)
        _CACHE[key] = (now, incidents)
        return incidents


class FixtureSource:
    """Stand-in for the city API, filtered to a bbox.

    Lets live mode run and be tested with no network, and makes the latency of
    the scoring half measurable in isolation from the fetch half.
    """

    def __init__(self, incidents: Iterable):
        self._all = list(incidents)
        self.last_fetch_s = 0.0
        self.last_count = 0
        self.cache_hit = False

    def fetch(self, bbox: Sequence[float], limit: int = 8000) -> list:
        lo_lon, lo_lat, hi_lon, hi_lat = bbox
        t0 = time.time()
        out = [i for i in self._all
               if lo_lon <= i.lon <= hi_lon and lo_lat <= i.lat <= hi_lat][:limit]
        self.last_fetch_s = time.time() - t0
        self.last_count = len(out)
        return out


@dataclass
class LiveAreas:
    areas: dict                 # name -> GeoJSON Feature, for the custom model
    incident_count: int
    fetch_s: float
    score_s: float
    cache_hit: bool
    bbox: tuple

    @property
    def names(self) -> list[str]:
        return sorted(self.areas)


def build_live_areas(source, points: Sequence[Sequence[float]], *,
                     mode: str = "pedestrian", hour: int = 22,
                     pad_m: float = CORRIDOR_PAD_M,
                     cell_m: float = 40.0, sigma_m: float = 110.0) -> LiveAreas:
    """Fetch incidents for the corridor and return inline custom-model areas."""
    from shapely.geometry import box as shp_box, mapping
    from shapely.ops import unary_union

    # Live areas MUST NOT collide with areas baked into the graph. Sending an
    # inline area whose name already exists server-side is a hard 400:
    #     area person_night_elevated already exists
    # Namespacing them means live and baked mode can share one server, and you
    # can A/B the two against the same graph.

    bbox = corridor_bbox(points, pad_m)
    incidents = source.fetch(bbox)

    t0 = time.time()
    layer = LAYERS["person"] if mode == "pedestrian" else LAYERS["property"]
    arr = IncidentArray.from_incidents(incidents).subset(layer)
    tod = "night" if (hour >= 20 or hour < 6) else "day"
    layer_name = ("person" if mode == "pedestrian" else "property") + "_" + tod

    areas: dict = {}
    if len(arr) == 0:
        return LiveAreas({}, 0, source.last_fetch_s, time.time() - t0,
                         getattr(source, "cache_hit", False), bbox)

    # Grid over the CORRIDOR only — a few thousand cells, not a million.
    spec = FieldSpec(bbox=bbox, cell_m=cell_m, sigma_m=sigma_m)
    field = build_field(arr, spec, mode, hour=float(hour))

    lo_lon, lo_lat, _, _ = bbox
    half = cell_m / 2.0
    dlon = cell_m / M_PER_DEG_LON
    dlat = cell_m / M_PER_DEG_LAT

    for name, lo, hi in resolve_thresholds(field, DEFAULT_BANDS):
        mask = (field >= lo) & (field < hi)
        ys, xs = np.nonzero(mask)
        if len(xs) == 0:
            continue
        boxes = [
            shp_box(lo_lon + gx * dlon - half / M_PER_DEG_LON,
                    lo_lat + gy * dlat - half / M_PER_DEG_LAT,
                    lo_lon + (gx + 1) * dlon - half / M_PER_DEG_LON,
                    lo_lat + (gy + 1) * dlat - half / M_PER_DEG_LAT)
            for gx, gy in zip(xs, ys)
        ]
        merged = unary_union(boxes).simplify(SIMPLIFY_DEG, preserve_topology=True)
        geoms = [g for g in getattr(merged, "geoms", [merged])
                 if g.geom_type == "Polygon" and not g.is_empty
                 and g.area * M_PER_DEG_LAT * M_PER_DEG_LON >= MIN_AREA_M2]
        if not geoms:
            continue
        area_name = f"{LIVE_PREFIX}{layer_name}_{name}"
        areas[area_name] = {
            "type": "Feature",
            "id": area_name,
            "properties": {"layer": layer_name, "band": name, "live": True},
            "geometry": {"type": "MultiPolygon",
                         "coordinates": [mapping(g)["coordinates"] for g in geoms]},
        }

    return LiveAreas(areas, len(arr), source.last_fetch_s, time.time() - t0,
                     getattr(source, "cache_hit", False), bbox)


def payload_kb(areas: dict) -> float:
    """Request size added by inline areas. Worth watching — this rides along on
    every routing call, and a sloppy simplify tolerance can make it enormous."""
    return len(json.dumps(areas).encode()) / 1024.0

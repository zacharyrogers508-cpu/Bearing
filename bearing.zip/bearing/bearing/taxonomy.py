"""Canonical taxonomy resolution.

The whole point of this module is that adding city #2 should mean adding a CSV,
not writing code. Everything city-specific lives in data/*.csv; this file only
knows how to resolve a match.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DATA = Path(__file__).resolve().parent.parent / "data"

CANONICAL = (
    "person_violent",
    "person_threat",
    "person_theft",
    "property_vehicle",
    "property_other",
    "traffic",
    "excluded",
)

# Which canonical classes roll up into which scored layer.
LAYERS = {
    "person": ("person_violent", "person_threat", "person_theft"),
    "property": ("property_vehicle", "property_other", "traffic"),
}


@dataclass(frozen=True)
class Rule:
    iucr: str
    primary_type: str
    description_pattern: str
    canonical: str
    weight: float

    @property
    def specificity(self) -> int:
        """Higher wins. IUCR exact beats type+description beats type alone."""
        if self.iucr:
            return 3
        if self.description_pattern:
            return 2
        return 1


def _rows(path: Path):
    with path.open() as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            yield line
    return


def load_rules(city: str = "chicago") -> list[Rule]:
    path = DATA / f"taxonomy_{city}.csv"
    reader = csv.DictReader(_rows(path))
    out: list[Rule] = []
    for r in reader:
        canonical = (r["canonical"] or "").strip()
        if canonical not in CANONICAL:
            raise ValueError(f"unknown canonical class {canonical!r} in {path.name}")
        out.append(
            Rule(
                iucr=(r["iucr"] or "").strip().upper(),
                primary_type=(r["primary_type"] or "").strip().upper(),
                description_pattern=(r["description_pattern"] or "").strip().upper(),
                canonical=canonical,
                weight=float(r["weight"] or 0.0),
            )
        )
    return out


def load_street_relevance(city: str = "chicago") -> dict[str, tuple[float, float]]:
    path = DATA / f"street_relevance_{city}.csv"
    out: dict[str, tuple[float, float]] = {}
    for r in csv.DictReader(_rows(path)):
        key = (r["location_description"] or "").strip().upper()
        out[key] = (float(r["pedestrian"]), float(r["vehicle"]))
    if "DEFAULT" not in out:
        raise ValueError(f"{path.name} must define a DEFAULT row")
    return out


class Taxonomy:
    """Resolves a raw source record to (canonical_class, weight)."""

    def __init__(self, city: str = "chicago"):
        self.city = city
        self._rules = load_rules(city)
        self._relevance = load_street_relevance(city)
        # index by primary_type for a cheap first cut
        self._by_type: dict[str, list[Rule]] = {}
        self._by_iucr: dict[str, Rule] = {}
        for rule in self._rules:
            if rule.iucr:
                self._by_iucr[rule.iucr] = rule
            self._by_type.setdefault(rule.primary_type, []).append(rule)

    def classify(
        self,
        primary_type: Optional[str],
        description: Optional[str] = None,
        iucr: Optional[str] = None,
    ) -> tuple[str, float]:
        if iucr:
            hit = self._by_iucr.get(iucr.strip().upper())
            if hit:
                return hit.canonical, hit.weight

        ptype = (primary_type or "").strip().upper()
        desc = (description or "").strip().upper()
        candidates = self._by_type.get(ptype, [])

        best: Optional[Rule] = None
        for rule in candidates:
            if rule.iucr:
                continue  # already handled above; only matches on exact code
            if rule.description_pattern and rule.description_pattern not in desc:
                continue
            if best is None or rule.specificity > best.specificity:
                best = rule

        if best is None:
            # Unmapped primary_type. Excluded rather than guessed: an unmapped
            # offence class silently entering the score is worse than a gap.
            return "excluded", 0.0
        return best.canonical, best.weight

    def street_relevance(self, location_description: Optional[str]) -> tuple[float, float]:
        key = (location_description or "").strip().upper()
        return self._relevance.get(key, self._relevance["DEFAULT"])

    def unmapped_types(self, primary_types) -> set[str]:
        """Ops helper: surface source values we have no rule for.

        Run this after every ingest. CPD adds and renames primary_type values;
        silent drift is how a scoring model rots without anyone noticing.
        """
        known = {t for t in self._by_type if t}
        return {t.strip().upper() for t in primary_types if t} - known

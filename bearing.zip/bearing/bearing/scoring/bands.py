"""Raster -> GeoJSON risk bands for GraphHopper custom areas.

Why bands and not per-edge values
---------------------------------
GraphHopper's supported no-fork extension point is `custom_areas`: GeoJSON
polygons loaded at import that become `in_<name>` predicates usable in a
custom model's `priority` section. Getting an arbitrary float onto every edge
requires forking a TagParser; getting a *band membership* onto every edge is
config. Bands cost us resolution we do not have anyway (see kde.py note 1 —
the source is block-level), so this is a real alignment between what the
engine supports and what the data can honestly say.

Bands are cut on the normalised field so they are comparable across layers.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from shapely.geometry import box, mapping
from shapely.ops import unary_union

from .kde import FieldSpec, to_lonlat

#: Bands are defined by PERCENTILE of the non-trivial field, not by fixed cut
#: points on the normalised value.
#:
#: Fixed cuts looked reasonable and were wrong. Because normalisation clips at
#: the 97th percentile, everything above it piles into the top band — the
#: `keepout` band came out *larger* than `severe`, which is incoherent as a
#: severity ladder. More importantly, fixed cuts make band coverage depend on
#: the shape of the city's distribution, so the fraction of Chicago marked
#: keep-out would drift day to day as incidents land, and routes would lurch
#: for no reason a user could perceive.
#:
#: Percentile bands make coverage stable and predictable: keep-out is always
#: about the worst 0.5% of the walkable city.
#:
#: The absolute floor is the guard against the obvious failure of pure
#: percentiles — in a genuinely quiet city (or a quiet night), the worst 0.5%
#: is still safe, and flagging it as keep-out would be a lie. A cell must be
#: BOTH in the top percentile band AND above the floor to qualify.
DEFAULT_BANDS: tuple[tuple[str, float, float, float], ...] = (
    # name,      pct_lo, pct_hi, absolute_floor
    ("elevated",  92.0,  97.0,   0.18),
    ("high",      97.0,  99.0,   0.30),
    ("severe",    99.0,  99.7,   0.45),
    ("keepout",   99.7, 100.01,  0.60),
)

#: Cells below this contribute nothing and are excluded from the percentile
#: base. Without this, the millions of near-zero cells in a city's quiet
#: majority drag every percentile down toward noise.
FIELD_EPSILON = 0.02

#: Polygon simplification tolerance in degrees (~2 m). Keeps file size sane
#: without moving a boundary further than the geocoding error already does.
SIMPLIFY_DEG = 0.00002

#: Drop specks smaller than this (m^2). A 3-cell blob is noise, and each one
#: costs import time and produces a visually confusing sliver on the map.
MIN_AREA_M2 = 6_000.0


@dataclass
class BandSet:
    layer: str            # e.g. "person_night"
    features: list[dict]

    def geojson(self) -> dict:
        return {"type": "FeatureCollection", "features": self.features}


def _cells_to_polygon(mask: np.ndarray, spec: FieldSpec):
    """Union the cells of a boolean mask into merged polygons."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return None
    half = spec.cell_m / 2.0
    boxes = []
    for gx, gy in zip(xs, ys):
        x0 = gx * spec.cell_m - half
        y0 = gy * spec.cell_m - half
        lon0, lat0 = to_lonlat(np.array([x0]), np.array([y0]), spec.origin)
        lon1, lat1 = to_lonlat(
            np.array([x0 + spec.cell_m]), np.array([y0 + spec.cell_m]), spec.origin
        )
        boxes.append(box(lon0[0], lat0[0], lon1[0], lat1[0]))
    return unary_union(boxes)


def _area_m2(geom) -> float:
    # crude but sufficient for a speck filter at this latitude
    from .kde import M_PER_DEG_LAT, M_PER_DEG_LON
    return geom.area * M_PER_DEG_LAT * M_PER_DEG_LON


def resolve_thresholds(
    field: np.ndarray,
    bands: Sequence[tuple[str, float, float, float]] = DEFAULT_BANDS,
) -> list[tuple[str, float, float]]:
    """Turn percentile bands into concrete (name, lo, hi) value cuts.

    Returns cuts in field units, with the absolute floor applied. A band whose
    percentile cut falls below its floor is raised to the floor, which can make
    it empty — that is the intended behaviour for a quiet city.
    """
    base = field[field >= FIELD_EPSILON]
    if base.size == 0:
        return [(name, 1.01, 1.02) for name, *_ in bands]

    out: list[tuple[str, float, float]] = []
    for name, p_lo, p_hi, floor in bands:
        lo = max(float(np.percentile(base, min(p_lo, 100.0))), floor)
        hi = (
            float("inf") if p_hi > 100.0
            else max(float(np.percentile(base, min(p_hi, 100.0))), floor)
        )
        if hi <= lo:
            hi = float("inf") if p_hi > 100.0 else lo
        out.append((name, lo, hi))
    return out


def extract_bands(
    field: np.ndarray,
    spec: FieldSpec,
    layer: str,
    bands: Sequence[tuple[str, float, float, float]] = DEFAULT_BANDS,
) -> BandSet:
    features: list[dict] = []
    for name, lo, hi in resolve_thresholds(field, bands):
        mask = (field >= lo) & (field < hi)
        merged = _cells_to_polygon(mask, spec)
        if merged is None or merged.is_empty:
            continue
        merged = merged.simplify(SIMPLIFY_DEG, preserve_topology=True)

        geoms = list(getattr(merged, "geoms", [merged]))
        for i, g in enumerate(geoms):
            if g.is_empty or g.geom_type != "Polygon":
                continue
            if _area_m2(g) < MIN_AREA_M2:
                continue
            features.append({
                "type": "Feature",
                "id": f"{layer}_{name}_{i}",
                "properties": {
                    "layer": layer,
                    "band": name,
                    "area_name": f"{layer}_{name}",
                    "lo": round(lo, 4),
                    "hi": None if hi == float("inf") else round(hi, 4),
                },
                "geometry": mapping(g),
            })
    return BandSet(layer=layer, features=features)


def write_custom_areas(bandsets: Sequence[BandSet], out_dir: Path) -> dict[str, int]:
    """Write one GeoJSON per (layer, band) into GraphHopper's custom_areas dir.

    THE AREA NAME COMES FROM THE FEATURE `id`, NOT THE FILENAME.
    ------------------------------------------------------------
    This cost a rebuild to discover and is not obvious from the docs. Writing
    N features named `person_night_keepout_0..N` into person_night_keepout.geojson
    produces N separate areas, and `in_person_night_keepout` does not exist:

        Cannot compile expression: Area 'person_night_keepout' wasn't found

    Giving every feature the same id does not work either — GraphHopper rejects
    the import outright with `area testA already exists`.

    So each band is emitted as ONE Feature with a MultiPolygon geometry whose
    `id` is the band name. Verified against GraphHopper 10.0: the area count
    drops to one per band and `in_person_night_keepout` compiles and deflects
    routing. The custom-models doc says a member "must be a Feature with a
    geometry type Polygon"; MultiPolygon is in fact accepted and is the only
    way to get one predicate per band.

    Also: nothing but area GeoJSON may live in this directory. GraphHopper
    parses every file in it as a JsonFeatureCollection and dies on unknown
    top-level keys, which is why the bake manifest is written to the parent.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    counts: dict[str, int] = {}
    grouped: dict[str, list[dict]] = {}
    for bs in bandsets:
        for feat in bs.features:
            grouped.setdefault(feat["properties"]["area_name"], []).append(feat)

    for area_name, feats in grouped.items():
        polygons = [f["geometry"]["coordinates"] for f in feats]
        first = feats[0]["properties"]
        feature = {
            "type": "Feature",
            "id": area_name,          # <- this is what becomes in_<area_name>
            "properties": {
                "layer": first["layer"],
                "band": first["band"],
                "area_name": area_name,
                "polygon_count": len(polygons),
                "lo": first["lo"],
                "hi": first["hi"],
            },
            "geometry": {"type": "MultiPolygon", "coordinates": polygons},
        }
        (out_dir / f"{area_name}.geojson").write_text(json.dumps(
            {"type": "FeatureCollection", "features": [feature]},
            separators=(",", ":"),
        ))
        counts[area_name] = len(polygons)
    return counts


def coverage_report(field: np.ndarray, bands=DEFAULT_BANDS) -> str:
    total = field.size
    cuts = resolve_thresholds(field, bands)
    base = field[field >= FIELD_EPSILON]
    lines = [
        f"grid cells: {total:,}   above epsilon: {base.size:,} "
        f"({100.0 * base.size / total:.1f}%)"
    ]
    banded = 0
    for name, lo, hi in cuts:
        n = int(((field >= lo) & (field < hi)).sum())
        banded += n
        hi_s = "inf" if hi == float("inf") else f"{hi:.3f}"
        lines.append(
            f"  {name:<9} [{lo:.3f},{hi_s:>5})  {n:>8,}  {100.0 * n / total:6.3f}% of city"
        )
    lines.append(f"  {'banded':<9} {'':<14}  {banded:>8,}  {100.0 * banded / total:6.3f}% of city")
    return "\n".join(lines)


def unlit_area(
    outages: Sequence,
    spec: FieldSpec,
    radius_m: float = 90.0,
    min_cluster: int = 1,
) -> BandSet:
    """Build the `unlit_street` area from open 311 light outages.

    This is the only near-real-time layer we have in Chicago — the crime feed
    lags seven days, 311 does not. An outage opened last night legitimately
    changes tonight's walking route, and it is the part of the score a user can
    verify with their own eyes.

    Radius is one circuit's worth: CDOT electricians service the whole circuit
    (8-16 lamps) on an "all out" report, so an outage affects considerably more
    than the reported pole.
    """
    from shapely.geometry import Point

    pts = [
        Point(o.lon, o.lat).buffer(
            radius_m / 111_320.0 * (1.6 if getattr(o, "kind", "") == "all_out" else 1.0),
            quad_segs=6,
        )
        for o in outages
        if getattr(o, "open_now", True)
    ]
    if not pts:
        return BandSet(layer="unlit_street", features=[])

    merged = unary_union(pts).simplify(SIMPLIFY_DEG, preserve_topology=True)
    geoms = [g for g in getattr(merged, "geoms", [merged])
             if g.geom_type == "Polygon" and not g.is_empty]
    if not geoms:
        return BandSet(layer="unlit_street", features=[])

    # Emit one Feature PER POLYGON with a Polygon geometry. write_custom_areas
    # is what assembles a band into a single MultiPolygon feature; returning a
    # MultiPolygon here would get wrapped a second time and produce rings one
    # level too deep, which GraphHopper reports as:
    #   Invalid number of points in LineString (found 1 - must be 0 or >= 2)
    return BandSet(layer="unlit_street", features=[
        {
            "type": "Feature",
            "id": f"unlit_street_{i}",
            "properties": {
                "layer": "unlit_street", "band": "unlit",
                "area_name": "unlit_street", "lo": 0.0, "hi": None,
            },
            "geometry": mapping(g),
        }
        for i, g in enumerate(geoms)
    ])

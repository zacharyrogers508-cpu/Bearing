"""Nightly bake: incidents -> risk fields -> band polygons -> custom_areas.

Run from ops/bake.sh. Idempotent; writes into a staging directory and swaps,
so a failed bake never leaves GraphHopper with a half-written area set.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from ..ingest.chicago import CITY_BBOX
from ..taxonomy import LAYERS
from .kde import FieldSpec, IncidentArray, build_field
from .bands import extract_bands, write_custom_areas, coverage_report, unlit_area

log = logging.getLogger("bake")

#: (layer, mode, representative hour). Four surfaces, matching the four
#: `in_<layer>_<tod>_<band>` predicate families the custom models reference.
SURFACES = [
    ("person_night",   "person",   "pedestrian", 23.0),
    ("person_day",     "person",   "pedestrian", 13.0),
    ("property_night", "property", "vehicle",    23.0),
    ("property_day",   "property", "vehicle",    13.0),
]


def taxonomy_sha(city: str = "chicago") -> str:
    root = Path(__file__).resolve().parent.parent.parent / "data"
    h = hashlib.sha256()
    for name in (f"taxonomy_{city}.csv", f"street_relevance_{city}.csv"):
        h.update((root / name).read_bytes())
    return h.hexdigest()[:16]


def bake(incidents, out_dir: Path, spec: FieldSpec | None = None,
         verbose: bool = True, field_dir: Path | None = None,
         outages=None) -> dict:
    spec = spec or FieldSpec(bbox=CITY_BBOX, cell_m=40.0, sigma_m=110.0)
    arr = IncidentArray.from_incidents(incidents)

    staging = out_dir.parent / (out_dir.name + ".staging")
    if staging.exists():
        shutil.rmtree(staging)

    #: The API samples these rasters directly for /score. GraphHopper gets the
    #: band polygons; the API gets the continuous surface, because a licensee
    #: scoring someone else's polyline needs a number, not a band.
    field_dir = field_dir or (out_dir.parent / "fields")
    field_staging = field_dir.parent / (field_dir.name + ".staging")
    if field_staging.exists():
        shutil.rmtree(field_staging)
    field_staging.mkdir(parents=True, exist_ok=True)

    bandsets, layer_counts = [], {}
    t0 = time.time()
    for name, layer, mode, hour in SURFACES:
        sub = arr.subset(LAYERS[layer])
        layer_counts[name] = int(len(sub))
        field = build_field(sub, spec, mode, hour=hour)
        np.save(field_staging / f"{name}.npy", field)
        bs = extract_bands(field, spec, name)
        bandsets.append(bs)
        if verbose:
            log.info("%s: %d incidents -> %d polygons", name, len(sub), len(bs.features))
            print(f"\n--- {name} (n={len(sub)}) ---")
            print(coverage_report(field))

    # The lighting layer. Always emitted, even when empty — a custom model
    # referencing in_unlit_street must compile, and an absent area is a hard
    # failure at request time:
    #   Cannot compile expression: Area 'unlit_street' wasn't found
    lit_bs = unlit_area(outages or [], spec)
    if not lit_bs.features:
        lit_bs.features = [{
            "type": "Feature", "id": "unlit_street",
            "properties": {"layer": "unlit_street", "band": "unlit",
                           "area_name": "unlit_street", "polygon_count": 0,
                           "lo": 0.0, "hi": None},
            # degenerate speck well outside the city bbox: binds the name
            # without matching any edge. Polygon, not MultiPolygon —
            # write_custom_areas does the MultiPolygon assembly.
            "geometry": {"type": "Polygon", "coordinates": [
                [[-180.0, -85.0], [-179.999, -85.0],
                 [-179.999, -84.999], [-180.0, -85.0]]]},
        }]
    bandsets.append(lit_bs)
    layer_counts["unlit_street"] = len(outages or [])

    counts = write_custom_areas(bandsets, staging)

    if out_dir.exists():
        shutil.rmtree(out_dir)
    staging.rename(out_dir)
    if field_dir.exists():
        shutil.rmtree(field_dir)
    field_staging.rename(field_dir)

    manifest = {
        "baked_at": datetime.now(timezone.utc).isoformat(),
        "taxonomy_sha": taxonomy_sha(),
        "incident_count": int(len(arr)),
        "layer_counts": layer_counts,
        "band_counts": counts,
        "spec": {
            "cell_m": spec.cell_m, "sigma_m": spec.sigma_m,
            "half_life_days": spec.half_life_days, "bbox": list(spec.bbox),
        },
        "elapsed_s": round(time.time() - t0, 2),
    }
    # The manifest must NOT live inside out_dir. GraphHopper parses *every*
    # file in custom_areas.directory as a JsonFeatureCollection and dies on
    # any unrecognised top-level key:
    #   UnrecognizedPropertyException: Unrecognized field "baked_at"
    #   (2 known properties: "type", "features")
    # Found by importing, not by reading the docs.
    # Name the manifest after the area directory. A single shared
    # bake_manifest.json collided: the backtest's train-only bake overwrote the
    # production manifest, and /health then reported 3,295 incidents for a
    # surface built from 4,392. Wrong number, no error, easy to miss.
    (out_dir.parent / f"{out_dir.name}_manifest.json").write_text(
        json.dumps(manifest, indent=2))
    return manifest


def main() -> None:
    ap = argparse.ArgumentParser(description="Bake Bearing risk areas for GraphHopper")
    ap.add_argument("--fixture", type=Path, help="JSON file of raw Chicago crime rows (offline mode)")
    ap.add_argument("--lights-fixture", type=Path, help="JSON file of raw 311 light rows (offline mode)")
    ap.add_argument("--app-token", default=None)
    ap.add_argument("--lookback-days", type=int, default=365)
    ap.add_argument("--out", type=Path, default=Path("routing/data/custom_areas"))
    ap.add_argument("--cell-m", type=float, default=40.0)
    ap.add_argument("--sigma-m", type=float, default=110.0)
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s %(message)s")
    from ..ingest.chicago import ChicagoCrimes

    src = ChicagoCrimes(app_token=args.app_token)
    if args.fixture:
        rows = json.loads(args.fixture.read_text())
        src.stats["seen"] = len(rows)
        incidents = [i for i in (src._to_incident(r) for r in rows) if i]
        src.stats["kept"] = len(incidents)
    else:
        incidents = list(src.fetch(lookback_days=args.lookback_days))

    print(src.report())

    from ..ingest.chicago import ChicagoStreetLights, LightOutage
    outages = []
    if args.lights_fixture:
        for r in json.loads(args.lights_fixture.read_text()):
            try:
                lat, lon = float(r["latitude"]), float(r["longitude"])
            except (TypeError, ValueError, KeyError):
                continue
            outages.append(LightOutage(
                source_id=str(r.get("sr_number")), opened_at=r.get("created_date", ""),
                closed_at=r.get("closed_date"), lat=lat, lon=lon,
                kind="all_out" if "All Out" in (r.get("sr_type") or "") else "one_out",
                open_now=(r.get("status") or "").lower().startswith("open"),
            ))
    elif not args.fixture:
        outages = list(ChicagoStreetLights(app_token=args.app_token).fetch_open())
    open_now = [o for o in outages if o.open_now]
    print(f"light outages: {len(outages)} fetched, {len(open_now)} currently open")

    spec = FieldSpec(bbox=CITY_BBOX, cell_m=args.cell_m, sigma_m=args.sigma_m)
    manifest = bake(incidents, args.out, spec, outages=open_now)
    print("\n=== MANIFEST ===")
    print(json.dumps(manifest, indent=2))
    if src.unmapped:
        raise SystemExit(
            f"FAIL: unmapped primary_type values {sorted(src.unmapped)} — "
            "add rules to data/taxonomy_chicago.csv before publishing this bake"
        )


if __name__ == "__main__":
    main()

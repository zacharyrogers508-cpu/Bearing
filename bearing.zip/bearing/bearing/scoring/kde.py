"""Risk field construction.

Design notes that matter more than the code
-------------------------------------------

1. BANDWIDTH IS FLOORED BY GEOCODING ERROR. CPD publishes to the hundred-block,
   so the true incident location is uncertain by ~100 m. A kernel narrower than
   that manufactures precision that does not exist in the source and will
   produce confident-looking street-level differences that are pure noise.
   `sigma = max(requested, geocode_precision)` is enforced, not advisory.

2. TIME-OF-DAY IS CIRCULAR. 23:00 and 01:00 are two hours apart, not twenty-two.
   Naive absolute-difference weighting is a classic and invisible bug.

3. RECENCY DECAY IS EXPONENTIAL, NOT A WINDOW. A hard 90-day window means the
   score jumps discontinuously as incidents age out, which produces routes that
   change for no visible reason. 120-day half-life is smooth.

4. NORMALISATION IS BY PERCENTILE, NOT MAX. One extreme cluster otherwise
   flattens the entire rest of the city to near-zero.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Literal, Optional, Sequence

import numpy as np

Mode = Literal["pedestrian", "vehicle"]

# Web-Mercator-free local projection: at Chicago's latitude, good to <0.3%
# over the city extent and far cheaper than a full pyproj dependency.
CHICAGO_LAT0 = 41.88
M_PER_DEG_LAT = 111_132.0
M_PER_DEG_LON = 111_320.0 * np.cos(np.radians(CHICAGO_LAT0))


def to_local_m(lon: np.ndarray, lat: np.ndarray, origin: tuple[float, float]) -> tuple[np.ndarray, np.ndarray]:
    lon0, lat0 = origin
    return (lon - lon0) * M_PER_DEG_LON, (lat - lat0) * M_PER_DEG_LAT


def to_lonlat(x: np.ndarray, y: np.ndarray, origin: tuple[float, float]) -> tuple[np.ndarray, np.ndarray]:
    lon0, lat0 = origin
    return x / M_PER_DEG_LON + lon0, y / M_PER_DEG_LAT + lat0


@dataclass
class FieldSpec:
    bbox: tuple[float, float, float, float]   # lon_min, lat_min, lon_max, lat_max
    cell_m: float = 40.0
    sigma_m: float = 110.0
    half_life_days: float = 120.0
    hour_sigma: float = 3.5
    hour_floor: float = 0.20     # an incident at an unrelated hour still counts a little
    percentile: float = 97.0

    @property
    def origin(self) -> tuple[float, float]:
        return (self.bbox[0], self.bbox[1])

    def grid(self) -> tuple[np.ndarray, np.ndarray, int, int]:
        lon_min, lat_min, lon_max, lat_max = self.bbox
        w_m = (lon_max - lon_min) * M_PER_DEG_LON
        h_m = (lat_max - lat_min) * M_PER_DEG_LAT
        nx = int(np.ceil(w_m / self.cell_m)) + 1
        ny = int(np.ceil(h_m / self.cell_m)) + 1
        xs = np.arange(nx) * self.cell_m
        ys = np.arange(ny) * self.cell_m
        return xs, ys, nx, ny


def circular_hour_weight(inc_hour: np.ndarray, target_hour: float, sigma: float, floor: float) -> np.ndarray:
    d = np.abs(inc_hour - target_hour)
    d = np.minimum(d, 24.0 - d)
    return floor + (1.0 - floor) * np.exp(-(d ** 2) / (2.0 * sigma ** 2))


def recency_weight(days_ago: np.ndarray, half_life: float) -> np.ndarray:
    return np.exp(-np.log(2.0) * np.maximum(days_ago, 0.0) / half_life)


@dataclass
class IncidentArray:
    """Columnar incident store — the shape the kernel actually wants."""
    lon: np.ndarray
    lat: np.ndarray
    hour: np.ndarray
    days_ago: np.ndarray
    weight: np.ndarray
    ped_relevance: np.ndarray
    veh_relevance: np.ndarray
    canonical: np.ndarray
    geocode_precision_m: np.ndarray

    def __len__(self) -> int:
        return len(self.lon)

    @classmethod
    def from_incidents(cls, incidents: Iterable, now: Optional[datetime] = None) -> "IncidentArray":
        now = now or datetime.now(timezone.utc)
        lon, lat, hour, days, w, pr, vr, cls_, gp = ([] for _ in range(9))
        for inc in incidents:
            ts = inc.occurred_at
            dt = _parse(ts)
            if dt is None:
                continue
            lon.append(inc.lon); lat.append(inc.lat)
            hour.append(dt.hour + dt.minute / 60.0)
            days.append((now - dt).total_seconds() / 86400.0)
            w.append(inc.weight)
            pr.append(inc.ped_relevance); vr.append(inc.veh_relevance)
            cls_.append(inc.canonical)
            gp.append(inc.geocode_precision_m)
        f = lambda a: np.asarray(a, dtype=np.float64)
        return cls(f(lon), f(lat), f(hour), f(days), f(w), f(pr), f(vr),
                   np.asarray(cls_, dtype=object), f(gp))

    def subset(self, classes: Sequence[str]) -> "IncidentArray":
        m = np.isin(self.canonical, list(classes))
        return IncidentArray(
            self.lon[m], self.lat[m], self.hour[m], self.days_ago[m], self.weight[m],
            self.ped_relevance[m], self.veh_relevance[m], self.canonical[m],
            self.geocode_precision_m[m],
        )


def _parse(ts: str) -> Optional[datetime]:
    if not ts:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(ts.split("+")[0], fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def build_field(
    incidents: IncidentArray,
    spec: FieldSpec,
    mode: Mode,
    hour: float,
    normalise: bool = True,
) -> np.ndarray:
    """Return an (ny, nx) float32 field in [0, 1] (if normalised)."""
    xs, ys, nx, ny = spec.grid()
    field = np.zeros((ny, nx), dtype=np.float64)
    if len(incidents) == 0:
        return field.astype(np.float32)

    # Enforce the geocoding floor. This is the guard described in note 1.
    sigma = max(spec.sigma_m, float(np.median(incidents.geocode_precision_m)))
    cutoff = 3.0 * sigma
    inv2s2 = 1.0 / (2.0 * sigma * sigma)

    relevance = incidents.ped_relevance if mode == "pedestrian" else incidents.veh_relevance
    w = (
        incidents.weight
        * relevance
        * recency_weight(incidents.days_ago, spec.half_life_days)
        * circular_hour_weight(incidents.hour, hour, spec.hour_sigma, spec.hour_floor)
    )
    keep = w > 1e-6
    if not keep.any():
        return field.astype(np.float32)

    ix, iy = to_local_m(incidents.lon[keep], incidents.lat[keep], spec.origin)
    w = w[keep]

    # Scatter each incident into its local neighbourhood only. O(n * k) with
    # k ~ (2*cutoff/cell)^2 ~ 300 cells, rather than O(n * nx * ny).
    half = int(np.ceil(cutoff / spec.cell_m))
    cx = np.clip((ix / spec.cell_m).astype(int), 0, nx - 1)
    cy = np.clip((iy / spec.cell_m).astype(int), 0, ny - 1)

    off = np.arange(-half, half + 1)
    dxg, dyg = np.meshgrid(off, off, indexing="xy")
    dxg, dyg = dxg.ravel(), dyg.ravel()

    for k in range(len(w)):
        gx = cx[k] + dxg
        gy = cy[k] + dyg
        m = (gx >= 0) & (gx < nx) & (gy >= 0) & (gy < ny)
        if not m.any():
            continue
        gx, gy = gx[m], gy[m]
        ddx = gx * spec.cell_m - ix[k]
        ddy = gy * spec.cell_m - iy[k]
        contrib = w[k] * np.exp(-(ddx * ddx + ddy * ddy) * inv2s2)
        np.add.at(field, (gy, gx), contrib)

    if normalise:
        # Scale so that 1.0 == the `percentile`-th percentile of active cells.
        # Deliberately NOT clipped: clipping flattens the entire top of the
        # distribution to a single value, which destroys any percentile-based
        # banding downstream (every band above the clip point resolves to the
        # same cut). Values above 1.0 are meaningful and expected.
        flat = field[field > 0]
        if flat.size:
            hi = np.percentile(flat, spec.percentile)
            if hi > 0:
                field = field / hi
    return field.astype(np.float32)


def to_exposure(value):
    """Squash an unbounded field value to a [0, 1] exposure index for display.

    Saturating rather than clipping so the difference between "bad" and "very
    bad" survives into the number a user sees.
    """
    return 1.0 - np.exp(-np.asarray(value, dtype=np.float64) / 1.5)


def densify(lon, lat, spacing_m: float = 25.0):
    """Resample a polyline to at most `spacing_m` between points.

    Routers return SIMPLIFIED geometry — GraphHopper gave 4 vertices for a
    5 km route across a regular grid, because 4 points describe it exactly.
    Sampling a risk surface at those 4 points is very close to meaningless:
    the whole middle of the route is never looked at, and the exposure index
    comes back ~0 for a path straight through a keep-out zone.

    Densify before scoring, always. The cost is trivial and the alternative is
    a number that looks fine and is wrong.
    """
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    if lon.size < 2:
        return lon, lat

    out_lon: list[float] = []
    out_lat: list[float] = []
    for i in range(len(lon) - 1):
        dx = (lon[i + 1] - lon[i]) * M_PER_DEG_LON
        dy = (lat[i + 1] - lat[i]) * M_PER_DEG_LAT
        seg = float(np.hypot(dx, dy))
        n = max(1, int(np.ceil(seg / spacing_m)))
        ts = np.arange(n) / n
        out_lon.extend(lon[i] + ts * (lon[i + 1] - lon[i]))
        out_lat.extend(lat[i] + ts * (lat[i + 1] - lat[i]))
    out_lon.append(float(lon[-1]))
    out_lat.append(float(lat[-1]))
    return np.asarray(out_lon), np.asarray(out_lat)


def sample_field(field: np.ndarray, spec: FieldSpec, lon: np.ndarray, lat: np.ndarray) -> np.ndarray:
    """Bilinear sample at lon/lat. Used for scoring an arbitrary polyline."""
    ny, nx = field.shape
    x, y = to_local_m(np.asarray(lon, float), np.asarray(lat, float), spec.origin)
    fx = np.clip(x / spec.cell_m, 0, nx - 1.001)
    fy = np.clip(y / spec.cell_m, 0, ny - 1.001)
    x0, y0 = fx.astype(int), fy.astype(int)
    tx, ty = fx - x0, fy - y0
    return (
        field[y0, x0] * (1 - tx) * (1 - ty)
        + field[y0, x0 + 1] * tx * (1 - ty)
        + field[y0 + 1, x0] * (1 - tx) * ty
        + field[y0 + 1, x0 + 1] * tx * ty
    )

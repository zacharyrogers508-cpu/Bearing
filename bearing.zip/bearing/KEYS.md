# API keys

Bearing runs with **no keys at all** on demo data. Add them one at a time; each
one turns on a specific thing.

```bash
cp .env.example .env      # then edit .env
make keys                 # checks each key with a real request
```

`make keys` is the fast feedback loop. It tells you which keys work, which are
missing, and — importantly — distinguishes a rejected key from a blocked
network, because both return 403 and only one is your fault.

---

## 1. Chicago crime data (free, 2 minutes)

The one that makes the data real. Free, instant, no credit card.

1. Go to **https://data.cityofchicago.org**
2. Top right → **Sign In** → **Sign Up** (email + password)
3. Confirm your email, then go to
   **https://data.cityofchicago.org/profile/edit/developer_settings**
4. **Create New App Token**. Name it anything, e.g. "bearing".
5. Copy the **App Token** — not the Secret Token.

```
SOCRATA_APP_TOKEN=paste_it_here
```

The portal technically works without a token, but it throttles anonymous
callers aggressively and a year of incidents will stall partway. Get the token.

---

## 2. GraphHopper — hosted routing (PAID, and usually not worth it)

**The free plan does not work for Bearing.** GraphHopper's pricing page states
that the Free Plan "cannot use the flexible mode (ch.disable=true)", and custom
models — the entire mechanism Bearing uses to weight routes by risk — require
flexible mode. A free key returns:

```
400: {"message":"Free packages cannot use flexible mode"}
```

The key is valid. The plan just cannot do the one thing we need. Flexible mode
starts on the paid tiers; see https://www.graphhopper.com/pricing/.

**Run the router locally instead.** It is free, unlimited, faster per request,
and takes one command:

```bash
./ops/chicago-extract.sh
```

That pulls a Chicago-only street map (~60 MB, not the 400 MB Illinois file) and
imports it in a few minutes. One time. After that routing is local and costs
nothing.

If you do buy a plan, note that live mode makes **two** routing calls per trip —
one to find the corridor, one to route through it — so budget 2 credits per
user request.

---

## 3. TomTom — live traffic (free, 5 minutes)

Optional. Real congestion instead of the synthetic pattern.

1. Go to **https://developer.tomtom.com/**
2. **Register** for a free developer account
3. **Dashboard → My Apps → Add new App**, tick the **Traffic** APIs
4. Copy the **Consumer API Key**

```
TOMTOM_API_KEY=paste_it_here
```

Without this the app shows congestion labelled "demo", so you can't
accidentally present synthetic numbers as real. Verify current rates before you
depend on it — TomTom changed pricing effective 1 July 2026.

---

## 4. MapTiler — sharper map (free, 3 minutes)

Optional. Vector tiles, crisper labels, 3D pitch.

1. **https://cloud.maptiler.com/** → free account
2. Copy the key from your account page

```
MAPTILER_KEY=paste_it_here
```

The browser can't read `.env`, so this one also needs `app/.env.local`.
`make keys` writes that file for you once the key validates.

Without it the app uses a keyless basemap that looks fine.

---

## What each combination gets you

| Keys | What you get |
|---|---|
| none | Demo data, synthetic streets. Everything works. |
| Chicago only | Real incidents. Router runs locally — one graph import. |
| Chicago + local map | **Real data.** `./ops/chicago-extract.sh` then `./ops/run.sh` |
| Chicago + paid GraphHopper | Real data, no download. Free tier will not work. |
| + TomTom | Real congestion in driving ETAs |
| + MapTiler | Sharper basemap |

---

## Keeping them safe

`.env` and `app/.env.local` are both gitignored. Don't commit them.

The MapTiler key is different from the others: it ships to the browser and is
visible to anyone using the app. That's normal for map keys, but restrict it by
HTTP referrer in the MapTiler dashboard before you put it anywhere public. The
Chicago, GraphHopper and TomTom keys stay server-side and should never appear
in client code.

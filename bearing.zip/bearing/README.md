# Bearing

**Safety-weighted route planning.** Builds a risk surface from municipal crime
data and feeds it into a routing engine, so you get a *safest* route alongside
the *fastest* one.

> **Status: archived.** This works, and the method validates. I stopped because
> the business case did not survive research, not because the code did. See
> [Why this is archived](#why-this-is-archived) — that section is probably the
> most useful part of the repo.

```
walking, 10 PM, Chicago
  fastest   62 min   5182 m   exposure 0.292
  safest    77 min   6404 m   exposure 0.116   60% fewer reported incidents nearby
```

---

## Does it actually work?

Yes, and that's the part I'd point at. `make backtest` builds the risk model
from older incidents, routes real trips against it, then scores those routes on
**incidents the model never saw**:

| | median exposure reduction vs fastest |
|---|---|
| safest route | **41.4%** |
| random detour of the same added length | **0.0%** |

Head-to-head: safest wins 66 trips, loses 13, ties 1. Sign test p < 0.001 across
80 evaluable trips. Median cost: +4.8 minutes.

**The control row is the whole test.** A longer route can dodge incidents by
luck. A length-matched random detour delivers no reduction at all and is
identical to the fastest route per kilometre. So the 41% is the model locating
risk, not an artifact of walking further.

Caveat stated plainly: this ran on synthetic incidents over a synthetic street
grid. The *method* is validated; the *number* is not a Chicago number. Pointing
it at real data is two environment variables (see [SETUP.md](SETUP.md)) and I
didn't get there before shelving it.

---

## How it works

```
municipal open data (Chicago: crimes ijzp-q8t2, 311 lighting v6vf-nfxy)
        |
        v  bearing/ingest/
   classify against a canonical taxonomy
   weight by how much a location matters to someone passing by
   drop domestic, indoor, and enforcement-density offences
        |
        v  bearing/scoring/kde.py
   kernel density, bandwidth floored at the source geocoding error
   circular time-of-day weighting, 120-day recency half-life
   four surfaces: {person, property} x {night, day}
        |
        v  bearing/scoring/bands.py
   percentile bands with an absolute floor -> GeoJSON polygons
        |
        v  GraphHopper custom_areas + per-request custom models
   edge_weight = distance / (speed * priority) + distance * distance_influence
```

The user's profile (walking or driving, time of day, trip conditions) becomes a
set of priority multipliers over those bands at request time. Live traffic from
TomTom rides along inline as speed multipliers on the same mechanism.

### Two modes

**Baked** precomputes the whole city into the routing graph. ~275 ms per route,
needs an OSM extract and a graph import.

**Live** fetches incidents per trip: route once with no weighting to find the
corridor, pull incidents for that corridor's bounding box, score them, route
again with the polygons inline. ~1 s cold, ~350 ms warm, no precompute. A
Loop-to-Hyde-Park trip pulls 703 incidents instead of a quarter million, and
the inline payload is 14 KB.

---

## Run it

```bash
git clone <this repo> && cd bearing
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cd app && npm install && cd ..
./ops/run.sh
```

First run takes about two minutes (fetches GraphHopper, builds demo data,
imports a graph). Then open **http://localhost:5173**.

Works with no API keys at all on generated data. [KEYS.md](KEYS.md) covers
switching to real Chicago incidents and real traffic.

```
make verify     bake -> graph import -> routing -> API contract, all offline
make backtest   predictive validity check (no users needed)
make test       63 tests, ~13s
```

Needs Java 17+, Python 3.10+, Node 18+.

---

## Six things about GraphHopper that aren't in the docs

Each of these cost a rebuild to find, and each is now a regression test. If you
are doing anything similar with custom areas, this section will save you a day.

1. **Area names come from the feature `id`, not the filename.** Writing N
   features into `person_night_keepout.geojson` gives you N areas and no
   `person_night_keepout`. You get
   `Cannot compile expression: Area 'person_night_keepout' wasn't found`.

2. **Duplicate feature ids are rejected outright** — `area X already exists` —
   so you cannot just give every polygon in a band the same name.

3. **MultiPolygon works**, despite the docs saying a member "must be a Feature
   with a geometry type Polygon". It is the only way to get one predicate per
   band. This took my area count from 209 to 17.

4. **Nothing but area GeoJSON may live in `custom_areas.directory`.**
   GraphHopper parses every file in it as a FeatureCollection and dies on
   unknown top-level keys — including a build manifest.

5. **The car base profile has a built-in `distance_influence` of 90** that an
   empty `custom_model_files` does not override. Vehicle requests must send
   >= 90 or get `CustomModel in query can only use distance_influence bigger or
   equal to 90.0`.

6. **Inline areas cannot shadow baked ones.** Sending an inline area whose name
   already exists server-side is a 400. Namespace them.

Plus two that follow from the design:

- **`ch.disable` must be true on every request**, and there should be no
  `profiles_ch` block at all. Contraction-hierarchy profiles silently ignore
  custom models — you get a route, it just ignores your weighting.
- **Custom areas are read at import time**, so a new bake means a new graph.
  `ops/bake.sh` imports a shadow graph on a second port and flips the upstream.

### And two about the data

**Router geometry is simplified, and scoring it directly returns near-zero.**
GraphHopper returned 4 vertices for a 5 km route — 4 points describe it exactly
on a grid. Sampling the risk surface at those 4 points never looks at the middle
of the route, so a path straight through a keep-out zone scored
`exposure_index = 0.0000`. Everything looked fine. Densify to ~25 m before
scoring, always.

**Uniform trip sampling makes a backtest meaningless.** The first run sampled
origin/destination pairs uniformly across Chicago and got 10 evaluable trials
out of 100, because banded area is under 1% of the city and 90 trips never came
near a risk zone — the experiment compared the treatment against itself. Sample
trips that actually cross risk, report exposure per kilometre, and drop trips
where the safest route is identical to the fastest.

---

## What is deliberately not in the model

**Demographics.** Race, income, household composition, census variables. Never
inputs, never proxies, never validation features. There is a test enforcing the
closed vocabulary of user-selectable trip conditions.

**Enforcement-density proxies.** Narcotics, prostitution, gambling and liquor
offences. These measure where officers are deployed, not what a passer-by faces.
Including them encodes patrol allocation as danger.

**Non-public incidents.** Domestic incidents and offences inside residences,
retail interiors and custodial facilities. A domestic battery inside a
third-floor apartment geocodes to the same block as the sidewalk outside it;
scoring it as sidewalk risk inflates dense residential blocks for reasons that
have nothing to do with walking past.

Between them these discard about 26% of raw records. `data/*.csv` is where those
decisions live, and honestly it is the most interesting part of the codebase.
The Dijkstra is a week; deciding what counts is the work.

**Known limitation that excluding demographics does not fix:** reporting bias is
already inside the incident feed. Areas with heavier patrol and higher reporting
rates generate more records at equal underlying risk. Read every score as a
measure of *reporting*. [docs/methodology.md](docs/methodology.md) is explicit
about this.

---

## Why this is archived

The engineering worked. The business case did not.

**No one has ever bought this kind of company.** No mapping, rideshare or gig
platform has acquired a crime-data or safety-routing company. The one clean
precedent is CoreLogic acquiring Location Inc (NeighborhoodScout / CrimeRisk) in
January 2020 — a property-data giant buying a data asset, terms undisclosed.

**The incumbents have decades of head start.** CAP Index has sold address-level
crime risk scores since 1988 and serves a large share of the Fortune 100.
Location Inc claims 10-metre resolution, finer than block-level open data can
honestly support. SpotCrime sells the raw incident feed by API.

**The obvious buyers have solved their version and have reasons to avoid this
one.** DoorDash and Uber built reactive safety toolkits — panic buttons, crash
detection, crisis alerts, off-route checks. None routes around crime geography,
and a platform that told drivers to avoid specific neighbourhoods would face
immediate disparate-impact criticism.

**Consumer safety navigation is a graveyard, and not only for the obvious
reason.** SketchFactor (2014) was branded racist on launch and folded.
Microsoft's "avoid ghetto" patent shipped nothing. But the deeper problem is
frequency: navigation is a daily habit and safety routing is an occasional need,
which produces retention too poor to support paid acquisition. And the benefit
is unfeelable — the absolute risk of any single walk is tiny, so cutting it by
41% produces no experience the user can perceive.

**What I would look at instead, if I picked this up again.** The incumbents sell
crime-risk indices without publishing predictive validation or bias audits, and
their customers are walking into an algorithmic-fairness regime (Colorado
SB 21-169 extending disparate-impact testing to auto insurance from October
2025; *Huskey v. State Farm*; the SafeRent settlement). The validation harness
and the bias-aware taxonomy in this repo are closer to that need than to a
routing product. That is a hypothesis, not a plan — it would need two
conversations with an actuary to confirm or kill.

---

## Layout

```
bearing/ingest/      pull incidents and 311 lighting from municipal portals
bearing/scoring/     incidents -> risk surface -> router-readable polygons
bearing/routing.py   user profile -> GraphHopper custom model
bearing/traffic.py   live congestion from TomTom, synthetic fallback
bearing/live.py      per-trip corridor fetching (no precompute)
bearing/backtest.py  temporal split + length-matched control
bearing/api/         the API the app talks to
app/                 React + MapLibre client
data/*.csv           which offences count, and where they matter
docs/methodology.md  what is measured, what is excluded, what is wrong with it
```

### Adding another city

Two CSVs and, if the portal isn't Socrata, a ~40-line adapter.
`bearing/ingest/socrata.py` is city-agnostic and reused as-is for any Socrata
portal. The taxonomy file is what makes city forty take a week instead of a
month.

---

## License

MIT — see [LICENSE](LICENSE).

Municipal data carries its own terms. Chicago's open data license requires
attribution and re-imposition of terms on derivative applications; every city
differs. OpenStreetMap is ODbL, and while routes returned are produced works, an
enriched routing database may be a derivative database subject to share-alike.
Get an opinion before commercial use.

## Contributing

Not maintained. Fork it freely. If you build something with the GraphHopper
findings above, I would enjoy hearing about it.

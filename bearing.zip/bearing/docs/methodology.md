# Bearing scoring methodology

Published because a black-box crime score is unbuyable by anyone with a legal
department, and because the limitations below are real and a user acting on
this deserves to know them.

## What is scored

Reported incidents. Not crime. The distinction matters and is not a disclaimer.

## Inputs

| Layer | Source | Cadence | Geocoding |
|---|---|---|---|
| Crime incidents | Chicago PD CLEAR via `ijzp-q8t2` | daily, **7-day lag** | hundred-block (~100 m) |
| Street-light outages | 311 via `v6vf-nfxy` | continuous | address point |
| Traffic crashes | `85ca-t3if` | daily | intersection |

## Excluded by design

**Demographics.** Race, income, household composition, census variables. Never
inputs, never proxies, never validation features.

**Enforcement-density proxies.** Narcotics, prostitution, gambling, liquor
offences. These measure where officers are deployed. A neighbourhood with
heavier patrol generates more of these regardless of the risk to someone
walking through, so including them would encode patrol allocation as danger.

**Non-public incidents.** Domestic incidents and offences inside residences,
retail interiors, and custodial facilities. Weighted by
`street_relevance_chicago.csv`, which asks one question of every location type:
how much should this affect the score for a person walking past on the public
way?

**Offences involving children.** Never scored, never surfaced, never returned.

## Method

1. Each incident is classified to a canonical class and severity weight.
2. Weighted by street relevance for the travel mode.
3. Weighted by recency, exponential, 120-day half-life. Not a hard window — a
   window makes the score jump discontinuously as incidents age out, producing
   routes that change for no perceivable reason.
4. Weighted by time-of-day similarity, circular, sigma 3.5 h, floor 0.2.
   Circular because 23:00 and 01:00 are two hours apart, not twenty-two.
5. Gaussian kernel density onto a 40 m grid. **Bandwidth is floored at the
   source geocoding error.** A tighter kernel would manufacture street-level
   precision the source does not contain.
6. Normalised so 1.0 equals the 97th percentile of active cells. Not clipped.
7. Banded by percentile with an absolute floor, so band coverage is stable
   across days and cities, but a genuinely quiet area gets no keep-out zone.

## Known limitations

**Reporting bias is inside the data and excluding demographics does not remove
it.** Areas with higher reporting rates and heavier police presence generate
more records at equal underlying risk. Mitigations in progress: normalising
against calls-for-service volume, and weighting victim-reported above
officer-initiated. Until those land, read every score as a measure of
*reporting*.

**Resolution ceiling is the block, not the street segment.** We cannot honestly
distinguish one side of a street from the other, and we do not try.

**Seven-day latency on the crime layer in Chicago.** Lighting is current;
crime is not.

**Absence of reports is not evidence of safety.** Under-reported areas score
low for the wrong reason.

## Claim language

Every quantitative claim in the product is the measured version — "38% fewer
reported incidents within 100 m", not "safer". "Safest" appears as a UI label
for the lowest-exposure option and is not a representation about the world.

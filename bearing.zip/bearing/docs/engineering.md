# Bearing — Chicago

Safety-weighted route scoring. Phase 1 of the plan: one city, pedestrian-first,
built to answer a single question — **do people actually take the slower route?**

The scoring API is the product. The app is how we collect the answer.

## What runs today

```bash
pip install -r requirements.txt

curl -L -o routing/graphhopper-web.jar \
  https://github.com/graphhopper/graphhopper/releases/download/10.0/graphhopper-web-10.0.jar

make verify      # bake -> graph import -> route -> assert deflection
```

`make verify` is the one command that matters. Six stages, offline, no live
portal and no Illinois extract:

```
==> [1/6] fixtures          synthetic Chicago crime + 311 lighting
==> [2/6] unit tests        45 passed
==> [3/6] bake              incidents -> surfaces -> 17 band polygons
==> [4/6] graph import      real GraphHopper 10.0 graph
==> [5/6] routing           [1] 17 area predicates compile: OK
                            [2] pedestrian fastest=5182m safest=6405m delta=+1223m
                            [3] no CH-prepared profiles: OK
==> [6/6] API + app         16/16 band layers, route fields, telemetry
                            round trip, CORS preflight, 422 on bad concern
==> all green
```

Stage 6 replays the exact call sequence `app/bearing-live.jsx` makes, so a
broken app is a rendering bug rather than an integration one.

Individually:

```bash
make fixture     # offline Chicago-shaped crime + 311 lighting data
make bake        # incidents -> risk surfaces -> band polygons (~1.5s)
make test        # 41 tests, ~11s
make api         # scoring API on :8000
make simulate    # sanity-check the gate metric on synthetic cohorts
make gate        # Phase 1 gate report from collected telemetry
```

`make bake-live` (with `SOCRATA_APP_TOKEN`) pulls the real portal instead.
`docker compose up` runs PostGIS + GraphHopper + the API together.

## Two bugs worth knowing about, because they were invisible

**Router geometry is simplified, and scoring it directly returns near-zero.**
GraphHopper returned 4 vertices for a 5 km route — 4 points describe it exactly
on a regular grid. Sampling the risk surface at those 4 points never looks at
the middle of the route, so a path straight through a keep-out zone scored
`exposure_index = 0.0000`. Everything looked fine. `kde.densify()` resamples to
25 m before scoring; with it, the same trip reports 0.2924 exposure on the
fastest route against 0.1163 on the safest — a 60% reduction for +14.7 min.
**Densify before scoring, always.**

**A percentage against a near-zero baseline is noise dressed as a headline.**
When the fastest route is already clean, `100 * (1 - x/1e-9)` produced
"-100% exposure". The API now returns `baseline_already_low: true` and a
reduction of 0, and the app says "already a quiet route" instead of inventing
a number.

## Pipeline

```
data.cityofchicago.org
  ijzp-q8t2  crimes         ─┐
  v6vf-nfxy  311 lights     ─┤
  85ca-t3if  crashes        ─┘
        │
        ▼  bearing/ingest/chicago.py
   classify (taxonomy_chicago.csv)
   weight by location (street_relevance_chicago.csv)
   drop domestic / enforcement-proxy / indoor
        │
        ▼  bearing/scoring/kde.py
   kernel density, sigma floored at geocoding error
   circular time-of-day weight, 120-day half-life
   4 surfaces: {person,property} x {night,day}
        │
        ├──▼ bearing/scoring/bands.py ──▶ routing/data/custom_areas/*.geojson
        │      percentile bands + absolute floor        │
        │                                               ▼
        │                                     GraphHopper custom_areas
        │                                     in_person_night_keepout etc.
        │                                               │
        └──▼ routing/data/fields/*.npy                  ▼
               continuous surface            bearing/routing.py builds a
               for POST /score               per-request custom_model
```

## The architecture decision that made this work

GraphHopper's only no-fork extension point is `custom_areas`: GeoJSON polygons
loaded at import that become `in_<name>` predicates usable in a custom model's
`priority` section. Getting an arbitrary float onto every edge means forking a
TagParser. Getting *band membership* onto every edge is configuration.

We lose resolution we never had — CPD publishes to the hundred-block — so this
is a genuine alignment between what the engine supports and what the data can
honestly say, not a compromise.

### Six things the docs do not tell you

Every one of these was found by importing an actual graph, not by reading. Each
is now a regression test.

1. **The area name comes from the feature `id`, not the filename.** Writing N
   features into `person_night_keepout.geojson` gives you N areas and no
   `person_night_keepout`:
   `Cannot compile expression: Area 'person_night_keepout' wasn't found`.

2. **Duplicate feature ids are rejected outright** — `area X already exists` —
   so you cannot just name every polygon in a band the same thing.

3. **MultiPolygon works**, despite the docs saying a member "must be a Feature
   with a geometry type Polygon". It is the only way to get one predicate per
   band. This took the area count from 209 to 17.

4. **Nothing but area GeoJSON may live in `custom_areas.directory`.**
   GraphHopper parses every file in it as a FeatureCollection and dies on any
   unknown top-level key. The bake manifest lives in the parent directory
   because of `Unrecognized field "baked_at"`.

5. **The car base profile carries a built-in `distance_influence` of 90** that
   an empty `custom_model_files` does not override, so vehicle requests must
   send >= 90 or get `CustomModel in query can only use distance_influence
   bigger or equal to 90.0`. Pedestrian and vehicle therefore have different
   distance_influence ranges.

6. **A custom model referencing an absent area is a hard request-time
   failure.** The `unlit_street` area is emitted even when there are zero
   outages, as a degenerate polygon outside the city, purely so the name binds.

Two more that follow from the design:

- **`ch.disable` must be true on every request**, and there is deliberately no
  `profiles_ch` block. CH-prepared profiles silently ignore custom models — you
  get a route, it just ignores your risk weighting. `ops/verify.sh` asserts no
  CH profiles exist so a forgotten flag cannot quietly return an unweighted path.
- **Custom areas are read at import time.** A new bake means a new graph.
  `ops/bake.sh` imports a shadow graph on a second port, health-checks it, and
  flips the upstream rather than mutating the live one.

### Verified behaviour

```
  [1] 17 area predicates compile: OK
  [2] pedestrian fastest=5182m safest=6405m  delta=+1223m
  [3] no CH-prepared profiles: OK
```

## Chicago-specific reality

**The crime feed lags seven days.** `ijzp-q8t2` excludes the most recent seven
days, and Chicago publishes no calls-for-service feed, so that is a floor no
scraper can beat. Any copy implying real-time crime awareness in Chicago would
be false.

What *is* near-real-time is the 311 lighting layer (`v6vf-nfxy`), which updates
continuously and genuinely changes overnight route quality. If the Phase 1
telemetry says timeliness matters to users, that argues for prioritising cities
with public CAD feeds — Seattle and SF — in Phase 2.

**Geocoding is block-level.** CPD truncates to the hundred-block to protect
victims, so the true location is uncertain by roughly 100 m. `kde.py` enforces
`sigma >= geocode_precision` rather than treating it as advice. A narrower
kernel would manufacture street-level distinctions that are pure noise, and
they would look completely convincing on a map.

## What is deliberately not in the model

Race, income, household composition, census demographics. Not as inputs, not as
proxies, not as validation features. `test_concerns_only_scale_never_add_demographics`
enforces the closed vocabulary.

Also excluded, and this one is less obvious: narcotics, prostitution, gambling,
and liquor offences. These track enforcement density, not passer-by risk.
Including them scores where police spend time, which is exactly the bias we are
trying not to import.

And domestic incidents. A domestic battery inside a third-floor apartment
geocodes to the same block as the sidewalk outside it. Scoring it as sidewalk
risk is simply an error — it inflates dense residential blocks for reasons that
have nothing to do with walking past. This is the single highest-leverage
filter in the pipeline and it is what `street_relevance_chicago.csv` exists for.

## API

```
POST /score                 polyline + profile -> per-segment exposure + bands
POST /route                 three options via GraphHopper, scored, deduplicated
GET  /areas                 layer index + city bbox
GET  /areas/{layer}         baked band polygons (the REAL risk surface)
POST /telemetry/offer       log an offer made outside /route
POST /telemetry/selection   which option was chosen  <- the measurement
POST /telemetry/completion  navigation outcome + deviation
GET  /gate                  the Phase 1 decision, as JSON
GET  /gate/text             the same, human-readable
GET  /health                loaded surfaces, bake timestamp, taxonomy hash
```

`/route` records the offer server-side and returns an `offer_id`. The client
posts that back on selection. Recording the offer server-side rather than
trusting the client means the denominator of the gate metric cannot be
silently lost.

`/score` takes a polyline from **any** router, including the caller's own. That
decoupling is the commercial point: a delivery platform can license scoring
without adopting our router, our map, or our app.

```bash
curl -s localhost:8000/score -H 'content-type: application/json' -d '{
  "coordinates": [[-87.6290,41.8820],[-87.6285,41.8900],[-87.6280,41.8990]],
  "profile": {"mode":"pedestrian","concerns":["alone"],"hour":22,"safety":0.8}
}' | jq '{exposure_index, peak_exposure, surface}'
```

## The app

`app/bearing-live.jsx` is a React client against the live API. It draws the
**baked band polygons served by `/areas/{layer}`** — not its own derivation of
risk. A map that disagrees with the route it is explaining is worse than no
map, so the client never recomputes anything.

The basemap projects from the API's bbox rather than fetching tiles, so it runs
with no Mapbox token and no external calls. For production, the route geometry
`/route` returns is already the correct input for Mapbox Bring Your Own Route
with silent waypoints.

```bash
python ops/run_api.py 8000     # API (GraphHopper must be up on :8989)
# then point any React host at app/bearing-live.jsx
```

## Adding city #2

Add two CSVs. No code.

1. `data/taxonomy_<city>.csv` — source offence classes to canonical
2. `data/street_relevance_<city>.csv` — location descriptions to street weight
3. A ~40-line adapter in `bearing/ingest/<city>.py` if the portal is not Socrata

`bearing/ingest/socrata.py` is city-agnostic and gets reused as-is for any
Socrata portal — Seattle, Baltimore, Austin. The taxonomy file is the artifact
that makes city forty take a week instead of a month; treat it as the asset it
is.

## Operational guard

The bake **exits non-zero on any unmapped source value.** CPD adds and renames
`primary_type` values; without this, a new class is silently dropped and the
score quietly degrades for months with nobody noticing. `ops/bake.sh` runs under
`set -e`, so a stale taxonomy stops the deploy rather than publishing a surface
built on one.

## Does it actually work? (no users required)

This is the question to answer first, and it needs zero beta testers.

```bash
make backtest
```

Splits incidents at a cut date, bakes the risk surface from the **train period
only**, routes real trips through a GraphHopper graph built from that surface,
then scores those routes against **held-out incidents the model never saw**.

### The control is the whole test

A safest route is longer and uses different streets. A longer route may
encounter fewer incidents purely by wandering somewhere emptier. So every
safest route is matched against a **random detour of the same extra length,
with no risk weighting at all**. If the model cannot beat a random detour, it
is a longer walk with a green badge on it.

### Result

```
trials: 150   evaluable (diverted AND had exposure): 80

mean exposure per km (length-normalised)
  fastest 2.476   safest 1.407   control 2.489

exposure reduction vs fastest, median
  safest         41.4%
  random detour   0.0%   <- the number that matters

cost: +4.8 min median (+21.3% distance)

head-to-head vs an equal-length random detour
  safest better on 66 trips, worse on 13, tied on 1
  win rate 83.5%   sign-test p = 0.0

PASS — beats an equal-length random detour on future incidents
```

Read the control row carefully: a random detour of the same length delivers
**0% median reduction** and is identical to the fastest route per kilometre
(2.489 vs 2.476). The 41% is the model knowing where the risk is, not an
artifact of walking further.

### The first run of this failed, and that mattered

Sampling trips uniformly across Chicago produced 10 evaluable trials out of
100, median extra distance +0.1%, and a nonsense verdict. Banded area is under
1% of the city, so 90 trips never came near a risk zone and the experiment
compared the treatment against itself.

Two fixes, both now regression-tested:

- **Stratified sampling.** Sample trips whose direct line crosses a risk area.
  "Does this help on an average trip" has the trivial answer "usually there is
  nothing to avoid"; the product's claim is about trips that *would* cross risk.
- **Length normalisation and a treatment filter.** Report exposure per km, and
  drop trips where the safest route is identical to the fastest — those carry
  no information and were diluting the result to noise.

## Telemetry and the demand question

`bearing/telemetry.py` captures every route offer, which option was shown, and
which was chosen. `make gate` computes the decision.

**This is a different question from whether the model works, and it is gated
later.** The backtest above answers "does a route built from crime reports pass
fewer future incidents". This section answers "will a consumer accept +5
minutes", which only matters for the consumer app.

The API business — delivery, rideshare, campus safety — does not need this
number at all. Those buyers care about predictive validity, which the backtest
establishes with no users. Run the backtest first; only recruit a beta if you
are pursuing the consumer product.

Gate for the consumer app: **>=30% acceptance of a +5 min safer option among
night pedestrian trips, and >=15% return within 14 days.**

Three things about how the gate is computed that matter more than the threshold:

**Only offers with a real trade-off count.** If the safest route costs the same
as the fastest, choosing it says nothing about willingness to trade time for
safety. Including those inflates acceptance toward meaninglessness.

**The decision rule is the lower bound of a 95% Wilson interval, not the point
estimate.** Normal approximations are badly wrong at beta sample sizes and this
decision is too consequential to read off forty trips.

**That rule implies a recruitment target, and it is larger than it looks.**
`make simulate` exposed the problem: at n=105 qualifying trips, a genuine 40%
acceptance rate produced an observed 37% whose lower bound was 28.5 — failing a
gate it should have passed. `required_n()` computes the real number:

| if true acceptance is | qualifying night trips needed |
|---|---|
| 35% | 715 |
| 40% | 189 |
| 45% | 87 |
| 50% | 50 |
| 32% | 4,270 |

Note the cliff. Detecting 35% against a 30% threshold needs nearly four times
the sample of detecting 40%, and 32% is effectively undetectable. If the true
rate is marginal, **Phase 1 cannot answer the question at any realistic beta
size** — which is itself a finding, and a reason to treat a marginal result as
a failure rather than as grounds for a bigger study.

Working backwards from 189 qualifying trips, with roughly 40% of offers
carrying a real trade-off and ~1.6 offers per session: **~470 night offers,
~295 sessions, recruit ~600 users.** That is the Phase 1 recruitment target,
and it is the number to take to the campus safety offices.
